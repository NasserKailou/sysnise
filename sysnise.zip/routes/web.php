<?php
use App\Http\Controllers\ProjetPilotageController;
use Illuminate\Support\Facades\Route;
use App\Exports\DataTemplateExport;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\PermissionController;
use App\Http\Controllers\Admin\UserRoleController;

Route::middleware(['auth'])->group(function () {
	Route::get('/', [App\Http\Controllers\DonneeIndicateurController::class, 'extractionDonneesForm'])->name('donneeIndicateur.extractionDonnees.form');

	Route::get('/zones/upload', [App\Http\Controllers\ZoneController::class, 'showUploadForm'])->name('zones.showUploadForm');
	Route::post('/zones/upload', [App\Http\Controllers\ZoneController::class, 'upload'])->name('zones.upload');
	Route::resource('zones', App\Http\Controllers\ZoneController::class);

	Route::resource('type_desagregations', App\Http\Controllers\TypeDesagregationController::class);
	Route::resource('desagregations', App\Http\Controllers\DesagregationController::class);
	Route::resource('nature_donnees', App\Http\Controllers\NatureDonneeController::class);
	Route::get('/periodes/upload', [App\Http\Controllers\PeriodeController::class, 'showUploadForm'])->name('periodes.showUploadForm');
	Route::post('/periodes/upload', [App\Http\Controllers\PeriodeController::class, 'upload'])->name('periodes.upload');
	Route::resource('periodes', App\Http\Controllers\PeriodeController::class);
	Route::get('/source_indicateurs/upload', [App\Http\Controllers\SourceIndicateurController::class, 'showUploadForm'])->name('sourceIndicateurs.showUploadForm');
	Route::post('/source_indicateurs/upload', [App\Http\Controllers\SourceIndicateurController::class, 'upload'])->name('sourceIndicateurs.upload');
	Route::resource('source_indicateurs', App\Http\Controllers\SourceIndicateurController::class);
	Route::get('/unite_indicateurs/upload', [App\Http\Controllers\UniteIndicateurController::class, 'showUploadForm'])->name('uniteIndicateurs.showUploadForm');
	Route::post('/unite_indicateurs/upload', [App\Http\Controllers\UniteIndicateurController::class, 'upload'])->name('uniteIndicateurs.upload');
	Route::resource('unite_indicateurs', App\Http\Controllers\UniteIndicateurController::class);
	Route::resource('commentaire_valeur_indicateurs', App\Http\Controllers\CommentaireValeurIndicateurController::class);
	Route::resource('source_financements', App\Http\Controllers\SourceFinancementController::class);
	Route::resource('nature_financements', App\Http\Controllers\NatureFinancementController::class);
	Route::resource('statut_financements', App\Http\Controllers\StatutFinancementController::class);
	Route::resource('categorie_depenses', App\Http\Controllers\CategorieDepenseController::class);
	Route::resource('bailleurs', App\Http\Controllers\BailleurController::class);
	Route::resource('devises', App\Http\Controllers\DeviseController::class);
	Route::resource('secteurs', App\Http\Controllers\SecteurController::class);

	Route::resource('priorites', App\Http\Controllers\PrioriteController::class);
	Route::resource('institution_tutelles', App\Http\Controllers\InstitutionTutelleController::class);
	Route::resource('population_cibles', App\Http\Controllers\PopulationCibleController::class);
	Route::resource('statut_produits', App\Http\Controllers\StatutProduitController::class);
	Route::resource('type_produits', App\Http\Controllers\TypeProduitController::class);
	Route::resource('statut_activites', App\Http\Controllers\StatutActiviteController::class);
	Route::resource('type_activites', App\Http\Controllers\TypeActiviteController::class);
	Route::resource('statut_projets', App\Http\Controllers\StatutProjetController::class);
	Route::resource('etudes', App\Http\Controllers\EtudeController::class);

	Route::resource('projets', App\Http\Controllers\ProjetController::class);
	Route::get('/projets/{projet}/composantes', [App\Http\Controllers\ComposanteController::class, 'index'])->name('projets.composantes.index');
	Route::get('/projets/{projet}/composantes_upload', [App\Http\Controllers\ComposanteController::class, 'showUploadForm'])->name('projets.composantes.showUploadForm');
	Route::post('/projets/{projet}/composantes_upload', [App\Http\Controllers\ComposanteController::class, 'upload'])->name('projets.composantes.upload');

	Route::post('/projets/associer', [App\Http\Controllers\ProjetController::class, 'associer'])->name('projets.associer');
	Route::delete('/projets/associations/{association}', [App\Http\Controllers\ProjetController::class, 'dissocier'])->name('projets.dissocier');


	Route::prefix('projets/{projet}')->group(function () {
		// Enregistrer une nouvelle pièce jointe
		Route::post('piece_jointe_projets', [App\Http\Controllers\PieceJointeProjetController::class, 'store'])->name('projets.piece_jointe_projets.store');
		// Formulaire d'édition d'une pièce jointe
		Route::get('piece_jointe_projets/{piece}', [App\Http\Controllers\PieceJointeProjetController::class, 'edit'])->name('projets.piece_jointe_projets.edit');
		// Mise à jour d'une pièce jointe
		Route::put('piece_jointe_projets/{piece}', [App\Http\Controllers\PieceJointeProjetController::class, 'update'])->name('projets.piece_jointe_projets.update');
		// Suppression d'une pièce jointe
		Route::delete('piece_jointe_projets/{piece}', [App\Http\Controllers\PieceJointeProjetController::class, 'destroy'])->name('projets.piece_jointe_projets.destroy');

		//verifier l'appelation des routes
		Route::get('cadreProjet', [App\Http\Controllers\ProjetController::class, 'cadreProjet'])->name('projets.cadreProjet');
		Route::post('cadreProjet', [App\Http\Controllers\ProjetController::class, 'storeCadreProjet'])->name('projets.storeCadreProjet');
		Route::get('editCadreProjet', [App\Http\Controllers\ProjetController::class, 'editCadreProjet'])->name('projets.editCadreProjet');
		Route::post('editCadreProjet', [App\Http\Controllers\ProjetController::class, 'updateCadreProjet'])->name('projets.updateCadreProjet');
		
		Route::get('populationCibles', [App\Http\Controllers\ProjetController::class, 'populationCible'])->name('projets.populationCibles');
		Route::post('populationCibles', [App\Http\Controllers\ProjetController::class, 'storePopulationCibles'])->name('projets.populationCibles.store');
		Route::get('editPopulationCibles/{populationCible}', [App\Http\Controllers\ProjetController::class, 'editPopulationCibles'])->name('projets.populationCibles.edit');
		Route::put('editPopulationCibles/{populationCible}', [App\Http\Controllers\ProjetController::class, 'updatePopulationCibles'])->name('projets.populationCibles.update');
		Route::delete('populationCibles/{populationCible}', [App\Http\Controllers\ProjetController::class, 'destroyPopulationCibles'])->name('projets.populationCibles.destroy');
		//etudes disponibles
		Route::get('etudeDisponibles', [App\Http\Controllers\ProjetController::class, 'etudeDisponibles'])->name('projets.etudeDisponibles');
		Route::post('etudeDisponibles', [App\Http\Controllers\ProjetController::class, 'storeEtudeDisponibles'])->name('projets.etudeDisponibles.store');
		Route::delete('etudeDisponibles/{etude}', [App\Http\Controllers\ProjetController::class, 'destroyEtudeDisponibles'])->name('projets.etudeDisponibles.destroy');
		//etudes envisagées
		Route::get('etudeEnvisagees', [App\Http\Controllers\ProjetController::class, 'etudeEnvisagees'])->name('projets.etudeEnvisagees');
		Route::post('etudeEnvisagees', [App\Http\Controllers\ProjetController::class, 'storeEtudeEnvisagees'])->name('projets.etudeEnvisagees.store');
		Route::get('editEtudeEnvisagees/{etude}/{sourceFinancement}', [App\Http\Controllers\ProjetController::class, 'editEtudeEnvisagees'])->name('projets.etudeEnvisagees.edit');
		Route::post('editEtudeEnvisagees/{etude}/{sourceFinancement}', [App\Http\Controllers\ProjetController::class, 'updateEtudeEnvisagees'])->name('projets.etudeEnvisagees.update');
		Route::delete('etudeEnvisagees/{etude}/{sourceFinancement}', [App\Http\Controllers\ProjetController::class, 'destroyEtudeEnvisagees'])->name('projets.etudeEnvisagees.destroy');

		//recherche de financement
		Route::get('rechercheFinancements', [App\Http\Controllers\ProjetController::class, 'rechercheFinancements'])->name('projets.rechercheFinancements');
		Route::post('rechercheFinancements', [App\Http\Controllers\ProjetController::class, 'storeRechercheFinancements'])->name('projets.rechercheFinancements.store');
		Route::get('editRechercheFinancements/{bailleur}/{sourceFinancement}/{statutFinancement}/{natureFinancement}', [App\Http\Controllers\ProjetController::class, 'editRechercheFinancements'])->name('projets.rechercheFinancements.edit');
		Route::post('editrechercheFinancements', [App\Http\Controllers\ProjetController::class, 'updateRechercheFinancements'])->name('projets.rechercheFinancements.update');
		Route::delete('rechercheFinancements/{bailleur}/{sourceFinancement}/{statutFinancement}/{natureFinancement}', [App\Http\Controllers\ProjetController::class, 'destroyRechercheFinancements'])->name('projets.rechercheFinancements.destroy');
		
		//plan de financement
		Route::get('planFinancements', [App\Http\Controllers\ProjetController::class, 'planFinancements'])->name('projets.planFinancements');
		Route::post('planFinancements', [App\Http\Controllers\ProjetController::class, 'storePlanFinancements'])->name('projets.planFinancements.store');
		Route::get('editPlanFinancements/{composante_id}/{source_financement_id}/{bailleur_id}/{categorie_depense_id}/{nature_financement_id}/{statut_financement_id}', [App\Http\Controllers\ProjetController::class, 'editPlanFinancements'])->name('projets.planFinancements.edit');
		Route::post('editplanFinancements/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'updatePlanFinancements'])->name('projets.planFinancements.update');
		Route::delete('planFinancements/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'destroyPlanFinancements'])->name('projets.planFinancements.destroy');
		
		//financement par composante
		Route::get('financementParComposante', [App\Http\Controllers\ProjetController::class, 'financementParComposante'])->name('projets.financementParComposante');
		Route::post('financementParComposante', [App\Http\Controllers\ProjetController::class, 'storeFinancementParComposante'])->name('projets.financementParComposante.store');
		Route::get('editFinancementParComposante/{composante_id}', [App\Http\Controllers\ProjetController::class, 'editFinancementParComposante'])->name('projets.financementParComposante.edit');
		Route::post('editFinancementParComposante/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'updateFinancementParComposante'])->name('projets.financementParComposante.update');
		
		//financement par catégorie de dépense
		Route::get('financementParCategorieDepense', [App\Http\Controllers\ProjetController::class, 'financementParCategorieDepense'])->name('projets.financementParCategorieDepense');
		Route::post('financementParCategorieDepense', [App\Http\Controllers\ProjetController::class, 'storeFinancementParCategorieDepense'])->name('projets.financementParCategorieDepense.store');
		Route::get('editFinancementParCategorieDepense/{composante_id}', [App\Http\Controllers\ProjetController::class, 'editFinancementParCategorieDepense'])->name('projets.financementParCategorieDepense.edit');
		Route::post('editFinancementParCategorieDepense/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'updateFinancementParCategorieDepense'])->name('projets.financementParCategorieDepense.update');
		
		//financement par Bailleur
		Route::get('financementParBailleur', [App\Http\Controllers\ProjetController::class, 'financementParBailleur'])->name('projets.financementParBailleur');
		Route::post('financementParBailleur', [App\Http\Controllers\ProjetController::class, 'storeFinancementParBailleur'])->name('projets.financementParBailleur.store');
		Route::get('editFinancementParBailleur/{composante_id}', [App\Http\Controllers\ProjetController::class, 'editFinancementParBailleur'])->name('projets.financementParBailleur.edit');
		Route::post('editFinancementParBailleur/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'updateFinancementParBailleur'])->name('projets.financementParBailleur.update');
		
		//**
		Route::get('financementParComposante/budgetAnnuelPrevu/{composante_id}', [App\Http\Controllers\ProjetController::class, 'budgetAnnuelPrevuParComposante'])->name('projets.financementParComposante.budgetAnnuelPrevu');
		
		Route::get('budgetAnnuelPrevu/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'budgetAnnuelPrevu'])->name('projets.planFinancements.budgetAnnuelPrevu');
		Route::post('budgetAnnuelPrevu/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'storeBudgetAnnuelPrevu'])->name('projets.planFinancements.budgetAnnuelPrevu.store');
		Route::get('editBudgetAnnuelPrevu/{budgetAnnuelPrevu}', [App\Http\Controllers\ProjetController::class, 'editBudgetAnnuelPrevu'])->name('projets.planFinancements.budgetAnnuelPrevu.edit');
		Route::post('editbudgetAnnuelPrevu/{budgetAnnuelPrevu}', [App\Http\Controllers\ProjetController::class, 'updateBudgetAnnuelPrevu'])->name('projets.planFinancements.budgetAnnuelPrevu.update');
		Route::delete('budgetAnnuelPrevu/{budgetAnnuelPrevu}', [App\Http\Controllers\ProjetController::class, 'destroyBudgetAnnuelPrevu'])->name('projets.planFinancements.budgetAnnuelPrevu.destroy');
		
		Route::get('budgetAnnuelDepense/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'budgetAnnuelDepense'])->name('projets.planFinancements.budgetAnnuelDepense');
		Route::post('budgetAnnuelDepense/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'storeBudgetAnnuelDepense'])->name('projets.planFinancements.budgetAnnuelDepense.store');
		Route::get('editBudgetAnnuelDepense/{budgetAnnuelDepense}', [App\Http\Controllers\ProjetController::class, 'editBudgetAnnuelDepense'])->name('projets.planFinancements.budgetAnnuelDepense.edit');
		Route::post('editbudgetAnnuelDepense/{budgetAnnuelDepense}', [App\Http\Controllers\ProjetController::class, 'updateBudgetAnnuelDepense'])->name('projets.planFinancements.budgetAnnuelDepense.update');
		Route::delete('budgetAnnuelDepense/{budgetAnnuelDepense}', [App\Http\Controllers\ProjetController::class, 'destroyBudgetAnnuelDepense'])->name('projets.planFinancements.budgetAnnuelDepense.destroy');
		
		//**
		Route::get('financementParComposante/budgetAnnuel/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'budgetAnnuelParComposante'])->name('projets.financementParComposante.budgetAnnuel');
		Route::get('budgetAnnuel/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'budgetAnnuel'])->name('projets.planFinancements.budgetAnnuel');
		Route::post('budgetAnnuel/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'storeBudgetAnnuel'])->name('projets.planFinancements.budgetAnnuel.store');
		Route::get('editBudgetAnnuel/{budgetAnnuel}', [App\Http\Controllers\ProjetController::class, 'editBudgetAnnuel'])->name('projets.planFinancements.budgetAnnuel.edit');
		Route::post('editbudgetAnnuel/{budgetAnnuel}', [App\Http\Controllers\ProjetController::class, 'updateBudgetAnnuel'])->name('projets.planFinancements.budgetAnnuel.update');
		Route::delete('budgetAnnuel/{budgetAnnuel}', [App\Http\Controllers\ProjetController::class, 'destroyBudgetAnnuel'])->name('projets.planFinancements.budgetAnnuel.destroy');
		
		//clôture projet
		Route::get('clotureProjets', [App\Http\Controllers\ProjetController::class, 'clotureProjets'])->name('projets.clotureProjets');
		Route::post('clotureProjets', [App\Http\Controllers\ProjetController::class, 'storeClotureProjets'])->name('projets.clotureProjets.store');
		Route::get('editClotureProjets/{clotureProjet}', [App\Http\Controllers\ProjetController::class, 'editClotureProjets'])->name('projets.clotureProjets.edit');
		Route::post('editClotureProjets/{clotureProjet}', [App\Http\Controllers\ProjetController::class, 'updateClotureProjets'])->name('projets.clotureProjets.update');
		Route::delete('clotureProjets/{clotureProjet}',[App\Http\Controllers\ProjetController::class, 'destroyClotureProjets'])->name('projets.clotureProjets.destroy');
		
		Route::get('viewAssociations', [App\Http\Controllers\ProjetController::class, 'viewAssociations'])->name('projets.viewAssociations');
		Route::get('association', [App\Http\Controllers\ProjetController::class, 'association'])->name('projets.association');
		
	});

	Route::resource('cadre_developpements', App\Http\Controllers\CadreDeveloppementController::class);
	Route::prefix('cadre_developpements/{cadre}')->group(function () {
		// Enregistrer une nouvelle pièce jointe
		Route::post('piece_jointes', [App\Http\Controllers\PieceJointeController::class, 'store'])->name('cadre_developpements.piece_jointes.store');
		// Formulaire d'édition d'une pièce jointe
		Route::get('piece_jointes/{piece}', [App\Http\Controllers\PieceJointeController::class, 'edit'])->name('cadre_developpements.piece_jointes.edit');
		// Mise à jour d'une pièce jointe
		Route::put('piece_jointes/{piece}', [App\Http\Controllers\PieceJointeController::class, 'update'])->name('cadre_developpements.piece_jointes.update');
		// Suppression d'une pièce jointe
		Route::delete('piece_jointes/{piece}', [App\Http\Controllers\PieceJointeController::class, 'destroy'])->name('cadre_developpements.piece_jointes.destroy');
	});
	
	//financement par Bailleur
	Route::get('financementParBailleur', [App\Http\Controllers\ProjetController::class, 'financementParBailleur'])->name('projets.financementParBailleur');
	Route::post('financementParBailleur', [App\Http\Controllers\ProjetController::class, 'storeFinancementParBailleur'])->name('projets.financementParBailleur.store');
	Route::get('editFinancementParBailleur/{composante_id}', [App\Http\Controllers\ProjetController::class, 'editFinancementParBailleur'])->name('projets.financementParBailleur.edit');
	Route::post('editFinancementParBailleur/{planFinancement}', [App\Http\Controllers\ProjetController::class, 'updateFinancementParBailleur'])->name('projets.financementParBailleur.update');
	
	Route::get('/cadre_developpements/{cadre_developpement}/financementParResultat', [App\Http\Controllers\CadreDeveloppementController::class, 'financementParResultat'])->name('cadre_developpements.financementParResultat');
	Route::post('/cadre_developpements/{cadre_developpement}/financementParResultat', [App\Http\Controllers\CadreDeveloppementController::class, 'soreFinancementParResultat'])->name('cadre_developpements.financementParResultat.store');
	
	Route::prefix('cadre_developpements/{cadre_developpement}/')->group(function () {
		Route::get('financementParBailleur', [App\Http\Controllers\CadreDeveloppementController::class, 'financementParBailleur'])->name('cadre_developpements.financementParBailleur');
		Route::post('financementParBailleur', [App\Http\Controllers\CadreDeveloppementController::class, 'storeFinancementParBailleur'])->name('cadre_developpements.financementParBailleur.store');
		Route::get('editFinancementParBailleur/{financementParBailleur}', [App\Http\Controllers\CadreDeveloppementController::class, 'editFinancementParBailleur'])->name('cadre_developpements.financementParBailleur.edit');
		Route::post('editFinancementParBailleur/{financementParBailleur}', [App\Http\Controllers\CadreDeveloppementController::class, 'updateFinancementParBailleur'])->name('cadre_developpements.financementParBailleur.update');
		Route::delete('destroyFinancementParBailleur/{financementParBailleur}', [App\Http\Controllers\CadreDeveloppementController::class, 'destroyFinancementParBailleur'])->name('cadre_developpements.financementParBailleur.destroy');
		
		Route::get('montantMobiliseFB/{financementParBailleur}', [App\Http\Controllers\CadreDeveloppementController::class, 'montantMobiliseFB'])->name('cadre_developpements.financementParBailleur.montantMobilise');
		Route::post('montantMobiliseFB/{financementParBailleur}', [App\Http\Controllers\CadreDeveloppementController::class, 'storeMontantMobiliseFB'])->name('cadre_developpements.financementParBailleur.montantMobilise.store');
		Route::get('editMontantMobiliseFB/{montantMobilise}', [App\Http\Controllers\CadreDeveloppementController::class, 'editMontantMobiliseFB'])->name('cadre_developpements.financementParBailleur.montantMobilise.edit');
		Route::post('editMontantMobiliseFB/{montantMobilise}', [App\Http\Controllers\CadreDeveloppementController::class, 'updateMontantMobiliseFB'])->name('cadre_developpements.financementParBailleur.montantMobilise.update');
		Route::delete('montantMobiliseFB/{montantMobilise}', [App\Http\Controllers\CadreDeveloppementController::class, 'destroyMontantMobiliseFB'])->name('cadre_developpements.financementParBailleur.montantMobilise.destroy');
		
		Route::get('montantConsommeFB/{financementParBailleur}', [App\Http\Controllers\CadreDeveloppementController::class, 'montantConsommeFB'])->name('cadre_developpements.financementParBailleur.montantConsomme');
		Route::post('montantConsommeFB/{financementParBailleur}', [App\Http\Controllers\CadreDeveloppementController::class, 'storeMontantConsommeFB'])->name('cadre_developpements.financementParBailleur.montantConsomme.store');
		Route::get('editMontantConsommeFB/{montantConsomme}', [App\Http\Controllers\CadreDeveloppementController::class, 'editMontantConsommeFB'])->name('cadre_developpements.financementParBailleur.montantConsomme.edit');
		Route::post('editMontantConsommeFB/{montantConsomme}', [App\Http\Controllers\CadreDeveloppementController::class, 'updateMontantConsommeFB'])->name('cadre_developpements.financementParBailleur.montantConsomme.update');
		Route::delete('montantConsommeFB/{montantConsomme}', [App\Http\Controllers\CadreDeveloppementController::class, 'destroyMontantConsommeFB'])->name('cadre_developpements.financementParBailleur.montantConsomme.destroy');
		
		Route::get('montantRechercheFB/{financementParBailleur}', [App\Http\Controllers\CadreDeveloppementController::class, 'montantRechercheFB'])->name('cadre_developpements.financementParBailleur.montantRecherche');
		Route::post('montantRechercheFB/{financementParBailleur}', [App\Http\Controllers\CadreDeveloppementController::class, 'storeMontantRechercheFB'])->name('cadre_developpements.financementParBailleur.montantRecherche.store');
		Route::get('editMontantRechercheFB/{montantRecherche}', [App\Http\Controllers\CadreDeveloppementController::class, 'editMontantRechercheFB'])->name('cadre_developpements.financementParBailleur.montantRecherche.edit');
		Route::post('editMontantRechercheFB/{montantRecherche}', [App\Http\Controllers\CadreDeveloppementController::class, 'updateMontantRechercheFB'])->name('cadre_developpements.financementParBailleur.montantRecherche.update');
		Route::delete('montantRechercheFB/{montantRecherche}', [App\Http\Controllers\CadreDeveloppementController::class, 'destroyMontantRechercheFB'])->name('cadre_developpements.financementParBailleur.montantRecherche.destroy');
		
		Route::get('financementParResultat', [App\Http\Controllers\CadreDeveloppementController::class, 'financementParResultat'])->name('cadre_developpements.financementParResultat');
		Route::post('financementParResultat', [App\Http\Controllers\CadreDeveloppementController::class, 'storeFinancementParResultat'])->name('cadre_developpements.financementParResultat.store');
		Route::get('editFinancementParResultat/{financementParResultat}', [App\Http\Controllers\CadreDeveloppementController::class, 'editFinancementParResultat'])->name('cadre_developpements.financementParResultat.edit');
		Route::post('editFinancementParResultat/{financementParResultat}', [App\Http\Controllers\CadreDeveloppementController::class, 'updateFinancementParResultat'])->name('cadre_developpements.financementParResultat.update');
		Route::delete('destroyFinancementParResultat/{financementParResultat}', [App\Http\Controllers\CadreDeveloppementController::class, 'destroyFinancementParResultat'])->name('cadre_developpements.financementParResultat.destroy');
		
		Route::get('montantMobiliseFR/{financementParResultat}', [App\Http\Controllers\CadreDeveloppementController::class, 'montantMobiliseFR'])->name('cadre_developpements.financementParResultat.montantMobilise');
		Route::post('montantMobiliseFR/{financementParResultat}', [App\Http\Controllers\CadreDeveloppementController::class, 'storeMontantMobiliseFR'])->name('cadre_developpements.financementParResultat.montantMobilise.store');
		Route::get('editMontantMobiliseFR/{montantMobilise}', [App\Http\Controllers\CadreDeveloppementController::class, 'editMontantMobiliseFR'])->name('cadre_developpements.financementParResultat.montantMobilise.edit');
		Route::post('editMontantMobiliseFR/{montantMobilise}', [App\Http\Controllers\CadreDeveloppementController::class, 'updateMontantMobiliseFR'])->name('cadre_developpements.financementParResultat.montantMobilise.update');
		Route::delete('montantMobiliseFR/{montantMobilise}', [App\Http\Controllers\CadreDeveloppementController::class, 'destroyMontantMobiliseFR'])->name('cadre_developpements.financementParResultat.montantMobilise.destroy');
		
		Route::get('montantConsommeFR/{financementParResultat}', [App\Http\Controllers\CadreDeveloppementController::class, 'montantConsommeFR'])->name('cadre_developpements.financementParResultat.montantConsomme');
		Route::post('montantConsommeFR/{financementParResultat}', [App\Http\Controllers\CadreDeveloppementController::class, 'storeMontantConsommeFR'])->name('cadre_developpements.financementParResultat.montantConsomme.store');
		Route::get('editMontantConsommeFR/{montantConsomme}', [App\Http\Controllers\CadreDeveloppementController::class, 'editMontantConsommeFR'])->name('cadre_developpements.financementParResultat.montantConsomme.edit');
		Route::post('editMontantConsommeFR/{montantConsomme}', [App\Http\Controllers\CadreDeveloppementController::class, 'updateMontantConsommeFR'])->name('cadre_developpements.financementParResultat.montantConsomme.update');
		Route::delete('montantConsommeFR/{montantConsomme}', [App\Http\Controllers\CadreDeveloppementController::class, 'destroyMontantConsommeFR'])->name('cadre_developpements.financementParResultat.montantConsomme.destroy');
		
		Route::get('montantRechercheFR/{financementParResultat}', [App\Http\Controllers\CadreDeveloppementController::class, 'montantRechercheFR'])->name('cadre_developpements.financementParResultat.montantRecherche');
		Route::post('montantRechercheFR/{financementParResultat}', [App\Http\Controllers\CadreDeveloppementController::class, 'storeMontantRechercheFR'])->name('cadre_developpements.financementParResultat.montantRecherche.store');
		Route::get('editMontantRechercheFR/{montantRecherche}', [App\Http\Controllers\CadreDeveloppementController::class, 'editMontantRechercheFR'])->name('cadre_developpements.financementParResultat.montantRecherche.edit');
		Route::post('editMontantRechercheFR/{montantRecherche}', [App\Http\Controllers\CadreDeveloppementController::class, 'updateMontantRechercheFR'])->name('cadre_developpements.financementParResultat.montantRecherche.update');
		Route::delete('montantRechercheFR/{montantRecherche}', [App\Http\Controllers\CadreDeveloppementController::class, 'destroyMontantRechercheFR'])->name('cadre_developpements.financementParResultat.montantRecherche.destroy');
		
		Route::get('viewAssociations', [App\Http\Controllers\CadreDeveloppementController::class, 'viewAssociations'])->name('cadre_developpements.viewAssociations');
		Route::get('association', [App\Http\Controllers\CadreDeveloppementController::class, 'association'])->name('cadre_developpements.association');
		
	
	});
	Route::get('/cadre_developpements/{cadre_developpement}/cadres_logiques', [App\Http\Controllers\CadreLogiqueController::class, 'index'])->name('cadre_developpements.cadres_logiques.index');
	Route::get('/cadre_developpements/{cadre_developpement}/cadres_logiques_upload', [App\Http\Controllers\CadreLogiqueController::class, 'showUploadForm'])->name('cadre_developpements.cadres_logiques.showUploadForm');
	Route::post('/cadre_developpements/{cadre_developpement}/cadres_logiques_upload', [App\Http\Controllers\CadreLogiqueController::class, 'upload'])->name('cadre_developpements.cadres_logiques.upload');
	Route::post('/cadre_developpements/associer', [App\Http\Controllers\CadreDeveloppementController::class, 'associer'])->name('cadre_developpements.associer');
	Route::delete('/cadre_developpements/associations/{association}', [App\Http\Controllers\CadreDeveloppementController::class, 'dissocier'])->name('cadre_developpements.dissocier');

	Route::resource('cadre_logiques.hypothese_risques', App\Http\Controllers\HypotheseRisqueController::class);
	Route::resource('cadre_logiques.produits', App\Http\Controllers\ProduitController::class);
    
	// Enregistrer une nouvelle pièce jointe
    Route::post('piece_jointe_produits', [App\Http\Controllers\PieceJointeProduitController::class, 'store'])->name('produits.piece_jointe_produits.store');
    // Formulaire d'édition d'une pièce jointe
    Route::get('piece_jointe_produits/{piece}', [App\Http\Controllers\PieceJointeProduitController::class, 'edit'])->name('produits.piece_jointe_produits.edit');
    // Mise à jour d'une pièce jointe
    Route::put('piece_jointe_produits/{piece}', [App\Http\Controllers\PieceJointeProduitController::class, 'update'])->name('produits.piece_jointe_produits.update');
    // Suppression d'une pièce jointe
    Route::delete('piece_jointe_produits/{piece}', [App\Http\Controllers\PieceJointeProduitController::class, 'destroy'])->name('produits.piece_jointe_produits.destroy');


	Route::resource('cadre_logiques.activites', App\Http\Controllers\ActiviteController::class);
	// Enregistrer une nouvelle pièce jointe
    Route::post('piece_jointe_activites', [App\Http\Controllers\PieceJointeActiviteController::class, 'store'])->name('activites.piece_jointe_activites.store');
    // Formulaire d'édition d'une pièce jointe
    Route::get('piece_jointe_activites/{piece}', [App\Http\Controllers\PieceJointeActiviteController::class, 'edit'])->name('activites.piece_jointe_activites.edit');
    // Mise à jour d'une pièce jointe
    Route::put('piece_jointe_activites/{piece}', [App\Http\Controllers\PieceJointeActiviteController::class, 'update'])->name('activites.piece_jointe_activites.update');
    // Suppression d'une pièce jointe
    Route::delete('piece_jointe_activites/{piece}', [App\Http\Controllers\PieceJointeActiviteController::class, 'destroy'])->name('activites.piece_jointe_activites.destroy');


	Route::get('/indicateurs/upload', [App\Http\Controllers\IndicateurController::class, 'showUploadForm'])->name('indicateurs.upload.form');
	Route::post('indicateurs/upload', [App\Http\Controllers\IndicateurController::class, 'upload'])->name('indicateurs.upload');
	Route::get('/indicateurs/{indicateur}/desagregation', [App\Http\Controllers\IndicateurController::class, 'showDesagregationForm'])->name('indicateurs.desagregation.form');

	Route::get('/donnee_indicateurs/create', [App\Http\Controllers\DonneeIndicateurController::class, 'create']);
	Route::post('/donnee_indicateurs/store', [App\Http\Controllers\DonneeIndicateurController::class, 'store'])->name('donnee_indicateurs.store');

	Route::get('/donnee_indicateurs/uploadData', [App\Http\Controllers\DonneeIndicateurController::class, 'showUploadDataForm'])->name('donnee_indicateurs.uploadData.form');
	Route::post('donnee_indicateurs/uploadData', [App\Http\Controllers\DonneeIndicateurController::class, 'uploadData'])->name('donnee_indicateurs.uploadData');
	Route::get('/donnee_indicateurs/extractionDonnees', [App\Http\Controllers\DonneeIndicateurController::class, 'extractionDonneesForm'])->name('donneeIndicateur.extractionDonnees.form');
	Route::post('/donnee_indicateurs/extractionDonnees', [App\Http\Controllers\DonneeIndicateurController::class, 'extractionDonnees'])->name('donneeIndicateur.extractionDonnees');

	Route::get('/donnee_indicateurs/parametreSaisie', [App\Http\Controllers\DonneeIndicateurController::class, 'parametreSaisieForm'])->name('donneeIndicateur.parametreSaisie.form');
	Route::post('/donnee_indicateurs/parametreSaisie', [App\Http\Controllers\DonneeIndicateurController::class, 'matriceSaisie'])->name('donneeIndicateur.parametreSaisie');
	Route::post('/donnee_indicateurs/matriceSaisie', [App\Http\Controllers\DonneeIndicateurController::class, 'saveMatriceSaisie'])->name('donneeIndicateur.matriceSaisie.store');

	// Routes de validation des données
	Route::get('/donnee_indicateurs/validation', [App\Http\Controllers\DonneeIndicateurController::class, 'indexValidation'])->name('donneeIndicateur.validation.index');
	Route::get('/donnee_indicateurs/validees', [App\Http\Controllers\DonneeIndicateurController::class, 'indexValidees'])->name('donneeIndicateur.validees.index');
	Route::get('/donnee_indicateurs/rejetees', [App\Http\Controllers\DonneeIndicateurController::class, 'indexRejetees'])->name('donneeIndicateur.rejetees.index');
	Route::post('/donnee_indicateurs/{id}/valider', [App\Http\Controllers\DonneeIndicateurController::class, 'valider'])->name('donneeIndicateur.valider');
	Route::post('/donnee_indicateurs/{id}/rejeter', [App\Http\Controllers\DonneeIndicateurController::class, 'rejeter'])->name('donneeIndicateur.rejeter');
	Route::post('/donnee_indicateurs/valider-global', [App\Http\Controllers\DonneeIndicateurController::class, 'validerGlobal'])->name('donneeIndicateur.valider.global');
	Route::post('/donnee_indicateurs/valider-tout', [App\Http\Controllers\DonneeIndicateurController::class, 'validerTout'])->name('donneeIndicateur.valider.tout');
	Route::post('/donnee_indicateurs/rejeter-global', [App\Http\Controllers\DonneeIndicateurController::class, 'rejeterGlobal'])->name('donneeIndicateur.rejeter.global');

	Route::get('/export_data_template', function () {
		return Excel::download(new DataTemplateExport, 'data_template.xlsx');
	});

	Route::get('/export_cadre_data_template/{cadre_developpement_id}', function ($cadre_developpement_id) {
		return Excel::download(new \App\Exports\CadreDataTemplateExport($cadre_developpement_id), 'modele_chargement_cadre_' . $cadre_developpement_id . '.xlsx');
	})->name('export_cadre_data_template');

	Route::get('/afficher_cmr/{cadre_id}', [App\Http\Controllers\DonneeIndicateurController::class, 'afficherCMR']);
	Route::get('/telecharger_cmr/{cadre_id}', [App\Http\Controllers\DonneeIndicateurController::class, 'telecharger_cmr']);





	// Routes pour la gestion du pilotage/audit d'un projet
Route::prefix('projets/{projet}')->name('projets.')->group(function () {
    Route::get('pilotage', [ProjetPilotageController::class, 'show'])->name('pilotage.show');
    Route::put('pilotage/general', [ProjetPilotageController::class, 'updateGeneral'])->name('pilotage.updateGeneral');

    // Pilotage années
    Route::post('pilotage-annees', [ProjetPilotageController::class, 'storePilotageAnnee'])->name('pilotage-annees.store');
    Route::get('pilotage-annees/{annee}/edit', [ProjetPilotageController::class, 'editPilotageAnnee'])->name('pilotage-annees.edit');
    Route::put('pilotage-annees/{annee}', [ProjetPilotageController::class, 'updatePilotageAnnee'])->name('pilotage-annees.update');
    Route::delete('pilotage-annees/{annee}', [ProjetPilotageController::class, 'destroyPilotageAnnee'])->name('pilotage-annees.destroy');

    // Audits exercices
    Route::post('audits-exercices', [ProjetPilotageController::class, 'storeAuditExercice'])->name('audits-exercices.store');
    Route::get('audits-exercices/{exercice}/edit', [ProjetPilotageController::class, 'editAuditExercice'])->name('audits-exercices.edit');
    Route::put('audits-exercices/{exercice}', [ProjetPilotageController::class, 'updateAuditExercice'])->name('audits-exercices.update');
    Route::delete('audits-exercices/{exercice}', [ProjetPilotageController::class, 'destroyAuditExercice'])->name('audits-exercices.destroy');

    // Rapports
    Route::post('rapports', [ProjetPilotageController::class, 'storeRapport'])->name('rapports.store');
    Route::delete('rapports/{rapport}', [ProjetPilotageController::class, 'destroyRapport'])->name('rapports.destroy');
});




	
});
Route::middleware(['auth'])->prefix('admin')->name('admin.')->group(function () {
    Route::resource('roles', RoleController::class);
    Route::resource('permissions', PermissionController::class)->except(['show']);
    Route::get('users', [UserRoleController::class, 'index'])->name('users.index');
    Route::post('users/{user}/roles', [UserRoleController::class, 'updateRoles'])->name('users.updateRoles');
});

// Routes de connexion
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.post');
Route::get('/logout', [LoginController::class, 'logout'])->name('logout');


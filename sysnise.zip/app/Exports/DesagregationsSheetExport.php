<?php

namespace App\Exports;

use App\Models\Desagregation;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithTitle;

class DesagregationsSheetExport implements FromCollection, WithHeadings, WithTitle
{
    public function collection()
    {
		return Desagregation::select('intitule', 'id')->get();
    }
	
	public function headings(): array
    {
        return [
            'Intitulé',
			'Id'
        ];
    }

    public function title(): string
    {
        return 'Desagregations'; 
    }
}
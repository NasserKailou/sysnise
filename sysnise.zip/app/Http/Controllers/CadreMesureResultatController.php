<?php

namespace App\Http\Controllers;

use App\Http\Requests\CadreMesureResultatStoreRequest;
use App\Http\Requests\CadreMesureResultatUpdateRequest;
use App\Models\CadreMesureResultat;
use App\Models\CadreDeveloppement;
use App\Models\Indicateur;
use App\Models\CadreLogique;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CadreMesureResultatController extends Controller
{
   
}

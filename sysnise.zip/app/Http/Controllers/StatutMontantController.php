<?php

namespace App\Http\Controllers;

use App\Http\Requests\StatutMontantStoreRequest;
use App\Http\Requests\StatutMontantUpdateRequest;
use App\Models\StatutMontant;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class StatutMontantController extends Controller
{
    public function index(Request $request)
    {
        $statutMontants = StatutMontant::all();

        return view('statutMontant.index', [
            'statutMontants' => $statutMontants,
			'breadcrumb' => 'Reférentiel > Statuts Activité',
        ]);
    }

    public function create(Request $request)
    {
        return view('statutMontant.create',[
			'breadcrumb' => 'Reférentiel > Nouveau Statut Activité',
		]);
    }

    public function store(StatutMontantStoreRequest $request)
    {
        $statutMontant = StatutMontant::create($request->validated());

        return redirect()->route('statut_montants.index')->with('success', 'statut de montant créée avec succès');
       
    }

    public function show(Request $request, StatutMontant $statutMontant)
    {
        return view('statutMontant.show', [
            'statutMontant' => $statutMontant,
			'breadcrumb' => 'Reférentiel > Statut Activité',
        ]);
    }

    public function edit(Request $request, StatutMontant $statutMontant)
    {
        return view('statutMontant.edit', [
            'statutMontant' => $statutMontant,
			'breadcrumb' => 'Reférentiel > Mise à jour Statut Activité',
        ]);
    }

    public function update(StatutMontantUpdateRequest $request, StatutMontant $statutMontant)
    {
        $statutMontant->update($request->validated());

        return redirect()->route('statut_montants.index')->with('success', 'statut de montant modifiée avec succès');
    }

    public function destroy(Request $request, StatutMontant $statutMontant)
    {
        $statutMontant->delete();

        return redirect()->route('statut_montants.index')->with('success', 'statut de montant supprimée avec succès');
    }
}

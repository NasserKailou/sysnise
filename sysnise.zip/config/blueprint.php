<?php
return [
    'controllers' => [
        'return_type' => 'view', // ou 'response' selon votre préférence
    ],
];


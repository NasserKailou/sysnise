--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

-- Started on 2025-11-13 17:42:14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5 (class 2615 OID 25949)
-- Name: public; Type: SCHEMA; Schema: -; Owner: sysnise
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO sysnise;

--
-- TOC entry 5547 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: sysnise
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 311 (class 1259 OID 27581)
-- Name: activite_zone; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.activite_zone (
    id integer NOT NULL,
    activite_id bigint NOT NULL,
    zone_id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.activite_zone OWNER TO sysnise;

--
-- TOC entry 310 (class 1259 OID 27580)
-- Name: activite_zone_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.activite_zone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activite_zone_id_seq OWNER TO sysnise;

--
-- TOC entry 5549 (class 0 OID 0)
-- Dependencies: 310
-- Name: activite_zone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.activite_zone_id_seq OWNED BY public.activite_zone.id;


--
-- TOC entry 305 (class 1259 OID 27521)
-- Name: activites; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.activites (
    id integer NOT NULL,
    cadre_logique_id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    annee_debut_prevu integer,
    annee_fin_prevu integer,
    duree_travaux integer,
    cout_prevu integer,
    responsable character varying(255),
    contact_responsable character varying(255),
    statut_activite_id bigint,
    description character varying(255),
    date_debut_realisation date,
    date_fin_realisation date,
    cout_realisation integer,
    latitude double precision,
    longitude double precision,
    activite_id bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    type_activite_id bigint
);


ALTER TABLE public.activites OWNER TO sysnise;

--
-- TOC entry 304 (class 1259 OID 27520)
-- Name: activites_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.activites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activites_id_seq OWNER TO sysnise;

--
-- TOC entry 5550 (class 0 OID 0)
-- Dependencies: 304
-- Name: activites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.activites_id_seq OWNED BY public.activites.id;


--
-- TOC entry 221 (class 1259 OID 26837)
-- Name: cache; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO sysnise;

--
-- TOC entry 222 (class 1259 OID 26844)
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO sysnise;

--
-- TOC entry 231 (class 1259 OID 26890)
-- Name: cadre_developpements; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.cadre_developpements (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    structure_responsable character varying(255),
    annee_debut character varying(255),
    annee_fin character varying(255),
    description text,
    cadre_developpement_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    type_cadre_developpement_id bigint DEFAULT 1
);


ALTER TABLE public.cadre_developpements OWNER TO sysnise;

--
-- TOC entry 230 (class 1259 OID 26889)
-- Name: cadre_developpements_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.cadre_developpements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cadre_developpements_id_seq OWNER TO sysnise;

--
-- TOC entry 5551 (class 0 OID 0)
-- Dependencies: 230
-- Name: cadre_developpements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.cadre_developpements_id_seq OWNED BY public.cadre_developpements.id;


--
-- TOC entry 235 (class 1259 OID 26908)
-- Name: cadre_logiques; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.cadre_logiques (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    niveau integer,
    cadre_logique_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.cadre_logiques OWNER TO sysnise;

--
-- TOC entry 234 (class 1259 OID 26907)
-- Name: cadre_logiques_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.cadre_logiques_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cadre_logiques_id_seq OWNER TO sysnise;

--
-- TOC entry 5552 (class 0 OID 0)
-- Dependencies: 234
-- Name: cadre_logiques_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.cadre_logiques_id_seq OWNED BY public.cadre_logiques.id;


--
-- TOC entry 239 (class 1259 OID 26922)
-- Name: indicateurs; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.indicateurs (
    id bigint NOT NULL,
    code character varying(255),
    intitule character varying(255) NOT NULL,
    definition character varying(255),
    donnees_requises character varying(255),
    methode_calcul character varying(255),
    methode_collecte character varying(255),
    source character varying(255),
    commentaire_limite character varying(255),
    niveau_desagregation character varying(255),
    periodicite character varying(255),
    unite character varying(255),
    echelle character varying(255),
    lien_avec_cadre_developpement character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.indicateurs OWNER TO sysnise;

--
-- TOC entry 238 (class 1259 OID 26921)
-- Name: indicateurs_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.indicateurs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.indicateurs_id_seq OWNER TO sysnise;

--
-- TOC entry 5553 (class 0 OID 0)
-- Dependencies: 238
-- Name: indicateurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.indicateurs_id_seq OWNED BY public.indicateurs.id;


--
-- TOC entry 256 (class 1259 OID 27053)
-- Name: cadre_mesure_resultats; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.cadre_mesure_resultats (
    indicateur_id bigint NOT NULL,
    cadre_logique_id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    id bigint DEFAULT nextval('public.indicateurs_id_seq'::regclass) NOT NULL
);


ALTER TABLE public.cadre_mesure_resultats OWNER TO sysnise;

--
-- TOC entry 255 (class 1259 OID 26992)
-- Name: commentaire_valeur_indicateurs; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.commentaire_valeur_indicateurs (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    description character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.commentaire_valeur_indicateurs OWNER TO sysnise;

--
-- TOC entry 254 (class 1259 OID 26991)
-- Name: commentaire_valeur_indicateurs_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.commentaire_valeur_indicateurs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.commentaire_valeur_indicateurs_id_seq OWNER TO sysnise;

--
-- TOC entry 5554 (class 0 OID 0)
-- Dependencies: 254
-- Name: commentaire_valeur_indicateurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.commentaire_valeur_indicateurs_id_seq OWNED BY public.commentaire_valeur_indicateurs.id;


--
-- TOC entry 258 (class 1259 OID 27083)
-- Name: desagregation_indicateur; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.desagregation_indicateur (
    id bigint NOT NULL,
    desagregation_id bigint NOT NULL,
    indicateur_id bigint NOT NULL
);


ALTER TABLE public.desagregation_indicateur OWNER TO sysnise;

--
-- TOC entry 257 (class 1259 OID 27082)
-- Name: desagregation_indicateur_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.desagregation_indicateur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.desagregation_indicateur_id_seq OWNER TO sysnise;

--
-- TOC entry 5555 (class 0 OID 0)
-- Dependencies: 257
-- Name: desagregation_indicateur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.desagregation_indicateur_id_seq OWNED BY public.desagregation_indicateur.id;


--
-- TOC entry 243 (class 1259 OID 26938)
-- Name: desagregations; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.desagregations (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    type_desagregation_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.desagregations OWNER TO sysnise;

--
-- TOC entry 242 (class 1259 OID 26937)
-- Name: desagregations_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.desagregations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.desagregations_id_seq OWNER TO sysnise;

--
-- TOC entry 5556 (class 0 OID 0)
-- Dependencies: 242
-- Name: desagregations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.desagregations_id_seq OWNED BY public.desagregations.id;


--
-- TOC entry 288 (class 1259 OID 27360)
-- Name: donnee_indicateur_desagregation; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.donnee_indicateur_desagregation (
    id integer NOT NULL,
    donnee_indicateur_id bigint NOT NULL,
    desagregation_id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.donnee_indicateur_desagregation OWNER TO sysnise;

--
-- TOC entry 287 (class 1259 OID 27359)
-- Name: donnee_indicateur_desagregation_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.donnee_indicateur_desagregation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.donnee_indicateur_desagregation_id_seq OWNER TO sysnise;

--
-- TOC entry 5557 (class 0 OID 0)
-- Dependencies: 287
-- Name: donnee_indicateur_desagregation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.donnee_indicateur_desagregation_id_seq OWNED BY public.donnee_indicateur_desagregation.id;


--
-- TOC entry 241 (class 1259 OID 26931)
-- Name: donnee_indicateurs; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.donnee_indicateurs (
    id bigint NOT NULL,
    nature_donnee_id bigint NOT NULL,
    indicateur_id bigint NOT NULL,
    zone_id bigint NOT NULL,
    periode_id bigint NOT NULL,
    source_indicateur_id bigint NOT NULL,
    unite_indicateur_id bigint NOT NULL,
    commentaire_valeur_indicateur_id bigint NOT NULL,
    valeur double precision NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.donnee_indicateurs OWNER TO sysnise;

--
-- TOC entry 240 (class 1259 OID 26930)
-- Name: donnee_indicateurs_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.donnee_indicateurs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.donnee_indicateurs_id_seq OWNER TO sysnise;

--
-- TOC entry 5558 (class 0 OID 0)
-- Dependencies: 240
-- Name: donnee_indicateurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.donnee_indicateurs_id_seq OWNED BY public.donnee_indicateurs.id;


--
-- TOC entry 270 (class 1259 OID 27166)
-- Name: etude_identifications; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.etude_identifications (
    id bigint NOT NULL,
    projet_id bigint NOT NULL,
    etude_id bigint NOT NULL,
    etude_disponible boolean NOT NULL,
    document_etude character varying(255),
    etude_envisagee boolean,
    source_financement_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.etude_identifications OWNER TO sysnise;

--
-- TOC entry 269 (class 1259 OID 27165)
-- Name: etude_identifications_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.etude_identifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.etude_identifications_id_seq OWNER TO sysnise;

--
-- TOC entry 5559 (class 0 OID 0)
-- Dependencies: 269
-- Name: etude_identifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.etude_identifications_id_seq OWNED BY public.etude_identifications.id;


--
-- TOC entry 274 (class 1259 OID 27180)
-- Name: etudes; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.etudes (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.etudes OWNER TO sysnise;

--
-- TOC entry 273 (class 1259 OID 27179)
-- Name: etudes_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.etudes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.etudes_id_seq OWNER TO sysnise;

--
-- TOC entry 5560 (class 0 OID 0)
-- Dependencies: 273
-- Name: etudes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.etudes_id_seq OWNED BY public.etudes.id;


--
-- TOC entry 227 (class 1259 OID 26869)
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO sysnise;

--
-- TOC entry 226 (class 1259 OID 26868)
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO sysnise;

--
-- TOC entry 5561 (class 0 OID 0)
-- Dependencies: 226
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- TOC entry 291 (class 1259 OID 27406)
-- Name: hypothese_risques; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.hypothese_risques (
    id integer NOT NULL,
    cadre_logique_id integer NOT NULL,
    hypothese text,
    risque text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.hypothese_risques OWNER TO sysnise;

--
-- TOC entry 290 (class 1259 OID 27405)
-- Name: hypothese_risques_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.hypothese_risques_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hypothese_risques_id_seq OWNER TO sysnise;

--
-- TOC entry 5562 (class 0 OID 0)
-- Dependencies: 290
-- Name: hypothese_risques_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.hypothese_risques_id_seq OWNED BY public.hypothese_risques.id;


--
-- TOC entry 264 (class 1259 OID 27141)
-- Name: institution_tutelles; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.institution_tutelles (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.institution_tutelles OWNER TO sysnise;

--
-- TOC entry 263 (class 1259 OID 27140)
-- Name: institution_tutelles_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.institution_tutelles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.institution_tutelles_id_seq OWNER TO sysnise;

--
-- TOC entry 5563 (class 0 OID 0)
-- Dependencies: 263
-- Name: institution_tutelles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.institution_tutelles_id_seq OWNED BY public.institution_tutelles.id;


--
-- TOC entry 225 (class 1259 OID 26861)
-- Name: job_batches; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO sysnise;

--
-- TOC entry 224 (class 1259 OID 26852)
-- Name: jobs; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO sysnise;

--
-- TOC entry 223 (class 1259 OID 26851)
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO sysnise;

--
-- TOC entry 5564 (class 0 OID 0)
-- Dependencies: 223
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- TOC entry 216 (class 1259 OID 26804)
-- Name: migrations; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO sysnise;

--
-- TOC entry 215 (class 1259 OID 26803)
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO sysnise;

--
-- TOC entry 5565 (class 0 OID 0)
-- Dependencies: 215
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- TOC entry 278 (class 1259 OID 27198)
-- Name: nature_financements; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.nature_financements (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.nature_financements OWNER TO sysnise;

--
-- TOC entry 277 (class 1259 OID 27197)
-- Name: mode_financements_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.mode_financements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mode_financements_id_seq OWNER TO sysnise;

--
-- TOC entry 5566 (class 0 OID 0)
-- Dependencies: 277
-- Name: mode_financements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.mode_financements_id_seq OWNED BY public.nature_financements.id;


--
-- TOC entry 247 (class 1259 OID 26956)
-- Name: nature_donnees; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.nature_donnees (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.nature_donnees OWNER TO sysnise;

--
-- TOC entry 246 (class 1259 OID 26955)
-- Name: nature_donnees_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.nature_donnees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nature_donnees_id_seq OWNER TO sysnise;

--
-- TOC entry 5567 (class 0 OID 0)
-- Dependencies: 246
-- Name: nature_donnees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.nature_donnees_id_seq OWNED BY public.nature_donnees.id;


--
-- TOC entry 280 (class 1259 OID 27207)
-- Name: statut_financements; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.statut_financements (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.statut_financements OWNER TO sysnise;

--
-- TOC entry 279 (class 1259 OID 27206)
-- Name: niveau_financements_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.niveau_financements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.niveau_financements_id_seq OWNER TO sysnise;

--
-- TOC entry 5568 (class 0 OID 0)
-- Dependencies: 279
-- Name: niveau_financements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.niveau_financements_id_seq OWNED BY public.statut_financements.id;


--
-- TOC entry 237 (class 1259 OID 26915)
-- Name: orientation_cadre_developpements; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.orientation_cadre_developpements (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    cadre_developpement_id bigint NOT NULL,
    cadre_logique_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.orientation_cadre_developpements OWNER TO sysnise;

--
-- TOC entry 236 (class 1259 OID 26914)
-- Name: orientation_cadre_developpements_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.orientation_cadre_developpements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orientation_cadre_developpements_id_seq OWNER TO sysnise;

--
-- TOC entry 5569 (class 0 OID 0)
-- Dependencies: 236
-- Name: orientation_cadre_developpements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.orientation_cadre_developpements_id_seq OWNED BY public.orientation_cadre_developpements.id;


--
-- TOC entry 219 (class 1259 OID 26821)
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO sysnise;

--
-- TOC entry 249 (class 1259 OID 26965)
-- Name: periodes; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.periodes (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.periodes OWNER TO sysnise;

--
-- TOC entry 248 (class 1259 OID 26964)
-- Name: periodes_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.periodes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.periodes_id_seq OWNER TO sysnise;

--
-- TOC entry 5570 (class 0 OID 0)
-- Dependencies: 248
-- Name: periodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.periodes_id_seq OWNED BY public.periodes.id;


--
-- TOC entry 286 (class 1259 OID 27268)
-- Name: permission_role; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.permission_role (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.permission_role OWNER TO sysnise;

--
-- TOC entry 284 (class 1259 OID 27243)
-- Name: permissions; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    label character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.permissions OWNER TO sysnise;

--
-- TOC entry 283 (class 1259 OID 27242)
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permissions_id_seq OWNER TO sysnise;

--
-- TOC entry 5571 (class 0 OID 0)
-- Dependencies: 283
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- TOC entry 307 (class 1259 OID 27547)
-- Name: piece_jointe_activites; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.piece_jointe_activites (
    id integer NOT NULL,
    intitule character varying(255) NOT NULL,
    fichier character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    activite_id bigint
);


ALTER TABLE public.piece_jointe_activites OWNER TO sysnise;

--
-- TOC entry 306 (class 1259 OID 27546)
-- Name: piece_jointe_activites_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.piece_jointe_activites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.piece_jointe_activites_id_seq OWNER TO sysnise;

--
-- TOC entry 5572 (class 0 OID 0)
-- Dependencies: 306
-- Name: piece_jointe_activites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.piece_jointe_activites_id_seq OWNED BY public.piece_jointe_activites.id;


--
-- TOC entry 297 (class 1259 OID 27475)
-- Name: piece_jointe_produits; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.piece_jointe_produits (
    id integer NOT NULL,
    intitule character varying(255) NOT NULL,
    fichier character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    produit_id bigint
);


ALTER TABLE public.piece_jointe_produits OWNER TO sysnise;

--
-- TOC entry 296 (class 1259 OID 27474)
-- Name: piece_jointe_produits_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.piece_jointe_produits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.piece_jointe_produits_id_seq OWNER TO sysnise;

--
-- TOC entry 5573 (class 0 OID 0)
-- Dependencies: 296
-- Name: piece_jointe_produits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.piece_jointe_produits_id_seq OWNED BY public.piece_jointe_produits.id;


--
-- TOC entry 322 (class 1259 OID 27762)
-- Name: piece_jointe_projets; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.piece_jointe_projets (
    id integer NOT NULL,
    intitule character varying(255) NOT NULL,
    fichier character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    projet_id bigint
);


ALTER TABLE public.piece_jointe_projets OWNER TO sysnise;

--
-- TOC entry 321 (class 1259 OID 27761)
-- Name: piece_jointe_projets_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.piece_jointe_projets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.piece_jointe_projets_id_seq OWNER TO sysnise;

--
-- TOC entry 5574 (class 0 OID 0)
-- Dependencies: 321
-- Name: piece_jointe_projets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.piece_jointe_projets_id_seq OWNED BY public.piece_jointe_projets.id;


--
-- TOC entry 233 (class 1259 OID 26899)
-- Name: piece_jointes; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.piece_jointes (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    fichier character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    cadre_developpement_id bigint
);


ALTER TABLE public.piece_jointes OWNER TO sysnise;

--
-- TOC entry 232 (class 1259 OID 26898)
-- Name: piece_jointes_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.piece_jointes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.piece_jointes_id_seq OWNER TO sysnise;

--
-- TOC entry 5575 (class 0 OID 0)
-- Dependencies: 232
-- Name: piece_jointes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.piece_jointes_id_seq OWNED BY public.piece_jointes.id;


--
-- TOC entry 268 (class 1259 OID 27159)
-- Name: projet_population_cible; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.projet_population_cible (
    id bigint NOT NULL,
    projet_id bigint NOT NULL,
    population_cible_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    effectif bigint
);


ALTER TABLE public.projet_population_cible OWNER TO sysnise;

--
-- TOC entry 267 (class 1259 OID 27158)
-- Name: population_cible_projets_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.population_cible_projets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.population_cible_projets_id_seq OWNER TO sysnise;

--
-- TOC entry 5576 (class 0 OID 0)
-- Dependencies: 267
-- Name: population_cible_projets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.population_cible_projets_id_seq OWNED BY public.projet_population_cible.id;


--
-- TOC entry 266 (class 1259 OID 27150)
-- Name: population_cibles; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.population_cibles (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.population_cibles OWNER TO sysnise;

--
-- TOC entry 265 (class 1259 OID 27149)
-- Name: population_cibles_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.population_cibles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.population_cibles_id_seq OWNER TO sysnise;

--
-- TOC entry 5577 (class 0 OID 0)
-- Dependencies: 265
-- Name: population_cibles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.population_cibles_id_seq OWNED BY public.population_cibles.id;


--
-- TOC entry 262 (class 1259 OID 27132)
-- Name: priorites; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.priorites (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.priorites OWNER TO sysnise;

--
-- TOC entry 261 (class 1259 OID 27131)
-- Name: priorites_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.priorites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.priorites_id_seq OWNER TO sysnise;

--
-- TOC entry 5578 (class 0 OID 0)
-- Dependencies: 261
-- Name: priorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.priorites_id_seq OWNED BY public.priorites.id;


--
-- TOC entry 309 (class 1259 OID 27561)
-- Name: produit_zone; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.produit_zone (
    id integer NOT NULL,
    produit_id bigint NOT NULL,
    zone_id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.produit_zone OWNER TO sysnise;

--
-- TOC entry 308 (class 1259 OID 27560)
-- Name: produit_zone_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.produit_zone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.produit_zone_id_seq OWNER TO sysnise;

--
-- TOC entry 5579 (class 0 OID 0)
-- Dependencies: 308
-- Name: produit_zone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.produit_zone_id_seq OWNED BY public.produit_zone.id;


--
-- TOC entry 295 (class 1259 OID 27445)
-- Name: produits; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.produits (
    id integer NOT NULL,
    cadre_logique_id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    annee_debut_prevu integer,
    annee_fin_prevu integer,
    duree_travaux integer,
    cout_prevu integer,
    responsable character varying(255),
    contact_responsable character varying(255),
    statut_produit_id bigint,
    description character varying(255),
    date_debut_realisation date,
    date_fin_realisation date,
    cout_realisation integer,
    latitude double precision,
    longitude double precision,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    type_produit_id bigint
);


ALTER TABLE public.produits OWNER TO sysnise;

--
-- TOC entry 294 (class 1259 OID 27444)
-- Name: produits_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.produits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.produits_id_seq OWNER TO sysnise;

--
-- TOC entry 5580 (class 0 OID 0)
-- Dependencies: 294
-- Name: produits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.produits_id_seq OWNED BY public.produits.id;


--
-- TOC entry 320 (class 1259 OID 27743)
-- Name: projet_cadre_logique; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.projet_cadre_logique (
    id integer NOT NULL,
    projet_id bigint NOT NULL,
    cadre_logique_id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.projet_cadre_logique OWNER TO sysnise;

--
-- TOC entry 319 (class 1259 OID 27742)
-- Name: projet_cadre_logique_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.projet_cadre_logique_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projet_cadre_logique_id_seq OWNER TO sysnise;

--
-- TOC entry 5581 (class 0 OID 0)
-- Dependencies: 319
-- Name: projet_cadre_logique_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.projet_cadre_logique_id_seq OWNED BY public.projet_cadre_logique.id;


--
-- TOC entry 324 (class 1259 OID 27781)
-- Name: projet_etude_disponible; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.projet_etude_disponible (
    id integer NOT NULL,
    projet_id bigint NOT NULL,
    etude_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    fichier character varying(255) NOT NULL
);


ALTER TABLE public.projet_etude_disponible OWNER TO sysnise;

--
-- TOC entry 323 (class 1259 OID 27780)
-- Name: projet_etude_disponible_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.projet_etude_disponible_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projet_etude_disponible_id_seq OWNER TO sysnise;

--
-- TOC entry 5582 (class 0 OID 0)
-- Dependencies: 323
-- Name: projet_etude_disponible_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.projet_etude_disponible_id_seq OWNED BY public.projet_etude_disponible.id;


--
-- TOC entry 326 (class 1259 OID 27788)
-- Name: projet_etude_envisagee; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.projet_etude_envisagee (
    id integer NOT NULL,
    projet_id bigint NOT NULL,
    etude_id bigint NOT NULL,
    source_financement_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.projet_etude_envisagee OWNER TO sysnise;

--
-- TOC entry 325 (class 1259 OID 27787)
-- Name: projet_etude_envisagee_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.projet_etude_envisagee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projet_etude_envisagee_id_seq OWNER TO sysnise;

--
-- TOC entry 5583 (class 0 OID 0)
-- Dependencies: 325
-- Name: projet_etude_envisagee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.projet_etude_envisagee_id_seq OWNED BY public.projet_etude_envisagee.id;


--
-- TOC entry 330 (class 1259 OID 27816)
-- Name: projet_financement; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.projet_financement (
    id bigint NOT NULL,
    projet_id bigint NOT NULL,
    source_financement_id bigint NOT NULL,
    ptf_id bigint,
    statut_financement_id bigint,
    nature_financement_id bigint,
    montant numeric(15,2),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.projet_financement OWNER TO sysnise;

--
-- TOC entry 329 (class 1259 OID 27815)
-- Name: projet_financement_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.projet_financement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projet_financement_id_seq OWNER TO sysnise;

--
-- TOC entry 5584 (class 0 OID 0)
-- Dependencies: 329
-- Name: projet_financement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.projet_financement_id_seq OWNED BY public.projet_financement.id;


--
-- TOC entry 318 (class 1259 OID 27724)
-- Name: projet_zone; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.projet_zone (
    id integer NOT NULL,
    projet_id bigint NOT NULL,
    zone_id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.projet_zone OWNER TO sysnise;

--
-- TOC entry 317 (class 1259 OID 27723)
-- Name: projet_zone_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.projet_zone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projet_zone_id_seq OWNER TO sysnise;

--
-- TOC entry 5585 (class 0 OID 0)
-- Dependencies: 317
-- Name: projet_zone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.projet_zone_id_seq OWNED BY public.projet_zone.id;


--
-- TOC entry 260 (class 1259 OID 27116)
-- Name: projets; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.projets (
    id bigint NOT NULL,
    sigle character varying(255) NOT NULL,
    intitule character varying(255) NOT NULL,
    priorite_id bigint,
    institution_tutelle_id bigint,
    direction_agence character varying(255),
    contact character varying(255),
    cout double precision,
    annee_demarrage integer,
    date_debut_prevue date,
    date_fin_prevue date,
    duree integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    statut_projet_id bigint,
    date_debut_effective date,
    date_fin_effective date,
    projet_id bigint,
    cadre_developpement_id bigint
);


ALTER TABLE public.projets OWNER TO sysnise;

--
-- TOC entry 259 (class 1259 OID 27115)
-- Name: projets_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.projets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projets_id_seq OWNER TO sysnise;

--
-- TOC entry 5586 (class 0 OID 0)
-- Dependencies: 259
-- Name: projets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.projets_id_seq OWNED BY public.projets.id;


--
-- TOC entry 328 (class 1259 OID 27795)
-- Name: ptfs; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.ptfs (
    id integer NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ptfs OWNER TO sysnise;

--
-- TOC entry 327 (class 1259 OID 27794)
-- Name: ptfs_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.ptfs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ptfs_id_seq OWNER TO sysnise;

--
-- TOC entry 5587 (class 0 OID 0)
-- Dependencies: 327
-- Name: ptfs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.ptfs_id_seq OWNED BY public.ptfs.id;


--
-- TOC entry 272 (class 1259 OID 27173)
-- Name: recherche_financements; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.recherche_financements (
    id bigint NOT NULL,
    projet_id bigint NOT NULL,
    source_financement_id bigint NOT NULL,
    niveau_financement_id bigint NOT NULL,
    mode_financement_id bigint NOT NULL,
    bailleurs character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.recherche_financements OWNER TO sysnise;

--
-- TOC entry 271 (class 1259 OID 27172)
-- Name: recherche_financements_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.recherche_financements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recherche_financements_id_seq OWNER TO sysnise;

--
-- TOC entry 5588 (class 0 OID 0)
-- Dependencies: 271
-- Name: recherche_financements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.recherche_financements_id_seq OWNED BY public.recherche_financements.id;


--
-- TOC entry 285 (class 1259 OID 27253)
-- Name: role_user; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.role_user (
    role_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.role_user OWNER TO sysnise;

--
-- TOC entry 282 (class 1259 OID 27232)
-- Name: roles; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    label character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO sysnise;

--
-- TOC entry 281 (class 1259 OID 27231)
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO sysnise;

--
-- TOC entry 5589 (class 0 OID 0)
-- Dependencies: 281
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- TOC entry 220 (class 1259 OID 26828)
-- Name: sessions; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO sysnise;

--
-- TOC entry 276 (class 1259 OID 27189)
-- Name: source_financements; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.source_financements (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.source_financements OWNER TO sysnise;

--
-- TOC entry 275 (class 1259 OID 27188)
-- Name: source_financements_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.source_financements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.source_financements_id_seq OWNER TO sysnise;

--
-- TOC entry 5590 (class 0 OID 0)
-- Dependencies: 275
-- Name: source_financements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.source_financements_id_seq OWNED BY public.source_financements.id;


--
-- TOC entry 251 (class 1259 OID 26974)
-- Name: source_indicateurs; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.source_indicateurs (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.source_indicateurs OWNER TO sysnise;

--
-- TOC entry 250 (class 1259 OID 26973)
-- Name: source_indicateurs_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.source_indicateurs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.source_indicateurs_id_seq OWNER TO sysnise;

--
-- TOC entry 5591 (class 0 OID 0)
-- Dependencies: 250
-- Name: source_indicateurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.source_indicateurs_id_seq OWNED BY public.source_indicateurs.id;


--
-- TOC entry 303 (class 1259 OID 27512)
-- Name: statut_activites; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.statut_activites (
    id integer NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.statut_activites OWNER TO sysnise;

--
-- TOC entry 302 (class 1259 OID 27511)
-- Name: statut_activites_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.statut_activites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.statut_activites_id_seq OWNER TO sysnise;

--
-- TOC entry 5592 (class 0 OID 0)
-- Dependencies: 302
-- Name: statut_activites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.statut_activites_id_seq OWNED BY public.statut_activites.id;


--
-- TOC entry 293 (class 1259 OID 27425)
-- Name: statut_produits; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.statut_produits (
    id integer NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.statut_produits OWNER TO sysnise;

--
-- TOC entry 292 (class 1259 OID 27424)
-- Name: statut_produits_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.statut_produits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.statut_produits_id_seq OWNER TO sysnise;

--
-- TOC entry 5593 (class 0 OID 0)
-- Dependencies: 292
-- Name: statut_produits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.statut_produits_id_seq OWNED BY public.statut_produits.id;


--
-- TOC entry 316 (class 1259 OID 27715)
-- Name: statut_projets; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.statut_projets (
    id integer NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.statut_projets OWNER TO sysnise;

--
-- TOC entry 315 (class 1259 OID 27714)
-- Name: statut_projets_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.statut_projets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.statut_projets_id_seq OWNER TO sysnise;

--
-- TOC entry 5594 (class 0 OID 0)
-- Dependencies: 315
-- Name: statut_projets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.statut_projets_id_seq OWNED BY public.statut_projets.id;


--
-- TOC entry 301 (class 1259 OID 27503)
-- Name: type_activites; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.type_activites (
    id integer NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.type_activites OWNER TO sysnise;

--
-- TOC entry 300 (class 1259 OID 27502)
-- Name: type_activites_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.type_activites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.type_activites_id_seq OWNER TO sysnise;

--
-- TOC entry 5595 (class 0 OID 0)
-- Dependencies: 300
-- Name: type_activites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.type_activites_id_seq OWNED BY public.type_activites.id;


--
-- TOC entry 245 (class 1259 OID 26947)
-- Name: type_desagregations; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.type_desagregations (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.type_desagregations OWNER TO sysnise;

--
-- TOC entry 244 (class 1259 OID 26946)
-- Name: type_desagregations_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.type_desagregations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.type_desagregations_id_seq OWNER TO sysnise;

--
-- TOC entry 5596 (class 0 OID 0)
-- Dependencies: 244
-- Name: type_desagregations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.type_desagregations_id_seq OWNED BY public.type_desagregations.id;


--
-- TOC entry 299 (class 1259 OID 27489)
-- Name: type_produits; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.type_produits (
    id integer NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.type_produits OWNER TO sysnise;

--
-- TOC entry 298 (class 1259 OID 27488)
-- Name: type_produits_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.type_produits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.type_produits_id_seq OWNER TO sysnise;

--
-- TOC entry 5597 (class 0 OID 0)
-- Dependencies: 298
-- Name: type_produits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.type_produits_id_seq OWNED BY public.type_produits.id;


--
-- TOC entry 253 (class 1259 OID 26983)
-- Name: unite_indicateurs; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.unite_indicateurs (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.unite_indicateurs OWNER TO sysnise;

--
-- TOC entry 252 (class 1259 OID 26982)
-- Name: unite_indicateurs_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.unite_indicateurs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.unite_indicateurs_id_seq OWNER TO sysnise;

--
-- TOC entry 5598 (class 0 OID 0)
-- Dependencies: 252
-- Name: unite_indicateurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.unite_indicateurs_id_seq OWNED BY public.unite_indicateurs.id;


--
-- TOC entry 218 (class 1259 OID 26811)
-- Name: users; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO sysnise;

--
-- TOC entry 217 (class 1259 OID 26810)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO sysnise;

--
-- TOC entry 5599 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 314 (class 1259 OID 27706)
-- Name: view_cadre_logique; Type: VIEW; Schema: public; Owner: sysnise
--

CREATE VIEW public.view_cadre_logique AS
 WITH RECURSIVE nodes AS (
         SELECT cd.id,
            cd.intitule,
            NULL::bigint AS parent_id,
            1 AS niveau,
            cd.id AS cadre_developpement_id
           FROM public.cadre_developpements cd
        UNION ALL
         SELECT cl.id,
            cl.intitule,
            ocd.cadre_developpement_id AS parent_id,
            2 AS niveau,
            ocd.cadre_developpement_id
           FROM (public.orientation_cadre_developpements ocd
             JOIN public.cadre_logiques cl ON ((cl.id = ocd.cadre_logique_id)))
        UNION ALL
         SELECT cl_child.id,
            cl_child.intitule,
            cl_child.cadre_logique_id AS parent_id,
            (n_1.niveau + 1) AS niveau,
            n_1.cadre_developpement_id
           FROM (public.cadre_logiques cl_child
             JOIN nodes n_1 ON ((cl_child.cadre_logique_id = n_1.id)))
        )
 SELECT cadre_developpement_id,
    id,
    intitule,
    parent_id,
    niveau
   FROM nodes n;


ALTER VIEW public.view_cadre_logique OWNER TO sysnise;

--
-- TOC entry 312 (class 1259 OID 27652)
-- Name: view_chaine_logique2; Type: VIEW; Schema: public; Owner: sysnise
--

CREATE VIEW public.view_chaine_logique2 AS
 WITH developpements AS (
         SELECT cd.id,
            cd.intitule,
            NULL::bigint AS parent_id
           FROM public.cadre_developpements cd
        ), logiques_niveau2 AS (
         SELECT cl.id,
            cl.intitule,
            ocd.cadre_developpement_id AS parent_id
           FROM (public.cadre_logiques cl
             JOIN public.orientation_cadre_developpements ocd ON ((cl.id = ocd.cadre_logique_id)))
        ), logiques_suivants AS (
         SELECT cl.id,
            cl.intitule,
            cl.cadre_logique_id AS parent_id
           FROM public.cadre_logiques cl
          WHERE (cl.cadre_logique_id IS NOT NULL)
        )
 SELECT developpements.id,
    developpements.intitule,
    developpements.parent_id
   FROM developpements
UNION ALL
 SELECT logiques_niveau2.id,
    logiques_niveau2.intitule,
    logiques_niveau2.parent_id
   FROM logiques_niveau2
UNION ALL
 SELECT logiques_suivants.id,
    logiques_suivants.intitule,
    logiques_suivants.parent_id
   FROM logiques_suivants
  ORDER BY 3 NULLS FIRST, 1;


ALTER VIEW public.view_chaine_logique2 OWNER TO sysnise;

--
-- TOC entry 229 (class 1259 OID 26881)
-- Name: zones; Type: TABLE; Schema: public; Owner: sysnise
--

CREATE TABLE public.zones (
    id bigint NOT NULL,
    intitule character varying(255) NOT NULL,
    code character varying(255),
    latitude double precision,
    longitude double precision,
    zone_id bigint,
    niveau integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.zones OWNER TO sysnise;

--
-- TOC entry 313 (class 1259 OID 27696)
-- Name: view_cmr; Type: VIEW; Schema: public; Owner: sysnise
--

CREATE VIEW public.view_cmr AS
 WITH RECURSIVE nodes AS (
         SELECT cd.id AS cadre_id,
            cd.intitule,
            NULL::bigint AS parent_id,
            1 AS niveau,
            cd.id AS cadre_developpement_id
           FROM public.cadre_developpements cd
        UNION ALL
         SELECT cl.id AS cadre_id,
            cl.intitule,
            ocd.cadre_developpement_id AS parent_id,
            2 AS niveau,
            ocd.cadre_developpement_id
           FROM (public.orientation_cadre_developpements ocd
             JOIN public.cadre_logiques cl ON ((cl.id = ocd.cadre_logique_id)))
        UNION ALL
         SELECT cl_child.id AS cadre_id,
            cl_child.intitule,
            cl_child.cadre_logique_id AS parent_id,
            (n_1.niveau + 1) AS niveau,
            n_1.cadre_developpement_id
           FROM (public.cadre_logiques cl_child
             JOIN nodes n_1 ON ((cl_child.cadre_logique_id = n_1.cadre_id)))
        )
 SELECT n.cadre_developpement_id,
    n.cadre_id,
    n.intitule AS cadre_intitule,
    n.parent_id,
    n.niveau,
    i.id AS indicateur_id,
    i.intitule AS indicateur_intitule,
    di.valeur,
    z.intitule AS zone_intitule,
    u.intitule AS unite_intitule,
    s.intitule AS source_intitule,
    nd.intitule AS nature_donnee_intitule,
    p.intitule AS periode_intitule,
    string_agg(DISTINCT (dsg.intitule)::text, ', '::text) AS desagregations
   FROM ((((((((((nodes n
     LEFT JOIN public.cadre_mesure_resultats cmr ON ((cmr.cadre_logique_id = n.cadre_id)))
     LEFT JOIN public.indicateurs i ON ((i.id = cmr.indicateur_id)))
     LEFT JOIN public.donnee_indicateurs di ON ((di.indicateur_id = i.id)))
     LEFT JOIN public.zones z ON ((z.id = di.zone_id)))
     LEFT JOIN public.unite_indicateurs u ON ((u.id = di.unite_indicateur_id)))
     LEFT JOIN public.source_indicateurs s ON ((s.id = di.source_indicateur_id)))
     LEFT JOIN public.nature_donnees nd ON ((nd.id = di.nature_donnee_id)))
     LEFT JOIN public.periodes p ON ((p.id = di.periode_id)))
     LEFT JOIN public.donnee_indicateur_desagregation did ON ((did.donnee_indicateur_id = di.id)))
     LEFT JOIN public.desagregations dsg ON ((dsg.id = did.desagregation_id)))
  WHERE (n.niveau >= 2)
  GROUP BY n.cadre_developpement_id, n.cadre_id, n.intitule, n.parent_id, n.niveau, i.id, i.intitule, di.valeur, z.intitule, u.intitule, s.intitule, nd.intitule, p.intitule
  ORDER BY n.cadre_developpement_id, n.parent_id NULLS FIRST, n.cadre_id, i.id;


ALTER VIEW public.view_cmr OWNER TO sysnise;

--
-- TOC entry 289 (class 1259 OID 27390)
-- Name: view_extraction_donnees; Type: VIEW; Schema: public; Owner: sysnise
--

CREATE VIEW public.view_extraction_donnees AS
 SELECT di.id,
    di.nature_donnee_id,
    nd.intitule AS nature_donnee_intitule,
    di.indicateur_id,
    i.intitule AS indicateur_intitule,
    di.zone_id,
    z.intitule AS zone_intitule,
    di.source_indicateur_id,
    si.intitule AS source_indicateur_intitule,
    di.unite_indicateur_id,
    ui.intitule AS unite_indicateur_intitule,
    di.commentaire_valeur_indicateur_id,
    cvi.intitule AS commentaire_intitule,
    di.periode_id,
    p.intitule AS periode_intitule,
    di.valeur,
    string_agg(DISTINCT (d.id)::text, ', '::text) AS desagregation_ids,
    string_agg(DISTINCT (d.intitule)::text, ', '::text) AS desagregations
   FROM (((((((((public.donnee_indicateurs di
     LEFT JOIN public.nature_donnees nd ON ((di.nature_donnee_id = nd.id)))
     LEFT JOIN public.indicateurs i ON ((di.indicateur_id = i.id)))
     LEFT JOIN public.zones z ON ((di.zone_id = z.id)))
     LEFT JOIN public.periodes p ON ((di.periode_id = p.id)))
     LEFT JOIN public.source_indicateurs si ON ((di.source_indicateur_id = si.id)))
     LEFT JOIN public.unite_indicateurs ui ON ((di.unite_indicateur_id = ui.id)))
     LEFT JOIN public.commentaire_valeur_indicateurs cvi ON ((di.commentaire_valeur_indicateur_id = cvi.id)))
     LEFT JOIN public.donnee_indicateur_desagregation did ON ((di.id = did.donnee_indicateur_id)))
     LEFT JOIN public.desagregations d ON ((did.desagregation_id = d.id)))
  GROUP BY di.id, di.nature_donnee_id, nd.intitule, di.indicateur_id, i.intitule, di.zone_id, z.intitule, di.source_indicateur_id, si.intitule, di.unite_indicateur_id, ui.intitule, di.commentaire_valeur_indicateur_id, cvi.intitule, di.periode_id, p.intitule, di.valeur
  ORDER BY i.intitule, z.intitule, p.intitule;


ALTER VIEW public.view_extraction_donnees OWNER TO sysnise;

--
-- TOC entry 228 (class 1259 OID 26880)
-- Name: zones_id_seq; Type: SEQUENCE; Schema: public; Owner: sysnise
--

CREATE SEQUENCE public.zones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zones_id_seq OWNER TO sysnise;

--
-- TOC entry 5600 (class 0 OID 0)
-- Dependencies: 228
-- Name: zones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sysnise
--

ALTER SEQUENCE public.zones_id_seq OWNED BY public.zones.id;


--
-- TOC entry 5049 (class 2604 OID 27584)
-- Name: activite_zone id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.activite_zone ALTER COLUMN id SET DEFAULT nextval('public.activite_zone_id_seq'::regclass);


--
-- TOC entry 5042 (class 2604 OID 27524)
-- Name: activites id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.activites ALTER COLUMN id SET DEFAULT nextval('public.activites_id_seq'::regclass);


--
-- TOC entry 4997 (class 2604 OID 26893)
-- Name: cadre_developpements id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.cadre_developpements ALTER COLUMN id SET DEFAULT nextval('public.cadre_developpements_id_seq'::regclass);


--
-- TOC entry 5000 (class 2604 OID 26911)
-- Name: cadre_logiques id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.cadre_logiques ALTER COLUMN id SET DEFAULT nextval('public.cadre_logiques_id_seq'::regclass);


--
-- TOC entry 5010 (class 2604 OID 26995)
-- Name: commentaire_valeur_indicateurs id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.commentaire_valeur_indicateurs ALTER COLUMN id SET DEFAULT nextval('public.commentaire_valeur_indicateurs_id_seq'::regclass);


--
-- TOC entry 5014 (class 2604 OID 27086)
-- Name: desagregation_indicateur id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.desagregation_indicateur ALTER COLUMN id SET DEFAULT nextval('public.desagregation_indicateur_id_seq'::regclass);


--
-- TOC entry 5004 (class 2604 OID 26941)
-- Name: desagregations id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.desagregations ALTER COLUMN id SET DEFAULT nextval('public.desagregations_id_seq'::regclass);


--
-- TOC entry 5028 (class 2604 OID 27363)
-- Name: donnee_indicateur_desagregation id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateur_desagregation ALTER COLUMN id SET DEFAULT nextval('public.donnee_indicateur_desagregation_id_seq'::regclass);


--
-- TOC entry 5003 (class 2604 OID 26934)
-- Name: donnee_indicateurs id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateurs ALTER COLUMN id SET DEFAULT nextval('public.donnee_indicateurs_id_seq'::regclass);


--
-- TOC entry 5020 (class 2604 OID 27169)
-- Name: etude_identifications id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.etude_identifications ALTER COLUMN id SET DEFAULT nextval('public.etude_identifications_id_seq'::regclass);


--
-- TOC entry 5022 (class 2604 OID 27183)
-- Name: etudes id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.etudes ALTER COLUMN id SET DEFAULT nextval('public.etudes_id_seq'::regclass);


--
-- TOC entry 4994 (class 2604 OID 26872)
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- TOC entry 5031 (class 2604 OID 27409)
-- Name: hypothese_risques id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.hypothese_risques ALTER COLUMN id SET DEFAULT nextval('public.hypothese_risques_id_seq'::regclass);


--
-- TOC entry 5002 (class 2604 OID 26925)
-- Name: indicateurs id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.indicateurs ALTER COLUMN id SET DEFAULT nextval('public.indicateurs_id_seq'::regclass);


--
-- TOC entry 5017 (class 2604 OID 27144)
-- Name: institution_tutelles id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.institution_tutelles ALTER COLUMN id SET DEFAULT nextval('public.institution_tutelles_id_seq'::regclass);


--
-- TOC entry 4993 (class 2604 OID 26855)
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- TOC entry 4991 (class 2604 OID 26807)
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- TOC entry 5006 (class 2604 OID 26959)
-- Name: nature_donnees id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.nature_donnees ALTER COLUMN id SET DEFAULT nextval('public.nature_donnees_id_seq'::regclass);


--
-- TOC entry 5024 (class 2604 OID 27201)
-- Name: nature_financements id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.nature_financements ALTER COLUMN id SET DEFAULT nextval('public.mode_financements_id_seq'::regclass);


--
-- TOC entry 5001 (class 2604 OID 26918)
-- Name: orientation_cadre_developpements id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.orientation_cadre_developpements ALTER COLUMN id SET DEFAULT nextval('public.orientation_cadre_developpements_id_seq'::regclass);


--
-- TOC entry 5007 (class 2604 OID 26968)
-- Name: periodes id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.periodes ALTER COLUMN id SET DEFAULT nextval('public.periodes_id_seq'::regclass);


--
-- TOC entry 5027 (class 2604 OID 27246)
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- TOC entry 5045 (class 2604 OID 27550)
-- Name: piece_jointe_activites id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointe_activites ALTER COLUMN id SET DEFAULT nextval('public.piece_jointe_activites_id_seq'::regclass);


--
-- TOC entry 5038 (class 2604 OID 27478)
-- Name: piece_jointe_produits id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointe_produits ALTER COLUMN id SET DEFAULT nextval('public.piece_jointe_produits_id_seq'::regclass);


--
-- TOC entry 5059 (class 2604 OID 27765)
-- Name: piece_jointe_projets id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointe_projets ALTER COLUMN id SET DEFAULT nextval('public.piece_jointe_projets_id_seq'::regclass);


--
-- TOC entry 4999 (class 2604 OID 26902)
-- Name: piece_jointes id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointes ALTER COLUMN id SET DEFAULT nextval('public.piece_jointes_id_seq'::regclass);


--
-- TOC entry 5018 (class 2604 OID 27153)
-- Name: population_cibles id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.population_cibles ALTER COLUMN id SET DEFAULT nextval('public.population_cibles_id_seq'::regclass);


--
-- TOC entry 5016 (class 2604 OID 27135)
-- Name: priorites id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.priorites ALTER COLUMN id SET DEFAULT nextval('public.priorites_id_seq'::regclass);


--
-- TOC entry 5046 (class 2604 OID 27564)
-- Name: produit_zone id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.produit_zone ALTER COLUMN id SET DEFAULT nextval('public.produit_zone_id_seq'::regclass);


--
-- TOC entry 5035 (class 2604 OID 27448)
-- Name: produits id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.produits ALTER COLUMN id SET DEFAULT nextval('public.produits_id_seq'::regclass);


--
-- TOC entry 5056 (class 2604 OID 27746)
-- Name: projet_cadre_logique id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_cadre_logique ALTER COLUMN id SET DEFAULT nextval('public.projet_cadre_logique_id_seq'::regclass);


--
-- TOC entry 5060 (class 2604 OID 27784)
-- Name: projet_etude_disponible id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_etude_disponible ALTER COLUMN id SET DEFAULT nextval('public.projet_etude_disponible_id_seq'::regclass);


--
-- TOC entry 5061 (class 2604 OID 27791)
-- Name: projet_etude_envisagee id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_etude_envisagee ALTER COLUMN id SET DEFAULT nextval('public.projet_etude_envisagee_id_seq'::regclass);


--
-- TOC entry 5063 (class 2604 OID 27819)
-- Name: projet_financement id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_financement ALTER COLUMN id SET DEFAULT nextval('public.projet_financement_id_seq'::regclass);


--
-- TOC entry 5019 (class 2604 OID 27162)
-- Name: projet_population_cible id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_population_cible ALTER COLUMN id SET DEFAULT nextval('public.population_cible_projets_id_seq'::regclass);


--
-- TOC entry 5053 (class 2604 OID 27727)
-- Name: projet_zone id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_zone ALTER COLUMN id SET DEFAULT nextval('public.projet_zone_id_seq'::regclass);


--
-- TOC entry 5015 (class 2604 OID 27119)
-- Name: projets id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projets ALTER COLUMN id SET DEFAULT nextval('public.projets_id_seq'::regclass);


--
-- TOC entry 5062 (class 2604 OID 27798)
-- Name: ptfs id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.ptfs ALTER COLUMN id SET DEFAULT nextval('public.ptfs_id_seq'::regclass);


--
-- TOC entry 5021 (class 2604 OID 27176)
-- Name: recherche_financements id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.recherche_financements ALTER COLUMN id SET DEFAULT nextval('public.recherche_financements_id_seq'::regclass);


--
-- TOC entry 5026 (class 2604 OID 27235)
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- TOC entry 5023 (class 2604 OID 27192)
-- Name: source_financements id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.source_financements ALTER COLUMN id SET DEFAULT nextval('public.source_financements_id_seq'::regclass);


--
-- TOC entry 5008 (class 2604 OID 26977)
-- Name: source_indicateurs id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.source_indicateurs ALTER COLUMN id SET DEFAULT nextval('public.source_indicateurs_id_seq'::regclass);


--
-- TOC entry 5041 (class 2604 OID 27515)
-- Name: statut_activites id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_activites ALTER COLUMN id SET DEFAULT nextval('public.statut_activites_id_seq'::regclass);


--
-- TOC entry 5025 (class 2604 OID 27210)
-- Name: statut_financements id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_financements ALTER COLUMN id SET DEFAULT nextval('public.niveau_financements_id_seq'::regclass);


--
-- TOC entry 5034 (class 2604 OID 27428)
-- Name: statut_produits id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_produits ALTER COLUMN id SET DEFAULT nextval('public.statut_produits_id_seq'::regclass);


--
-- TOC entry 5052 (class 2604 OID 27718)
-- Name: statut_projets id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_projets ALTER COLUMN id SET DEFAULT nextval('public.statut_projets_id_seq'::regclass);


--
-- TOC entry 5040 (class 2604 OID 27506)
-- Name: type_activites id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.type_activites ALTER COLUMN id SET DEFAULT nextval('public.type_activites_id_seq'::regclass);


--
-- TOC entry 5005 (class 2604 OID 26950)
-- Name: type_desagregations id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.type_desagregations ALTER COLUMN id SET DEFAULT nextval('public.type_desagregations_id_seq'::regclass);


--
-- TOC entry 5039 (class 2604 OID 27492)
-- Name: type_produits id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.type_produits ALTER COLUMN id SET DEFAULT nextval('public.type_produits_id_seq'::regclass);


--
-- TOC entry 5009 (class 2604 OID 26986)
-- Name: unite_indicateurs id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.unite_indicateurs ALTER COLUMN id SET DEFAULT nextval('public.unite_indicateurs_id_seq'::regclass);


--
-- TOC entry 4992 (class 2604 OID 26814)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 4996 (class 2604 OID 26884)
-- Name: zones id; Type: DEFAULT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.zones ALTER COLUMN id SET DEFAULT nextval('public.zones_id_seq'::regclass);


--
-- TOC entry 5525 (class 0 OID 27581)
-- Dependencies: 311
-- Data for Name: activite_zone; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.activite_zone (id, activite_id, zone_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5519 (class 0 OID 27521)
-- Dependencies: 305
-- Data for Name: activites; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.activites (id, cadre_logique_id, intitule, annee_debut_prevu, annee_fin_prevu, duree_travaux, cout_prevu, responsable, contact_responsable, statut_activite_id, description, date_debut_realisation, date_fin_realisation, cout_realisation, latitude, longitude, activite_id, created_at, updated_at, type_activite_id) FROM stdin;
\.


--
-- TOC entry 5436 (class 0 OID 26837)
-- Dependencies: 221
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- TOC entry 5437 (class 0 OID 26844)
-- Dependencies: 222
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- TOC entry 5446 (class 0 OID 26890)
-- Dependencies: 231
-- Data for Name: cadre_developpements; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.cadre_developpements (id, intitule, structure_responsable, annee_debut, annee_fin, description, cadre_developpement_id, created_at, updated_at, type_cadre_developpement_id) FROM stdin;
11	PRR	MEF	2025	2029	\N	\N	2025-11-04 16:39:18	2025-11-04 16:39:18	1
14	Kandadji	DGPPD	2020	2027	RASS	\N	2025-11-09 01:41:49	2025-11-09 12:21:44	2
15	PRR10	MEF	2025	2029	\N	\N	2025-11-12 15:41:51	2025-11-12 15:41:51	2
16	PHASAOC	INS/DCMIS	2025	2025	\N	\N	2025-11-12 16:50:43	2025-11-12 16:50:43	2
17	PRR11	DGPPD	2025	2029	\N	\N	2025-11-13 08:45:44	2025-11-13 08:45:44	1
\.


--
-- TOC entry 5450 (class 0 OID 26908)
-- Dependencies: 235
-- Data for Name: cadre_logiques; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.cadre_logiques (id, intitule, niveau, cadre_logique_id, created_at, updated_at) FROM stdin;
122	CMR PRR	\N	0	2025-11-12 15:42:16	2025-11-12 15:42:49
123	Logique d'intervention PRR	\N	\N	2025-11-12 15:43:03	2025-11-12 15:43:03
98	CMR du PRR	\N	\N	2025-11-04 16:39:40	2025-11-04 16:39:40
99	Impact : les conditions de vie des populations sont améliorées de manière durable	\N	98	2025-11-04 16:40:03	2025-11-04 16:40:03
100	Changement Global 1 : la défense et la sécurité des personnes et des biens sont améliorées tout en préservant les intérêts fondamentaux du Niger	\N	99	2025-11-04 16:40:22	2025-11-04 16:40:22
101	Changement Global 2 : les populations sont bien gouvernées de manière transparente, inclusive et redevable	\N	99	2025-11-04 16:40:45	2025-11-04 16:40:45
102	Changement Global 3 : La croissance économique inclusive et créatrice d’emplois pour la souveraineté économique est améliorée	\N	99	2025-11-04 16:41:05	2025-11-04 16:41:05
103	Changement Global 4 : l’offre des services sociaux et de la protection sociale est améliorée à travers notamment des reformes appropriées	\N	99	2025-11-04 16:41:57	2025-11-04 16:41:57
104	Changement intermédiaire 1.1 : La défense nationale et la sécurisation du territoire sont renforcées	\N	100	2025-11-04 16:42:42	2025-11-04 16:42:42
105	Changement intermédiaire 1.2 : Les conditions pour une paix durable et une cohésion sociale plus forte au sein des communautés sont établies tout en consolidant l’unité nationale	\N	100	2025-11-04 16:43:05	2025-11-04 16:43:05
106	Changement intermédiaire 2.1 : L’accès des citoyens aux services judiciaires de qualité est renforcé, garantissant une justice indépendante et efficace	\N	101	2025-11-04 16:43:25	2025-11-04 16:43:25
107	Changement intermédiaire 2.2 : La performance de l’administration publique (centrale et locale) est améliorée via la modernisation des processus, la promotion du mérite et la lutte contre la corruption	\N	101	2025-11-04 16:43:43	2025-11-04 16:43:43
108	Changement intermédiaire 2.3 : Le cadre politique et institutionnel, participatif et souverain, favorisant la stabilité démocratique est opérationnel	\N	101	2025-11-04 16:44:30	2025-11-04 16:44:30
109	Changement intermédiaire 2.4 : les fondements d’une identité nationale sont renforcés, favorisant la paix et la résilience sociale	\N	101	2025-11-04 16:44:45	2025-11-04 16:44:45
110	Changement intermédiaire 3.1 :  la gestion de l’économie est améliorée	\N	102	2025-11-04 16:45:11	2025-11-04 16:45:11
111	Changement intermédiaire 3.2 :  Les conditions pour une souveraineté alimentaire progressive sont créées	\N	102	2025-11-04 16:45:24	2025-11-04 16:45:24
112	Changement intermédiaire 3.3 : Les approches innovantes pour l’écoulement des produits agricoles sont développées	\N	102	2025-11-04 16:45:51	2025-11-04 16:45:51
113	Changement intermédiaire 3.4 : Les chaines de valeur minières et pétrolières sont développées	\N	102	2025-11-04 16:46:04	2025-11-04 16:46:04
114	Changement intermédiaire 3.5 : Les acteurs économiques bénéficient des services énergétiques, de transport et de TIC de qualité	\N	102	2025-11-04 16:46:20	2025-11-04 16:46:20
115	Changement intermédiaire 4.1 : Le système éducatif nigérien est adapté aux besoins d’insertion socio – économique des populations	\N	103	2025-11-04 16:46:43	2025-11-04 16:46:43
116	Changement intermédiaire 4.2 : les recherches fondamentale et appliquée sont valorisées	\N	103	2025-11-04 16:46:56	2025-11-04 16:46:56
117	Changement intermédiaire 4.3 : Les populations ont accès équitablement aux services de santé et d’hygiène de qualité	\N	103	2025-11-04 16:47:16	2025-11-04 16:47:16
118	Changement intermédiaire 4.4 : Un système de protection sociale dynamique et adapté à la prévention et à la prise en charge efficace des situations de vulnérabilité est opérationnel	\N	103	2025-11-04 16:47:41	2025-11-04 16:47:41
119	Changement intermédiaire 4.5 les conditions favorables à la protection, à l’employabilité et à l’entrepreneuriat des jeunes sont créées	\N	103	2025-11-04 16:47:55	2025-11-04 16:47:55
120	Changement intermédiaire 4.6 : Les populations ont accès à l’eau potable de qualité et un cadre de vie sain	\N	103	2025-11-04 16:48:15	2025-11-04 16:48:15
124	Impact	\N	122	2025-11-12 15:43:10	2025-11-12 15:43:10
125	CMR du PRR	\N	\N	2025-11-13 08:48:49	2025-11-13 08:48:49
126	Impact : intitule	\N	125	2025-11-13 08:49:04	2025-11-13 08:49:04
127	Effet global1 : intitule	\N	126	2025-11-13 08:49:16	2025-11-13 08:49:16
\.


--
-- TOC entry 5471 (class 0 OID 27053)
-- Dependencies: 256
-- Data for Name: cadre_mesure_resultats; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.cadre_mesure_resultats (indicateur_id, cadre_logique_id, created_at, updated_at, id) FROM stdin;
1246	99	2025-11-04 17:01:20	2025-11-04 17:01:20	1317
1247	99	2025-11-04 17:01:32	2025-11-04 17:01:32	1318
1248	99	2025-11-04 17:01:42	2025-11-04 17:01:42	1319
1249	100	2025-11-04 17:02:17	2025-11-04 17:02:17	1320
1250	104	2025-11-04 17:02:37	2025-11-04 17:02:37	1321
1251	104	2025-11-04 17:02:51	2025-11-04 17:02:51	1322
1252	105	2025-11-04 17:03:08	2025-11-04 17:03:08	1323
1253	105	2025-11-04 17:03:19	2025-11-04 17:03:19	1324
1254	101	2025-11-04 17:03:53	2025-11-04 17:03:53	1325
1255	101	2025-11-04 17:04:06	2025-11-04 17:04:06	1326
1256	106	2025-11-04 17:04:24	2025-11-04 17:04:24	1327
1257	106	2025-11-04 17:04:41	2025-11-04 17:04:41	1328
1258	106	2025-11-04 17:04:53	2025-11-04 17:04:53	1329
1259	107	2025-11-04 17:05:14	2025-11-04 17:05:14	1330
1260	107	2025-11-04 17:05:33	2025-11-04 17:05:33	1331
1261	107	2025-11-04 17:05:46	2025-11-04 17:05:46	1332
1262	107	2025-11-04 17:05:59	2025-11-04 17:05:59	1333
1263	108	2025-11-04 17:06:31	2025-11-04 17:06:31	1334
1264	108	2025-11-04 17:06:43	2025-11-04 17:06:43	1335
1265	109	2025-11-04 17:07:25	2025-11-04 17:07:25	1336
1266	109	2025-11-04 17:07:42	2025-11-04 17:07:42	1337
1267	102	2025-11-04 17:08:04	2025-11-04 17:08:04	1338
1268	102	2025-11-04 17:08:17	2025-11-04 17:08:17	1339
1269	110	2025-11-04 17:08:40	2025-11-04 17:08:40	1340
1270	110	2025-11-04 17:09:12	2025-11-04 17:09:12	1341
1271	110	2025-11-04 17:09:25	2025-11-04 17:09:25	1342
1272	110	2025-11-04 17:09:37	2025-11-04 17:09:37	1343
1273	111	2025-11-04 17:10:01	2025-11-04 17:10:01	1344
1274	111	2025-11-04 17:10:21	2025-11-04 17:10:21	1345
1275	111	2025-11-04 17:10:41	2025-11-04 17:10:41	1346
1276	111	2025-11-04 17:10:52	2025-11-04 17:10:52	1347
1277	111	2025-11-04 17:11:28	2025-11-04 17:11:28	1348
1278	111	2025-11-04 17:11:39	2025-11-04 17:11:39	1349
1279	112	2025-11-04 17:15:50	2025-11-04 17:15:50	1350
1280	112	2025-11-04 17:16:01	2025-11-04 17:16:01	1351
1281	112	2025-11-04 17:16:19	2025-11-04 17:16:19	1352
1282	112	2025-11-04 17:16:37	2025-11-04 17:16:37	1353
1283	113	2025-11-04 17:16:51	2025-11-04 17:16:51	1354
1284	113	2025-11-04 17:17:06	2025-11-04 17:17:06	1355
1285	114	2025-11-04 17:17:25	2025-11-04 17:17:25	1356
1286	114	2025-11-04 17:17:36	2025-11-04 17:17:36	1357
1287	114	2025-11-04 17:17:46	2025-11-04 17:17:46	1358
1288	114	2025-11-04 17:17:57	2025-11-04 17:17:57	1359
1289	114	2025-11-04 17:18:10	2025-11-04 17:18:10	1360
1290	103	2025-11-04 17:18:32	2025-11-04 17:18:32	1361
1291	103	2025-11-04 17:18:51	2025-11-04 17:18:51	1362
1292	103	2025-11-04 17:19:04	2025-11-04 17:19:04	1363
1293	115	2025-11-04 17:19:20	2025-11-04 17:19:20	1364
1294	115	2025-11-04 17:19:32	2025-11-04 17:19:32	1365
1295	115	2025-11-04 17:19:48	2025-11-04 17:19:48	1366
1296	115	2025-11-04 17:20:00	2025-11-04 17:20:00	1367
1297	115	2025-11-04 17:20:12	2025-11-04 17:20:12	1368
1298	115	2025-11-04 17:20:24	2025-11-04 17:20:24	1369
1299	115	2025-11-04 17:20:43	2025-11-04 17:20:43	1370
1300	116	2025-11-04 17:22:02	2025-11-04 17:22:02	1371
1301	116	2025-11-04 17:22:14	2025-11-04 17:22:14	1372
1302	116	2025-11-04 17:22:27	2025-11-04 17:22:27	1373
1303	117	2025-11-04 17:23:44	2025-11-04 17:23:44	1374
1304	117	2025-11-04 17:23:57	2025-11-04 17:23:57	1375
1305	117	2025-11-04 17:24:10	2025-11-04 17:24:10	1376
1306	117	2025-11-04 17:24:23	2025-11-04 17:24:23	1377
1307	118	2025-11-04 17:24:42	2025-11-04 17:24:42	1378
1308	118	2025-11-04 17:24:53	2025-11-04 17:24:53	1379
1309	119	2025-11-04 17:26:16	2025-11-04 17:26:16	1381
1310	119	2025-11-04 17:26:29	2025-11-04 17:26:29	1382
1311	120	2025-11-04 17:27:28	2025-11-04 17:27:28	1383
1312	120	2025-11-04 17:27:39	2025-11-04 17:27:39	1384
1313	120	2025-11-04 17:27:51	2025-11-04 17:27:51	1385
1314	120	2025-11-04 17:28:11	2025-11-04 17:28:11	1386
1315	120	2025-11-04 17:28:23	2025-11-04 17:28:23	1387
1316	120	2025-11-04 17:28:34	2025-11-04 17:28:34	1388
1246	124	2025-11-12 15:49:20	2025-11-12 15:49:20	1389
1247	124	2025-11-12 15:49:21	2025-11-12 15:49:21	1390
1247	123	2025-11-12 15:49:24	2025-11-12 15:49:24	1391
1246	123	2025-11-12 15:49:47	2025-11-12 15:49:47	1392
1254	123	2025-11-12 15:50:00	2025-11-12 15:50:00	1393
1249	124	2025-11-12 16:04:44	2025-11-12 16:04:44	1394
1246	126	2025-11-13 08:55:15	2025-11-13 08:55:15	1395
\.


--
-- TOC entry 5470 (class 0 OID 26992)
-- Dependencies: 255
-- Data for Name: commentaire_valeur_indicateurs; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.commentaire_valeur_indicateurs (id, intitule, description, created_at, updated_at) FROM stdin;
2	...	\N	2025-09-28 20:17:37	2025-09-28 20:17:37
1	///	\N	2025-09-28 20:17:20	2025-09-28 20:18:35
3	RAS	\N	2025-09-30 14:40:40	2025-09-30 14:40:40
\.


--
-- TOC entry 5473 (class 0 OID 27083)
-- Dependencies: 258
-- Data for Name: desagregation_indicateur; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.desagregation_indicateur (id, desagregation_id, indicateur_id) FROM stdin;
\.


--
-- TOC entry 5458 (class 0 OID 26938)
-- Dependencies: 243
-- Data for Name: desagregations; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.desagregations (id, intitule, type_desagregation_id, created_at, updated_at) FROM stdin;
2	Femme	1	2025-09-23 13:50:20	2025-09-23 13:50:20
1	Homme	1	2025-09-23 13:50:14	2025-09-23 13:50:27
3	Urbain	2	2025-09-29 11:52:38	2025-09-30 12:15:40
5	Rural	2	2025-10-14 10:28:11	2025-10-14 10:28:11
6	Total	4	2025-10-22 16:01:35	2025-10-22 16:01:35
\.


--
-- TOC entry 5503 (class 0 OID 27360)
-- Dependencies: 288
-- Data for Name: donnee_indicateur_desagregation; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.donnee_indicateur_desagregation (id, donnee_indicateur_id, desagregation_id, created_at, updated_at) FROM stdin;
748	750	6	2025-11-05 11:20:54	2025-11-05 11:20:54
749	751	6	2025-11-05 11:20:54	2025-11-05 11:20:54
750	752	6	2025-11-05 11:20:54	2025-11-05 11:20:54
751	753	6	2025-11-05 11:20:54	2025-11-05 11:20:54
752	754	6	2025-11-05 11:20:54	2025-11-05 11:20:54
753	755	6	2025-11-05 11:20:54	2025-11-05 11:20:54
754	756	6	2025-11-05 11:20:54	2025-11-05 11:20:54
755	757	6	2025-11-05 11:20:54	2025-11-05 11:20:54
756	758	6	2025-11-05 11:20:54	2025-11-05 11:20:54
757	759	6	2025-11-05 11:20:54	2025-11-05 11:20:54
758	760	6	2025-11-05 11:20:54	2025-11-05 11:20:54
759	761	6	2025-11-05 11:20:54	2025-11-05 11:20:54
760	762	6	2025-11-05 11:20:54	2025-11-05 11:20:54
761	763	6	2025-11-05 11:20:54	2025-11-05 11:20:54
762	764	6	2025-11-05 11:20:54	2025-11-05 11:20:54
763	765	6	2025-11-05 11:20:54	2025-11-05 11:20:54
764	766	6	2025-11-05 11:20:54	2025-11-05 11:20:54
765	767	6	2025-11-05 11:20:54	2025-11-05 11:20:54
766	768	6	2025-11-05 11:20:54	2025-11-05 11:20:54
767	769	6	2025-11-05 11:20:54	2025-11-05 11:20:54
768	770	6	2025-11-05 11:20:54	2025-11-05 11:20:54
769	771	6	2025-11-05 11:20:54	2025-11-05 11:20:54
770	772	6	2025-11-05 11:20:54	2025-11-05 11:20:54
771	773	6	2025-11-05 11:20:54	2025-11-05 11:20:54
772	774	6	2025-11-05 11:20:54	2025-11-05 11:20:54
773	775	6	2025-11-05 11:20:54	2025-11-05 11:20:54
774	776	6	2025-11-05 11:20:54	2025-11-05 11:20:54
775	777	6	2025-11-05 11:20:54	2025-11-05 11:20:54
776	778	6	2025-11-05 11:20:54	2025-11-05 11:20:54
777	779	6	2025-11-05 11:20:54	2025-11-05 11:20:54
778	780	6	2025-11-05 11:20:54	2025-11-05 11:20:54
779	781	6	2025-11-05 11:20:54	2025-11-05 11:20:54
780	782	6	2025-11-05 11:20:54	2025-11-05 11:20:54
781	783	6	2025-11-05 11:20:54	2025-11-05 11:20:54
782	784	6	2025-11-05 11:20:54	2025-11-05 11:20:54
783	785	6	2025-11-05 11:20:54	2025-11-05 11:20:54
784	786	6	2025-11-05 11:20:54	2025-11-05 11:20:54
785	787	6	2025-11-05 11:20:54	2025-11-05 11:20:54
786	788	6	2025-11-05 11:20:54	2025-11-05 11:20:54
787	789	6	2025-11-05 11:20:54	2025-11-05 11:20:54
788	790	6	2025-11-05 11:20:54	2025-11-05 11:20:54
789	791	6	2025-11-05 11:20:54	2025-11-05 11:20:54
790	792	6	2025-11-05 11:20:54	2025-11-05 11:20:54
791	793	6	2025-11-05 11:20:54	2025-11-05 11:20:54
792	794	6	2025-11-05 11:20:54	2025-11-05 11:20:54
793	795	6	2025-11-05 11:20:54	2025-11-05 11:20:54
794	796	6	2025-11-05 11:20:54	2025-11-05 11:20:54
795	797	6	2025-11-05 11:20:54	2025-11-05 11:20:54
796	798	6	2025-11-05 11:20:54	2025-11-05 11:20:54
797	799	6	2025-11-05 11:20:54	2025-11-05 11:20:54
798	800	6	2025-11-05 11:20:54	2025-11-05 11:20:54
799	801	6	2025-11-05 11:20:54	2025-11-05 11:20:54
800	802	6	2025-11-05 11:20:54	2025-11-05 11:20:54
801	803	6	2025-11-05 11:20:54	2025-11-05 11:20:54
802	804	6	2025-11-05 11:20:54	2025-11-05 11:20:54
803	805	6	2025-11-05 11:20:54	2025-11-05 11:20:54
804	806	6	2025-11-05 11:20:54	2025-11-05 11:20:54
805	807	6	2025-11-05 11:20:54	2025-11-05 11:20:54
806	808	6	2025-11-05 11:20:54	2025-11-05 11:20:54
807	809	6	2025-11-05 11:20:54	2025-11-05 11:20:54
808	810	6	2025-11-05 11:20:54	2025-11-05 11:20:54
809	811	6	2025-11-05 11:20:54	2025-11-05 11:20:54
810	812	6	2025-11-05 11:20:54	2025-11-05 11:20:54
811	813	6	2025-11-05 11:20:54	2025-11-05 11:20:54
812	814	6	2025-11-05 11:20:54	2025-11-05 11:20:54
813	815	6	2025-11-05 11:20:54	2025-11-05 11:20:54
814	816	6	2025-11-05 11:20:54	2025-11-05 11:20:54
815	817	6	2025-11-05 11:21:58	2025-11-05 11:21:58
816	818	6	2025-11-05 11:21:58	2025-11-05 11:21:58
817	819	6	2025-11-05 11:21:58	2025-11-05 11:21:58
818	820	6	2025-11-05 11:21:58	2025-11-05 11:21:58
819	821	6	2025-11-05 11:21:58	2025-11-05 11:21:58
820	822	6	2025-11-05 11:21:58	2025-11-05 11:21:58
821	823	6	2025-11-05 11:21:58	2025-11-05 11:21:58
822	824	6	2025-11-05 11:21:58	2025-11-05 11:21:58
823	825	6	2025-11-05 11:21:58	2025-11-05 11:21:58
824	826	6	2025-11-05 11:21:58	2025-11-05 11:21:58
825	827	6	2025-11-05 11:21:58	2025-11-05 11:21:58
826	828	6	2025-11-05 11:21:58	2025-11-05 11:21:58
827	829	6	2025-11-05 11:21:58	2025-11-05 11:21:58
828	830	6	2025-11-05 11:21:58	2025-11-05 11:21:58
829	831	6	2025-11-05 11:21:58	2025-11-05 11:21:58
830	832	6	2025-11-05 11:21:58	2025-11-05 11:21:58
831	833	6	2025-11-05 11:21:58	2025-11-05 11:21:58
832	834	6	2025-11-05 11:21:58	2025-11-05 11:21:58
833	835	6	2025-11-05 11:21:58	2025-11-05 11:21:58
834	836	6	2025-11-05 11:21:58	2025-11-05 11:21:58
835	837	6	2025-11-05 11:21:58	2025-11-05 11:21:58
836	838	6	2025-11-05 11:21:58	2025-11-05 11:21:58
837	839	6	2025-11-05 11:21:58	2025-11-05 11:21:58
838	840	6	2025-11-05 11:21:58	2025-11-05 11:21:58
839	841	6	2025-11-05 11:21:58	2025-11-05 11:21:58
840	842	6	2025-11-05 11:21:58	2025-11-05 11:21:58
841	843	6	2025-11-05 11:21:58	2025-11-05 11:21:58
842	844	6	2025-11-05 11:21:58	2025-11-05 11:21:58
843	845	6	2025-11-05 11:21:58	2025-11-05 11:21:58
844	846	6	2025-11-05 11:21:58	2025-11-05 11:21:58
845	847	6	2025-11-05 11:21:58	2025-11-05 11:21:58
846	848	6	2025-11-05 11:21:58	2025-11-05 11:21:58
847	849	6	2025-11-05 11:21:58	2025-11-05 11:21:58
848	850	6	2025-11-05 11:21:58	2025-11-05 11:21:58
849	851	6	2025-11-05 11:21:58	2025-11-05 11:21:58
850	852	6	2025-11-05 11:21:58	2025-11-05 11:21:58
851	853	6	2025-11-05 11:21:58	2025-11-05 11:21:58
852	854	6	2025-11-05 11:21:58	2025-11-05 11:21:58
853	855	6	2025-11-05 11:21:58	2025-11-05 11:21:58
854	856	6	2025-11-05 11:21:58	2025-11-05 11:21:58
855	857	6	2025-11-05 11:21:58	2025-11-05 11:21:58
856	858	6	2025-11-05 11:21:58	2025-11-05 11:21:58
857	859	6	2025-11-05 11:21:58	2025-11-05 11:21:58
858	860	6	2025-11-05 11:21:58	2025-11-05 11:21:58
859	861	6	2025-11-05 11:21:58	2025-11-05 11:21:58
860	862	6	2025-11-05 11:21:58	2025-11-05 11:21:58
861	863	6	2025-11-05 11:21:58	2025-11-05 11:21:58
862	864	6	2025-11-05 11:21:58	2025-11-05 11:21:58
863	865	6	2025-11-05 11:21:58	2025-11-05 11:21:58
864	866	6	2025-11-05 11:21:58	2025-11-05 11:21:58
865	867	6	2025-11-05 11:21:58	2025-11-05 11:21:58
866	868	6	2025-11-05 11:21:58	2025-11-05 11:21:58
867	869	6	2025-11-05 11:21:58	2025-11-05 11:21:58
868	870	6	2025-11-05 11:21:58	2025-11-05 11:21:58
869	871	6	2025-11-05 11:21:58	2025-11-05 11:21:58
870	872	6	2025-11-05 11:21:58	2025-11-05 11:21:58
871	873	6	2025-11-05 11:21:58	2025-11-05 11:21:58
872	874	6	2025-11-05 11:21:58	2025-11-05 11:21:58
873	875	6	2025-11-05 11:21:58	2025-11-05 11:21:58
874	876	6	2025-11-05 11:21:58	2025-11-05 11:21:58
875	877	6	2025-11-05 11:21:58	2025-11-05 11:21:58
876	878	6	2025-11-05 11:21:58	2025-11-05 11:21:58
877	879	6	2025-11-05 11:21:58	2025-11-05 11:21:58
878	880	6	2025-11-05 11:21:58	2025-11-05 11:21:58
879	881	6	2025-11-05 11:21:58	2025-11-05 11:21:58
880	882	6	2025-11-05 11:21:58	2025-11-05 11:21:58
881	883	6	2025-11-05 11:21:58	2025-11-05 11:21:58
882	884	6	2025-11-05 11:21:58	2025-11-05 11:21:58
883	885	6	2025-11-05 11:21:58	2025-11-05 11:21:58
884	886	6	2025-11-05 11:21:58	2025-11-05 11:21:58
885	887	6	2025-11-05 11:21:58	2025-11-05 11:21:58
886	888	6	2025-11-05 11:21:58	2025-11-05 11:21:58
887	889	6	2025-11-05 11:21:58	2025-11-05 11:21:58
888	890	6	2025-11-05 11:21:58	2025-11-05 11:21:58
889	891	6	2025-11-05 11:21:58	2025-11-05 11:21:58
890	892	6	2025-11-05 11:21:58	2025-11-05 11:21:58
891	893	6	2025-11-05 11:21:58	2025-11-05 11:21:58
892	894	6	2025-11-05 11:21:58	2025-11-05 11:21:58
893	895	6	2025-11-05 11:21:58	2025-11-05 11:21:58
894	896	6	2025-11-05 11:21:58	2025-11-05 11:21:58
895	897	6	2025-11-05 11:21:59	2025-11-05 11:21:59
896	898	6	2025-11-05 11:21:59	2025-11-05 11:21:59
897	899	6	2025-11-05 11:21:59	2025-11-05 11:21:59
898	900	6	2025-11-05 11:21:59	2025-11-05 11:21:59
899	901	6	2025-11-05 11:21:59	2025-11-05 11:21:59
900	902	6	2025-11-05 11:21:59	2025-11-05 11:21:59
901	903	6	2025-11-05 11:21:59	2025-11-05 11:21:59
902	904	6	2025-11-05 11:21:59	2025-11-05 11:21:59
903	905	6	2025-11-05 11:21:59	2025-11-05 11:21:59
904	906	6	2025-11-05 11:21:59	2025-11-05 11:21:59
905	907	6	2025-11-05 11:21:59	2025-11-05 11:21:59
906	908	6	2025-11-05 11:21:59	2025-11-05 11:21:59
907	909	6	2025-11-05 11:21:59	2025-11-05 11:21:59
908	910	6	2025-11-05 11:21:59	2025-11-05 11:21:59
909	911	6	2025-11-05 11:21:59	2025-11-05 11:21:59
910	912	6	2025-11-05 11:21:59	2025-11-05 11:21:59
911	913	6	2025-11-05 11:21:59	2025-11-05 11:21:59
912	914	6	2025-11-05 11:21:59	2025-11-05 11:21:59
913	915	6	2025-11-05 11:21:59	2025-11-05 11:21:59
914	916	6	2025-11-05 11:21:59	2025-11-05 11:21:59
915	917	6	2025-11-05 11:21:59	2025-11-05 11:21:59
916	918	6	2025-11-05 11:21:59	2025-11-05 11:21:59
917	919	6	2025-11-05 11:21:59	2025-11-05 11:21:59
918	920	6	2025-11-05 11:21:59	2025-11-05 11:21:59
919	921	6	2025-11-05 11:21:59	2025-11-05 11:21:59
920	922	6	2025-11-05 11:21:59	2025-11-05 11:21:59
921	923	6	2025-11-05 11:21:59	2025-11-05 11:21:59
922	924	6	2025-11-05 11:21:59	2025-11-05 11:21:59
923	925	6	2025-11-05 11:21:59	2025-11-05 11:21:59
924	926	6	2025-11-05 11:21:59	2025-11-05 11:21:59
925	927	6	2025-11-05 11:21:59	2025-11-05 11:21:59
926	928	6	2025-11-05 11:21:59	2025-11-05 11:21:59
927	929	6	2025-11-05 11:21:59	2025-11-05 11:21:59
928	930	6	2025-11-05 11:21:59	2025-11-05 11:21:59
929	931	6	2025-11-05 11:21:59	2025-11-05 11:21:59
930	932	6	2025-11-05 11:21:59	2025-11-05 11:21:59
931	933	6	2025-11-05 11:21:59	2025-11-05 11:21:59
932	934	6	2025-11-05 11:21:59	2025-11-05 11:21:59
933	935	6	2025-11-05 11:21:59	2025-11-05 11:21:59
934	936	6	2025-11-05 11:21:59	2025-11-05 11:21:59
935	937	6	2025-11-05 11:21:59	2025-11-05 11:21:59
936	938	6	2025-11-05 11:21:59	2025-11-05 11:21:59
937	939	6	2025-11-05 11:21:59	2025-11-05 11:21:59
938	940	6	2025-11-05 11:21:59	2025-11-05 11:21:59
939	941	6	2025-11-05 11:21:59	2025-11-05 11:21:59
940	942	6	2025-11-05 11:21:59	2025-11-05 11:21:59
941	943	6	2025-11-05 11:21:59	2025-11-05 11:21:59
942	944	6	2025-11-05 11:21:59	2025-11-05 11:21:59
943	945	6	2025-11-05 11:21:59	2025-11-05 11:21:59
944	946	6	2025-11-05 11:21:59	2025-11-05 11:21:59
945	947	6	2025-11-05 11:21:59	2025-11-05 11:21:59
946	948	6	2025-11-05 11:21:59	2025-11-05 11:21:59
947	949	6	2025-11-05 11:21:59	2025-11-05 11:21:59
948	950	6	2025-11-05 11:21:59	2025-11-05 11:21:59
949	951	6	2025-11-05 11:21:59	2025-11-05 11:21:59
950	952	6	2025-11-05 11:21:59	2025-11-05 11:21:59
951	953	6	2025-11-05 11:21:59	2025-11-05 11:21:59
952	954	6	2025-11-05 11:21:59	2025-11-05 11:21:59
953	955	6	2025-11-05 11:21:59	2025-11-05 11:21:59
954	956	6	2025-11-05 11:21:59	2025-11-05 11:21:59
955	957	6	2025-11-05 11:21:59	2025-11-05 11:21:59
956	958	6	2025-11-05 11:21:59	2025-11-05 11:21:59
957	959	6	2025-11-05 11:21:59	2025-11-05 11:21:59
958	960	6	2025-11-05 11:21:59	2025-11-05 11:21:59
959	961	6	2025-11-05 11:21:59	2025-11-05 11:21:59
960	962	6	2025-11-05 11:21:59	2025-11-05 11:21:59
961	963	6	2025-11-05 11:21:59	2025-11-05 11:21:59
962	964	6	2025-11-05 11:21:59	2025-11-05 11:21:59
963	965	6	2025-11-05 11:21:59	2025-11-05 11:21:59
964	966	6	2025-11-05 11:21:59	2025-11-05 11:21:59
965	967	6	2025-11-05 11:21:59	2025-11-05 11:21:59
966	968	6	2025-11-05 11:21:59	2025-11-05 11:21:59
967	969	6	2025-11-05 11:21:59	2025-11-05 11:21:59
968	970	6	2025-11-05 11:21:59	2025-11-05 11:21:59
969	971	6	2025-11-05 11:21:59	2025-11-05 11:21:59
970	972	6	2025-11-05 11:21:59	2025-11-05 11:21:59
971	973	6	2025-11-05 11:21:59	2025-11-05 11:21:59
972	974	6	2025-11-05 11:21:59	2025-11-05 11:21:59
973	975	6	2025-11-05 11:21:59	2025-11-05 11:21:59
974	976	6	2025-11-05 11:21:59	2025-11-05 11:21:59
975	977	6	2025-11-05 11:21:59	2025-11-05 11:21:59
976	978	6	2025-11-05 11:21:59	2025-11-05 11:21:59
977	979	6	2025-11-05 11:21:59	2025-11-05 11:21:59
978	980	6	2025-11-05 11:21:59	2025-11-05 11:21:59
979	981	6	2025-11-05 11:21:59	2025-11-05 11:21:59
980	982	6	2025-11-05 11:21:59	2025-11-05 11:21:59
981	983	6	2025-11-05 11:21:59	2025-11-05 11:21:59
982	984	6	2025-11-05 11:21:59	2025-11-05 11:21:59
983	985	6	2025-11-05 11:21:59	2025-11-05 11:21:59
984	986	6	2025-11-05 11:21:59	2025-11-05 11:21:59
985	987	6	2025-11-05 11:21:59	2025-11-05 11:21:59
986	988	6	2025-11-05 11:21:59	2025-11-05 11:21:59
987	989	6	2025-11-05 11:21:59	2025-11-05 11:21:59
988	990	6	2025-11-05 11:21:59	2025-11-05 11:21:59
989	991	6	2025-11-05 11:21:59	2025-11-05 11:21:59
990	992	6	2025-11-05 11:21:59	2025-11-05 11:21:59
991	993	6	2025-11-05 11:21:59	2025-11-05 11:21:59
992	994	6	2025-11-05 11:21:59	2025-11-05 11:21:59
993	995	6	2025-11-05 11:21:59	2025-11-05 11:21:59
994	996	6	2025-11-05 11:21:59	2025-11-05 11:21:59
995	997	6	2025-11-05 11:21:59	2025-11-05 11:21:59
996	998	6	2025-11-05 11:21:59	2025-11-05 11:21:59
997	999	6	2025-11-05 11:21:59	2025-11-05 11:21:59
998	1000	6	2025-11-05 11:21:59	2025-11-05 11:21:59
999	1001	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1000	1002	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1001	1003	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1002	1004	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1003	1005	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1004	1006	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1005	1007	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1006	1008	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1007	1009	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1008	1010	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1009	1011	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1010	1012	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1011	1013	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1012	1014	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1013	1015	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1014	1016	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1015	1017	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1016	1018	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1017	1019	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1018	1020	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1019	1021	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1020	1022	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1021	1023	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1022	1024	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1023	1025	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1024	1026	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1025	1027	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1026	1028	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1027	1029	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1028	1030	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1029	1031	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1030	1032	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1031	1033	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1032	1034	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1033	1035	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1034	1036	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1035	1037	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1036	1038	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1037	1039	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1038	1040	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1039	1041	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1040	1042	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1041	1043	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1042	1044	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1043	1045	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1044	1046	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1045	1047	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1046	1048	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1047	1049	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1048	1050	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1049	1051	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1050	1052	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1051	1053	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1052	1054	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1053	1055	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1054	1056	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1055	1057	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1056	1058	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1057	1059	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1058	1060	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1059	1061	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1060	1062	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1061	1063	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1062	1064	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1063	1065	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1064	1066	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1065	1067	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1066	1068	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1067	1069	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1068	1070	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1069	1071	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1070	1072	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1071	1073	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1072	1074	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1073	1075	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1074	1076	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1075	1077	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1076	1078	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1077	1079	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1078	1080	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1079	1081	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1080	1082	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1081	1083	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1082	1084	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1083	1085	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1084	1086	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1085	1087	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1086	1088	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1087	1089	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1088	1090	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1089	1091	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1090	1092	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1091	1093	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1092	1094	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1093	1095	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1094	1096	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1095	1097	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1096	1098	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1097	1099	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1098	1100	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1099	1101	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1100	1102	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1101	1103	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1102	1104	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1103	1105	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1104	1106	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1105	1107	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1106	1108	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1107	1109	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1108	1110	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1109	1111	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1110	1112	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1111	1113	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1112	1114	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1113	1115	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1114	1116	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1115	1117	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1116	1118	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1117	1119	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1118	1120	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1119	1121	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1120	1122	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1121	1123	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1122	1124	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1123	1125	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1124	1126	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1125	1127	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1126	1128	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1127	1129	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1128	1130	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1129	1131	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1130	1132	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1131	1133	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1132	1134	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1133	1135	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1134	1136	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1135	1137	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1136	1138	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1137	1139	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1138	1140	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1139	1141	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1140	1142	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1141	1143	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1142	1144	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1143	1145	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1144	1146	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1145	1147	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1146	1148	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1147	1149	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1148	1150	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1149	1151	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1150	1152	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1151	1153	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1152	1154	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1153	1155	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1154	1156	6	2025-11-05 11:21:59	2025-11-05 11:21:59
\.


--
-- TOC entry 5456 (class 0 OID 26931)
-- Dependencies: 241
-- Data for Name: donnee_indicateurs; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.donnee_indicateurs (id, nature_donnee_id, indicateur_id, zone_id, periode_id, source_indicateur_id, unite_indicateur_id, commentaire_valeur_indicateur_id, valeur, created_at, updated_at) FROM stdin;
750	3	1246	1	22	4	4	3	41.2	2025-11-05 11:20:54	2025-11-05 11:20:54
751	3	1247	1	22	4	4	3	71.5	2025-11-05 11:20:54	2025-11-05 11:20:54
752	3	1248	1	24	5	5	3	65.9	2025-11-05 11:20:54	2025-11-05 11:20:54
753	3	1249	1	22	4	4	3	79.2	2025-11-05 11:20:54	2025-11-05 11:20:54
754	3	1250	1	25	6	4	3	20.3	2025-11-05 11:20:54	2025-11-05 11:20:54
755	3	1251	1	23	7	4	3	50.37	2025-11-05 11:20:54	2025-11-05 11:20:54
756	3	1252	1	24	8	4	3	35.95	2025-11-05 11:20:54	2025-11-05 11:20:54
757	3	1253	1	24	8	4	3	18.04	2025-11-05 11:20:54	2025-11-05 11:20:54
758	3	1254	1	22	4	4	3	9.3	2025-11-05 11:20:54	2025-11-05 11:20:54
759	3	1255	1	22	4	4	3	60.4	2025-11-05 11:20:54	2025-11-05 11:20:54
760	3	1256	1	23	9	4	3	74.4	2025-11-05 11:20:54	2025-11-05 11:20:54
761	3	1257	1	24	10	6	3	19	2025-11-05 11:20:54	2025-11-05 11:20:54
762	3	1258	1	25	10	4	3	70.15	2025-11-05 11:20:54	2025-11-05 11:20:54
763	3	1259	1	22	4	4	3	40.1	2025-11-05 11:20:54	2025-11-05 11:20:54
764	3	1260	1	25	11	7	3	2	2025-11-05 11:20:54	2025-11-05 11:20:54
765	3	1261	1	22	12	4	3	37.65	2025-11-05 11:20:54	2025-11-05 11:20:54
766	3	1262	1	25	13	4	3	70	2025-11-05 11:20:54	2025-11-05 11:20:54
767	3	1263	1	25	10	4	3	50	2025-11-05 11:20:54	2025-11-05 11:20:54
768	3	1264	1	25	10	4	3	30.1	2025-11-05 11:20:54	2025-11-05 11:20:54
769	3	1265	1	19	14	4	3	40	2025-11-05 11:20:54	2025-11-05 11:20:54
770	3	1266	1	24	15	8	3	85	2025-11-05 11:20:54	2025-11-05 11:20:54
771	3	1267	1	25	16	4	3	8.5	2025-11-05 11:20:54	2025-11-05 11:20:54
772	3	1268	1	22	4	9	3	0.33	2025-11-05 11:20:54	2025-11-05 11:20:54
773	3	1269	1	25	17	4	3	68.98	2025-11-05 11:20:54	2025-11-05 11:20:54
774	3	1270	1	25	18	4	3	15	2025-11-05 11:20:54	2025-11-05 11:20:54
775	3	1271	1	25	19	4	3	7	2025-11-05 11:20:54	2025-11-05 11:20:54
776	3	1273	1	24	21	4	3	11.7	2025-11-05 11:20:54	2025-11-05 11:20:54
777	3	1274	1	25	16	4	3	26.45	2025-11-05 11:20:54	2025-11-05 11:20:54
778	3	1275	1	23	22	4	3	37	2025-11-05 11:20:54	2025-11-05 11:20:54
779	3	1276	1	25	22	4	3	13.35	2025-11-05 11:20:54	2025-11-05 11:20:54
780	3	1277	1	25	22	4	3	18	2025-11-05 11:20:54	2025-11-05 11:20:54
781	3	1278	1	25	16	4	3	8.97	2025-11-05 11:20:54	2025-11-05 11:20:54
782	3	1279	1	25	23	4	3	40.1	2025-11-05 11:20:54	2025-11-05 11:20:54
783	3	1280	1	23	24	4	3	14.6	2025-11-05 11:20:54	2025-11-05 11:20:54
784	3	1281	1	25	25	4	3	33	2025-11-05 11:20:54	2025-11-05 11:20:54
785	3	1282	1	25	25	4	3	59	2025-11-05 11:20:54	2025-11-05 11:20:54
786	3	1283	1	23	26	4	3	1.8	2025-11-05 11:20:54	2025-11-05 11:20:54
787	3	1284	1	23	26	4	3	2.4	2025-11-05 11:20:54	2025-11-05 11:20:54
788	3	1285	1	23	27	4	3	19.92	2025-11-05 11:20:54	2025-11-05 11:20:54
789	3	1286	1	25	28	10	3	12.1	2025-11-05 11:20:54	2025-11-05 11:20:54
790	3	1287	1	23	29	6	3	23	2025-11-05 11:20:54	2025-11-05 11:20:54
791	3	1288	1	23	30	4	3	63	2025-11-05 11:20:54	2025-11-05 11:20:54
792	3	1289	1	23	30	4	3	37	2025-11-05 11:20:54	2025-11-05 11:20:54
793	3	1290	1	22	4	4	3	35.6	2025-11-05 11:20:54	2025-11-05 11:20:54
794	3	1291	1	22	31	11	3	123	2025-11-05 11:20:54	2025-11-05 11:20:54
795	3	1292	1	16	32	12	3	519.5	2025-11-05 11:20:54	2025-11-05 11:20:54
796	3	1293	1	25	33	4	3	42.3	2025-11-05 11:20:54	2025-11-05 11:20:54
797	3	1294	1	25	33	4	3	12.6	2025-11-05 11:20:54	2025-11-05 11:20:54
798	3	1295	1	25	33	4	3	7.2	2025-11-05 11:20:54	2025-11-05 11:20:54
799	3	1296	1	25	33	4	3	13.7	2025-11-05 11:20:54	2025-11-05 11:20:54
800	3	1297	1	20	34	5	3	2.1	2025-11-05 11:20:54	2025-11-05 11:20:54
801	3	1298	1	25	35	13	3	67	2025-11-05 11:20:54	2025-11-05 11:20:54
802	3	1299	1	25	36	8	3	2.3	2025-11-05 11:20:54	2025-11-05 11:20:54
803	3	1300	1	25	25	4	3	20	2025-11-05 11:20:54	2025-11-05 11:20:54
804	3	1303	1	25	40	4	3	56.59	2025-11-05 11:20:54	2025-11-05 11:20:54
805	3	1304	1	25	41	4	3	47.42	2025-11-05 11:20:54	2025-11-05 11:20:54
806	3	1305	1	25	42	4	3	22.48	2025-11-05 11:20:54	2025-11-05 11:20:54
807	3	1306	1	23	43	4	3	12.2	2025-11-05 11:20:54	2025-11-05 11:20:54
808	3	1307	1	19	44	4	3	30	2025-11-05 11:20:54	2025-11-05 11:20:54
809	3	1308	1	22	4	4	3	52.6	2025-11-05 11:20:54	2025-11-05 11:20:54
810	3	1309	1	23	45	4	3	19.5	2025-11-05 11:20:54	2025-11-05 11:20:54
811	3	1310	1	22	4	4	3	10.1	2025-11-05 11:20:54	2025-11-05 11:20:54
812	3	1311	1	25	46	4	3	74.2	2025-11-05 11:20:54	2025-11-05 11:20:54
813	3	1312	1	25	46	4	3	49.69	2025-11-05 11:20:54	2025-11-05 11:20:54
814	3	1313	1	25	47	4	3	4	2025-11-05 11:20:54	2025-11-05 11:20:54
815	3	1315	1	23	49	4	3	43.9	2025-11-05 11:20:54	2025-11-05 11:20:54
816	3	1316	1	24	50	4	3	11.05	2025-11-05 11:20:54	2025-11-05 11:20:54
817	1	1246	1	26	4	4	3	39.34	2025-11-05 11:21:58	2025-11-05 11:21:58
818	1	1247	1	26	4	4	3	68.2	2025-11-05 11:21:58	2025-11-05 11:21:58
819	1	1248	1	26	5	5	3	65.92	2025-11-05 11:21:58	2025-11-05 11:21:58
820	1	1249	1	26	4	4	3	82.5	2025-11-05 11:21:58	2025-11-05 11:21:58
821	1	1250	1	26	6	4	3	16.5	2025-11-05 11:21:58	2025-11-05 11:21:58
822	1	1251	1	26	7	4	3	54.49	2025-11-05 11:21:58	2025-11-05 11:21:58
823	1	1252	1	26	8	4	3	30.95	2025-11-05 11:21:58	2025-11-05 11:21:58
824	1	1253	1	26	8	4	3	20	2025-11-05 11:21:58	2025-11-05 11:21:58
825	1	1254	1	26	4	4	3	13.4	2025-11-05 11:21:58	2025-11-05 11:21:58
826	1	1255	1	26	4	4	3	73.5	2025-11-05 11:21:58	2025-11-05 11:21:58
827	1	1256	1	26	9	4	3	76	2025-11-05 11:21:58	2025-11-05 11:21:58
828	1	1257	1	26	10	6	3	18	2025-11-05 11:21:58	2025-11-05 11:21:58
829	1	1258	1	26	10	4	3	70.15	2025-11-05 11:21:58	2025-11-05 11:21:58
830	1	1259	1	26	4	4	3	43.4	2025-11-05 11:21:58	2025-11-05 11:21:58
831	1	1260	1	26	11	7	3	3	2025-11-05 11:21:58	2025-11-05 11:21:58
832	1	1261	1	26	12	4	3	60	2025-11-05 11:21:58	2025-11-05 11:21:58
833	1	1262	1	26	13	4	3	74	2025-11-05 11:21:58	2025-11-05 11:21:58
834	1	1263	1	26	10	4	3	75	2025-11-05 11:21:58	2025-11-05 11:21:58
835	1	1264	1	26	10	4	3	35	2025-11-05 11:21:58	2025-11-05 11:21:58
836	1	1265	1	26	14	4	3	80	2025-11-05 11:21:58	2025-11-05 11:21:58
837	1	1266	1	26	15	8	3	90	2025-11-05 11:21:58	2025-11-05 11:21:58
838	1	1267	1	26	16	4	3	6.6	2025-11-05 11:21:58	2025-11-05 11:21:58
839	1	1268	1	26	4	9	3	0.306	2025-11-05 11:21:58	2025-11-05 11:21:58
840	1	1269	1	26	17	4	3	92	2025-11-05 11:21:58	2025-11-05 11:21:58
841	1	1270	1	26	18	4	3	50	2025-11-05 11:21:58	2025-11-05 11:21:58
842	1	1271	1	26	19	4	3	8.4	2025-11-05 11:21:58	2025-11-05 11:21:58
843	1	1273	1	26	21	4	3	9.2	2025-11-05 11:21:58	2025-11-05 11:21:58
844	1	1274	1	26	16	4	3	29	2025-11-05 11:21:58	2025-11-05 11:21:58
845	1	1275	1	26	22	4	3	43	2025-11-05 11:21:58	2025-11-05 11:21:58
846	1	1276	1	26	22	4	3	10	2025-11-05 11:21:58	2025-11-05 11:21:58
847	1	1277	1	26	22	4	3	5	2025-11-05 11:21:58	2025-11-05 11:21:58
848	1	1278	1	26	16	4	3	7	2025-11-05 11:21:58	2025-11-05 11:21:58
849	1	1279	1	26	23	4	3	40.3	2025-11-05 11:21:58	2025-11-05 11:21:58
850	1	1280	1	26	24	4	3	18.7	2025-11-05 11:21:58	2025-11-05 11:21:58
851	1	1281	1	26	25	4	3	34	2025-11-05 11:21:58	2025-11-05 11:21:58
852	1	1282	1	26	25	4	3	60	2025-11-05 11:21:58	2025-11-05 11:21:58
853	1	1283	1	26	26	4	3	3.7	2025-11-05 11:21:58	2025-11-05 11:21:58
854	1	1284	1	26	26	4	3	7.1	2025-11-05 11:21:58	2025-11-05 11:21:58
855	1	1285	1	26	27	4	3	29.8	2025-11-05 11:21:58	2025-11-05 11:21:58
856	1	1286	1	26	28	10	3	12.31	2025-11-05 11:21:58	2025-11-05 11:21:58
857	1	1287	1	26	29	6	3	24	2025-11-05 11:21:58	2025-11-05 11:21:58
858	1	1288	1	26	30	4	3	75	2025-11-05 11:21:58	2025-11-05 11:21:58
859	1	1289	1	26	30	4	3	62	2025-11-05 11:21:58	2025-11-05 11:21:58
860	1	1290	1	26	4	4	3	38.5	2025-11-05 11:21:58	2025-11-05 11:21:58
861	1	1291	1	26	31	11	3	65	2025-11-05 11:21:58	2025-11-05 11:21:58
862	1	1292	1	26	32	12	3	287.2	2025-11-05 11:21:58	2025-11-05 11:21:58
863	1	1293	1	26	33	4	3	44.3	2025-11-05 11:21:58	2025-11-05 11:21:58
864	1	1294	1	26	33	4	3	13.6	2025-11-05 11:21:58	2025-11-05 11:21:58
865	1	1295	1	26	33	4	3	7.95	2025-11-05 11:21:58	2025-11-05 11:21:58
866	1	1296	1	26	33	4	3	14.68	2025-11-05 11:21:58	2025-11-05 11:21:58
867	1	1297	1	26	34	5	3	2.86	2025-11-05 11:21:58	2025-11-05 11:21:58
868	1	1298	1	26	35	13	3	61	2025-11-05 11:21:58	2025-11-05 11:21:58
869	1	1299	1	26	36	8	3	2.05	2025-11-05 11:21:58	2025-11-05 11:21:58
870	1	1300	1	26	25	4	3	20	2025-11-05 11:21:58	2025-11-05 11:21:58
871	1	1303	1	26	40	4	3	61.49	2025-11-05 11:21:58	2025-11-05 11:21:58
872	1	1304	1	26	41	4	3	52.57	2025-11-05 11:21:58	2025-11-05 11:21:58
873	1	1305	1	26	42	4	3	35	2025-11-05 11:21:58	2025-11-05 11:21:58
874	1	1306	1	26	43	4	3	8.7	2025-11-05 11:21:58	2025-11-05 11:21:58
875	1	1307	1	26	44	4	3	45	2025-11-05 11:21:58	2025-11-05 11:21:58
876	1	1308	1	26	4	4	3	62.1	2025-11-05 11:21:58	2025-11-05 11:21:58
877	1	1309	1	26	45	4	3	23.2	2025-11-05 11:21:58	2025-11-05 11:21:58
878	1	1310	1	26	4	4	3	9.4	2025-11-05 11:21:58	2025-11-05 11:21:58
879	1	1311	1	26	46	4	3	90.47	2025-11-05 11:21:58	2025-11-05 11:21:58
880	1	1312	1	26	46	4	3	55.83	2025-11-05 11:21:58	2025-11-05 11:21:58
881	1	1313	1	26	47	4	3	18	2025-11-05 11:21:58	2025-11-05 11:21:58
882	1	1314	1	26	48	4	3	30	2025-11-05 11:21:58	2025-11-05 11:21:58
883	1	1315	1	26	49	4	3	62.7	2025-11-05 11:21:58	2025-11-05 11:21:58
884	1	1316	1	26	50	4	3	50	2025-11-05 11:21:58	2025-11-05 11:21:58
885	1	1246	1	27	4	4	3	37.14	2025-11-05 11:21:58	2025-11-05 11:21:58
886	1	1247	1	27	4	4	3	66.5	2025-11-05 11:21:58	2025-11-05 11:21:58
887	1	1248	1	27	5	5	3	65.95	2025-11-05 11:21:58	2025-11-05 11:21:58
888	1	1249	1	27	4	4	3	84.2	2025-11-05 11:21:58	2025-11-05 11:21:58
889	1	1250	1	27	6	4	3	12.8	2025-11-05 11:21:58	2025-11-05 11:21:58
890	1	1251	1	27	7	4	3	55.86	2025-11-05 11:21:58	2025-11-05 11:21:58
891	1	1252	1	27	8	4	3	25.95	2025-11-05 11:21:58	2025-11-05 11:21:58
892	1	1253	1	27	8	4	3	21.88	2025-11-05 11:21:58	2025-11-05 11:21:58
893	1	1254	1	27	4	4	3	15.5	2025-11-05 11:21:58	2025-11-05 11:21:58
894	1	1255	1	27	4	4	3	80	2025-11-05 11:21:58	2025-11-05 11:21:58
895	1	1256	1	27	9	4	3	77	2025-11-05 11:21:58	2025-11-05 11:21:58
896	1	1257	1	27	10	6	3	17	2025-11-05 11:21:58	2025-11-05 11:21:58
897	1	1258	1	27	10	4	3	71.64	2025-11-05 11:21:59	2025-11-05 11:21:59
898	1	1259	1	27	4	4	3	45.1	2025-11-05 11:21:59	2025-11-05 11:21:59
899	1	1260	1	27	11	7	3	4	2025-11-05 11:21:59	2025-11-05 11:21:59
900	1	1261	1	27	12	4	3	70	2025-11-05 11:21:59	2025-11-05 11:21:59
901	1	1262	1	27	13	4	3	78	2025-11-05 11:21:59	2025-11-05 11:21:59
902	1	1263	1	27	10	4	3	87.5	2025-11-05 11:21:59	2025-11-05 11:21:59
903	1	1264	1	27	10	4	3	40	2025-11-05 11:21:59	2025-11-05 11:21:59
904	1	1265	1	27	14	4	3	85	2025-11-05 11:21:59	2025-11-05 11:21:59
905	1	1266	1	27	15	8	3	95	2025-11-05 11:21:59	2025-11-05 11:21:59
906	1	1267	1	27	16	4	3	6.7	2025-11-05 11:21:59	2025-11-05 11:21:59
907	1	1268	1	27	4	9	3	0.3	2025-11-05 11:21:59	2025-11-05 11:21:59
908	1	1269	1	27	17	4	3	93	2025-11-05 11:21:59	2025-11-05 11:21:59
909	1	1270	1	27	18	4	3	75	2025-11-05 11:21:59	2025-11-05 11:21:59
910	1	1271	1	27	19	4	3	8.9	2025-11-05 11:21:59	2025-11-05 11:21:59
911	1	1273	1	27	21	4	3	8.5	2025-11-05 11:21:59	2025-11-05 11:21:59
912	1	1274	1	27	16	4	3	29.45	2025-11-05 11:21:59	2025-11-05 11:21:59
913	1	1275	1	27	22	4	3	46	2025-11-05 11:21:59	2025-11-05 11:21:59
914	1	1276	1	27	22	4	3	7	2025-11-05 11:21:59	2025-11-05 11:21:59
915	1	1277	1	27	22	4	3	5	2025-11-05 11:21:59	2025-11-05 11:21:59
916	1	1278	1	27	16	4	3	6.9	2025-11-05 11:21:59	2025-11-05 11:21:59
917	1	1279	1	27	23	4	3	41.8	2025-11-05 11:21:59	2025-11-05 11:21:59
918	1	1280	1	27	24	4	3	17.9	2025-11-05 11:21:59	2025-11-05 11:21:59
919	1	1281	1	27	25	4	3	36	2025-11-05 11:21:59	2025-11-05 11:21:59
920	1	1282	1	27	25	4	3	61	2025-11-05 11:21:59	2025-11-05 11:21:59
921	1	1283	1	27	26	4	3	4	2025-11-05 11:21:59	2025-11-05 11:21:59
922	1	1284	1	27	26	4	3	7.1	2025-11-05 11:21:59	2025-11-05 11:21:59
923	1	1285	1	27	27	4	3	35	2025-11-05 11:21:59	2025-11-05 11:21:59
924	1	1286	1	27	28	10	3	12.84	2025-11-05 11:21:59	2025-11-05 11:21:59
925	1	1287	1	27	29	6	3	25	2025-11-05 11:21:59	2025-11-05 11:21:59
926	1	1288	1	27	30	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
927	1	1289	1	27	30	4	3	66	2025-11-05 11:21:59	2025-11-05 11:21:59
928	1	1290	1	27	4	4	3	39.92	2025-11-05 11:21:59	2025-11-05 11:21:59
929	1	1291	1	27	31	11	3	62	2025-11-05 11:21:59	2025-11-05 11:21:59
930	1	1292	1	27	32	12	3	264	2025-11-05 11:21:59	2025-11-05 11:21:59
931	1	1293	1	27	33	4	3	46.3	2025-11-05 11:21:59	2025-11-05 11:21:59
932	1	1294	1	27	33	4	3	14.6	2025-11-05 11:21:59	2025-11-05 11:21:59
933	1	1295	1	27	33	4	3	8.8	2025-11-05 11:21:59	2025-11-05 11:21:59
934	1	1296	1	27	33	4	3	15.66	2025-11-05 11:21:59	2025-11-05 11:21:59
935	1	1297	1	27	34	5	3	3.02	2025-11-05 11:21:59	2025-11-05 11:21:59
936	1	1298	1	27	35	13	3	59.5	2025-11-05 11:21:59	2025-11-05 11:21:59
937	1	1299	1	27	36	8	3	2.02	2025-11-05 11:21:59	2025-11-05 11:21:59
938	1	1300	1	27	25	4	3	40	2025-11-05 11:21:59	2025-11-05 11:21:59
939	1	1303	1	27	40	4	3	63.56	2025-11-05 11:21:59	2025-11-05 11:21:59
940	1	1304	1	27	41	4	3	57.64	2025-11-05 11:21:59	2025-11-05 11:21:59
941	1	1305	1	27	42	4	3	45	2025-11-05 11:21:59	2025-11-05 11:21:59
942	1	1306	1	27	43	4	3	7.7	2025-11-05 11:21:59	2025-11-05 11:21:59
943	1	1307	1	27	44	4	3	55	2025-11-05 11:21:59	2025-11-05 11:21:59
944	1	1308	1	27	4	4	3	71.6	2025-11-05 11:21:59	2025-11-05 11:21:59
945	1	1309	1	27	45	4	3	25	2025-11-05 11:21:59	2025-11-05 11:21:59
946	1	1310	1	27	4	4	3	9	2025-11-05 11:21:59	2025-11-05 11:21:59
947	1	1311	1	27	46	4	3	95	2025-11-05 11:21:59	2025-11-05 11:21:59
948	1	1312	1	27	46	4	3	58.02	2025-11-05 11:21:59	2025-11-05 11:21:59
949	1	1313	1	27	47	4	3	20	2025-11-05 11:21:59	2025-11-05 11:21:59
950	1	1314	1	27	48	4	3	40	2025-11-05 11:21:59	2025-11-05 11:21:59
951	1	1315	1	27	49	4	3	66.8	2025-11-05 11:21:59	2025-11-05 11:21:59
952	1	1316	1	27	50	4	3	60	2025-11-05 11:21:59	2025-11-05 11:21:59
953	1	1246	1	28	4	4	3	36.07	2025-11-05 11:21:59	2025-11-05 11:21:59
954	1	1247	1	28	4	4	3	64.84	2025-11-05 11:21:59	2025-11-05 11:21:59
955	1	1248	1	28	5	5	3	66.38	2025-11-05 11:21:59	2025-11-05 11:21:59
956	1	1249	1	28	4	4	3	85.94	2025-11-05 11:21:59	2025-11-05 11:21:59
957	1	1250	1	28	6	4	3	9	2025-11-05 11:21:59	2025-11-05 11:21:59
958	1	1251	1	28	7	4	3	57.26	2025-11-05 11:21:59	2025-11-05 11:21:59
959	1	1252	1	28	8	4	3	20.95	2025-11-05 11:21:59	2025-11-05 11:21:59
960	1	1253	1	28	8	4	3	23.77	2025-11-05 11:21:59	2025-11-05 11:21:59
961	1	1254	1	28	4	4	3	17.93	2025-11-05 11:21:59	2025-11-05 11:21:59
962	1	1255	1	28	4	4	3	83.54	2025-11-05 11:21:59	2025-11-05 11:21:59
963	1	1256	1	28	9	4	3	79	2025-11-05 11:21:59	2025-11-05 11:21:59
964	1	1257	1	28	10	6	3	17	2025-11-05 11:21:59	2025-11-05 11:21:59
965	1	1258	1	28	10	4	3	72	2025-11-05 11:21:59	2025-11-05 11:21:59
966	1	1259	1	28	4	4	3	46.87	2025-11-05 11:21:59	2025-11-05 11:21:59
967	1	1260	1	28	11	7	3	5	2025-11-05 11:21:59	2025-11-05 11:21:59
968	1	1261	1	28	12	4	3	80	2025-11-05 11:21:59	2025-11-05 11:21:59
969	1	1262	1	28	13	4	3	92	2025-11-05 11:21:59	2025-11-05 11:21:59
970	1	1263	1	28	10	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
971	1	1264	1	28	10	4	3	45	2025-11-05 11:21:59	2025-11-05 11:21:59
972	1	1265	1	28	14	4	3	90	2025-11-05 11:21:59	2025-11-05 11:21:59
973	1	1266	1	28	15	8	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
974	1	1267	1	28	16	4	3	6.5	2025-11-05 11:21:59	2025-11-05 11:21:59
975	1	1268	1	28	4	9	3	0.294	2025-11-05 11:21:59	2025-11-05 11:21:59
976	1	1269	1	28	17	4	3	94	2025-11-05 11:21:59	2025-11-05 11:21:59
977	1	1270	1	28	18	4	3	85	2025-11-05 11:21:59	2025-11-05 11:21:59
978	1	1271	1	28	19	4	3	9.3	2025-11-05 11:21:59	2025-11-05 11:21:59
979	1	1273	1	28	21	4	3	7.9	2025-11-05 11:21:59	2025-11-05 11:21:59
980	1	1274	1	28	16	4	3	29.91	2025-11-05 11:21:59	2025-11-05 11:21:59
981	1	1275	1	28	22	4	3	49	2025-11-05 11:21:59	2025-11-05 11:21:59
982	1	1276	1	28	22	4	3	8	2025-11-05 11:21:59	2025-11-05 11:21:59
983	1	1277	1	28	22	4	3	4	2025-11-05 11:21:59	2025-11-05 11:21:59
984	1	1278	1	28	16	4	3	6.8	2025-11-05 11:21:59	2025-11-05 11:21:59
985	1	1279	1	28	23	4	3	42.7	2025-11-05 11:21:59	2025-11-05 11:21:59
986	1	1280	1	28	24	4	3	19.6	2025-11-05 11:21:59	2025-11-05 11:21:59
987	1	1281	1	28	25	4	3	40	2025-11-05 11:21:59	2025-11-05 11:21:59
988	1	1282	1	28	25	4	3	62	2025-11-05 11:21:59	2025-11-05 11:21:59
989	1	1283	1	28	26	4	3	4.3	2025-11-05 11:21:59	2025-11-05 11:21:59
990	1	1284	1	28	26	4	3	7.3	2025-11-05 11:21:59	2025-11-05 11:21:59
991	1	1285	1	28	27	4	3	41.11	2025-11-05 11:21:59	2025-11-05 11:21:59
992	1	1286	1	28	28	10	3	13.11	2025-11-05 11:21:59	2025-11-05 11:21:59
993	1	1287	1	28	29	6	3	24	2025-11-05 11:21:59	2025-11-05 11:21:59
994	1	1288	1	28	30	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
995	1	1289	1	28	30	4	3	70	2025-11-05 11:21:59	2025-11-05 11:21:59
996	1	1290	1	28	4	4	3	39.92	2025-11-05 11:21:59	2025-11-05 11:21:59
997	1	1291	1	28	31	11	3	59	2025-11-05 11:21:59	2025-11-05 11:21:59
998	1	1292	1	28	32	12	3	264	2025-11-05 11:21:59	2025-11-05 11:21:59
999	1	1293	1	28	33	4	3	48.3	2025-11-05 11:21:59	2025-11-05 11:21:59
1000	1	1294	1	28	33	4	3	15.6	2025-11-05 11:21:59	2025-11-05 11:21:59
1001	1	1295	1	28	33	4	3	9.55	2025-11-05 11:21:59	2025-11-05 11:21:59
1002	1	1296	1	28	33	4	3	16.64	2025-11-05 11:21:59	2025-11-05 11:21:59
1003	1	1297	1	28	34	5	3	3.17	2025-11-05 11:21:59	2025-11-05 11:21:59
1004	1	1298	1	28	35	13	3	58.04	2025-11-05 11:21:59	2025-11-05 11:21:59
1005	1	1299	1	28	36	8	3	1.99	2025-11-05 11:21:59	2025-11-05 11:21:59
1006	1	1300	1	28	25	4	3	57	2025-11-05 11:21:59	2025-11-05 11:21:59
1007	1	1303	1	28	40	4	3	65.7	2025-11-05 11:21:59	2025-11-05 11:21:59
1008	1	1304	1	28	41	4	3	62.7	2025-11-05 11:21:59	2025-11-05 11:21:59
1009	1	1305	1	28	42	4	3	55	2025-11-05 11:21:59	2025-11-05 11:21:59
1010	1	1306	1	28	43	4	3	6.8	2025-11-05 11:21:59	2025-11-05 11:21:59
1011	1	1307	1	28	44	4	3	67	2025-11-05 11:21:59	2025-11-05 11:21:59
1012	1	1308	1	28	4	4	3	81	2025-11-05 11:21:59	2025-11-05 11:21:59
1013	1	1309	1	28	45	4	3	26.9	2025-11-05 11:21:59	2025-11-05 11:21:59
1014	1	1310	1	28	4	4	3	8.6	2025-11-05 11:21:59	2025-11-05 11:21:59
1015	1	1311	1	28	46	4	3	95	2025-11-05 11:21:59	2025-11-05 11:21:59
1016	1	1312	1	28	46	4	3	60.21	2025-11-05 11:21:59	2025-11-05 11:21:59
1017	1	1313	1	28	47	4	3	22	2025-11-05 11:21:59	2025-11-05 11:21:59
1018	1	1314	1	28	48	4	3	40	2025-11-05 11:21:59	2025-11-05 11:21:59
1019	1	1315	1	28	49	4	3	66.84	2025-11-05 11:21:59	2025-11-05 11:21:59
1020	1	1316	1	28	50	4	3	65	2025-11-05 11:21:59	2025-11-05 11:21:59
1021	1	1246	1	29	4	4	3	35.91	2025-11-05 11:21:59	2025-11-05 11:21:59
1022	1	1247	1	29	4	4	3	63.23	2025-11-05 11:21:59	2025-11-05 11:21:59
1023	1	1248	1	29	5	5	3	66.81	2025-11-05 11:21:59	2025-11-05 11:21:59
1024	1	1249	1	29	4	4	3	87.71	2025-11-05 11:21:59	2025-11-05 11:21:59
1025	1	1250	1	29	6	4	3	5.3	2025-11-05 11:21:59	2025-11-05 11:21:59
1026	1	1251	1	29	7	4	3	58.7	2025-11-05 11:21:59	2025-11-05 11:21:59
1027	1	1252	1	29	8	4	3	15.95	2025-11-05 11:21:59	2025-11-05 11:21:59
1028	1	1253	1	29	8	4	3	25.66	2025-11-05 11:21:59	2025-11-05 11:21:59
1029	1	1254	1	29	4	4	3	20.74	2025-11-05 11:21:59	2025-11-05 11:21:59
1030	1	1255	1	29	4	4	3	87.23	2025-11-05 11:21:59	2025-11-05 11:21:59
1031	1	1256	1	29	9	4	3	80	2025-11-05 11:21:59	2025-11-05 11:21:59
1032	1	1257	1	29	10	6	3	15	2025-11-05 11:21:59	2025-11-05 11:21:59
1033	1	1258	1	29	10	4	3	73	2025-11-05 11:21:59	2025-11-05 11:21:59
1034	1	1259	1	29	4	4	3	48.7	2025-11-05 11:21:59	2025-11-05 11:21:59
1035	1	1260	1	29	11	7	3	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1036	1	1261	1	29	12	4	3	90	2025-11-05 11:21:59	2025-11-05 11:21:59
1037	1	1262	1	29	13	4	3	96	2025-11-05 11:21:59	2025-11-05 11:21:59
1038	1	1263	1	29	10	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
1039	1	1264	1	29	10	4	3	50	2025-11-05 11:21:59	2025-11-05 11:21:59
1040	1	1265	1	29	14	4	3	95	2025-11-05 11:21:59	2025-11-05 11:21:59
1041	1	1266	1	29	15	8	3	105	2025-11-05 11:21:59	2025-11-05 11:21:59
1042	1	1267	1	29	16	4	3	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1043	1	1268	1	29	4	9	3	0.288	2025-11-05 11:21:59	2025-11-05 11:21:59
1044	1	1269	1	29	17	4	3	95	2025-11-05 11:21:59	2025-11-05 11:21:59
1045	1	1270	1	29	18	4	3	90	2025-11-05 11:21:59	2025-11-05 11:21:59
1046	1	1271	1	29	19	4	3	9.6	2025-11-05 11:21:59	2025-11-05 11:21:59
1047	1	1273	1	29	21	4	3	7.4	2025-11-05 11:21:59	2025-11-05 11:21:59
1048	1	1274	1	29	16	4	3	30.37	2025-11-05 11:21:59	2025-11-05 11:21:59
1049	1	1275	1	29	22	4	3	53	2025-11-05 11:21:59	2025-11-05 11:21:59
1050	1	1276	1	29	22	4	3	14	2025-11-05 11:21:59	2025-11-05 11:21:59
1051	1	1277	1	29	22	4	3	5	2025-11-05 11:21:59	2025-11-05 11:21:59
1052	1	1278	1	29	16	4	3	6.7	2025-11-05 11:21:59	2025-11-05 11:21:59
1053	1	1279	1	29	23	4	3	43.6	2025-11-05 11:21:59	2025-11-05 11:21:59
1054	1	1280	1	29	24	4	3	20.5	2025-11-05 11:21:59	2025-11-05 11:21:59
1055	1	1281	1	29	25	4	3	42	2025-11-05 11:21:59	2025-11-05 11:21:59
1056	1	1282	1	29	25	4	3	63	2025-11-05 11:21:59	2025-11-05 11:21:59
1057	1	1283	1	29	26	4	3	4.2	2025-11-05 11:21:59	2025-11-05 11:21:59
1058	1	1284	1	29	26	4	3	6.9	2025-11-05 11:21:59	2025-11-05 11:21:59
1059	1	1285	1	29	27	4	3	48.28	2025-11-05 11:21:59	2025-11-05 11:21:59
1060	1	1286	1	29	28	10	3	13.26	2025-11-05 11:21:59	2025-11-05 11:21:59
1061	1	1287	1	29	29	6	3	22	2025-11-05 11:21:59	2025-11-05 11:21:59
1062	1	1288	1	29	30	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
1063	1	1289	1	29	30	4	3	75	2025-11-05 11:21:59	2025-11-05 11:21:59
1064	1	1290	1	29	4	4	3	41.39	2025-11-05 11:21:59	2025-11-05 11:21:59
1065	1	1291	1	29	31	11	3	56	2025-11-05 11:21:59	2025-11-05 11:21:59
1066	1	1292	1	29	32	12	3	240.8	2025-11-05 11:21:59	2025-11-05 11:21:59
1067	1	1293	1	29	33	4	3	50.3	2025-11-05 11:21:59	2025-11-05 11:21:59
1068	1	1294	1	29	33	4	3	16.6	2025-11-05 11:21:59	2025-11-05 11:21:59
1069	1	1295	1	29	33	4	3	10.3	2025-11-05 11:21:59	2025-11-05 11:21:59
1070	1	1296	1	29	33	4	3	17.62	2025-11-05 11:21:59	2025-11-05 11:21:59
1071	1	1297	1	29	34	5	3	3.34	2025-11-05 11:21:59	2025-11-05 11:21:59
1072	1	1298	1	29	35	13	3	56.61	2025-11-05 11:21:59	2025-11-05 11:21:59
1073	1	1299	1	29	36	8	3	1.96	2025-11-05 11:21:59	2025-11-05 11:21:59
1074	1	1300	1	29	25	4	3	28	2025-11-05 11:21:59	2025-11-05 11:21:59
1075	1	1303	1	29	40	4	3	67.91	2025-11-05 11:21:59	2025-11-05 11:21:59
1076	1	1304	1	29	41	4	3	67.77	2025-11-05 11:21:59	2025-11-05 11:21:59
1077	1	1305	1	29	42	4	3	65	2025-11-05 11:21:59	2025-11-05 11:21:59
1078	1	1306	1	29	43	4	3	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1079	1	1307	1	29	44	4	3	82	2025-11-05 11:21:59	2025-11-05 11:21:59
1080	1	1308	1	29	4	4	3	90.5	2025-11-05 11:21:59	2025-11-05 11:21:59
1081	1	1309	1	29	45	4	3	29	2025-11-05 11:21:59	2025-11-05 11:21:59
1082	1	1310	1	29	4	4	3	8.3	2025-11-05 11:21:59	2025-11-05 11:21:59
1083	1	1311	1	29	46	4	3	95	2025-11-05 11:21:59	2025-11-05 11:21:59
1084	1	1312	1	29	46	4	3	62.4	2025-11-05 11:21:59	2025-11-05 11:21:59
1085	1	1313	1	29	47	4	3	25	2025-11-05 11:21:59	2025-11-05 11:21:59
1086	1	1314	1	29	48	4	3	40	2025-11-05 11:21:59	2025-11-05 11:21:59
1087	1	1315	1	29	49	4	3	66.88	2025-11-05 11:21:59	2025-11-05 11:21:59
1088	1	1316	1	29	50	4	3	68	2025-11-05 11:21:59	2025-11-05 11:21:59
1089	1	1246	1	30	4	4	3	34.71	2025-11-05 11:21:59	2025-11-05 11:21:59
1090	1	1247	1	30	4	4	3	61.65	2025-11-05 11:21:59	2025-11-05 11:21:59
1091	1	1248	1	30	5	5	3	67.24	2025-11-05 11:21:59	2025-11-05 11:21:59
1092	1	1249	1	30	4	4	3	89.51	2025-11-05 11:21:59	2025-11-05 11:21:59
1093	1	1250	1	30	6	4	3	1.5	2025-11-05 11:21:59	2025-11-05 11:21:59
1094	1	1251	1	30	7	4	3	60.18	2025-11-05 11:21:59	2025-11-05 11:21:59
1095	1	1252	1	30	8	4	3	10.95	2025-11-05 11:21:59	2025-11-05 11:21:59
1096	1	1253	1	30	8	4	3	27.54	2025-11-05 11:21:59	2025-11-05 11:21:59
1097	1	1254	1	30	4	4	3	23.99	2025-11-05 11:21:59	2025-11-05 11:21:59
1098	1	1255	1	30	4	4	3	91.09	2025-11-05 11:21:59	2025-11-05 11:21:59
1099	1	1256	1	30	9	4	3	80	2025-11-05 11:21:59	2025-11-05 11:21:59
1100	1	1257	1	30	10	6	3	15	2025-11-05 11:21:59	2025-11-05 11:21:59
1101	1	1258	1	30	10	4	3	74	2025-11-05 11:21:59	2025-11-05 11:21:59
1102	1	1259	1	30	4	4	3	50.61	2025-11-05 11:21:59	2025-11-05 11:21:59
1103	1	1260	1	30	11	7	3	7	2025-11-05 11:21:59	2025-11-05 11:21:59
1104	1	1261	1	30	12	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
1105	1	1262	1	30	13	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
1106	1	1263	1	30	10	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
1107	1	1264	1	30	10	4	3	50	2025-11-05 11:21:59	2025-11-05 11:21:59
1108	1	1265	1	30	14	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
1109	1	1266	1	30	15	8	3	110	2025-11-05 11:21:59	2025-11-05 11:21:59
1110	1	1267	1	30	16	4	3	6	2025-11-05 11:21:59	2025-11-05 11:21:59
1111	1	1268	1	30	4	9	3	0.283	2025-11-05 11:21:59	2025-11-05 11:21:59
1112	1	1269	1	30	17	4	3	96	2025-11-05 11:21:59	2025-11-05 11:21:59
1113	1	1270	1	30	18	4	3	95	2025-11-05 11:21:59	2025-11-05 11:21:59
1114	1	1271	1	30	19	4	3	9.8	2025-11-05 11:21:59	2025-11-05 11:21:59
1115	1	1273	1	30	21	4	3	6.8	2025-11-05 11:21:59	2025-11-05 11:21:59
1116	1	1274	1	30	16	4	3	30.84	2025-11-05 11:21:59	2025-11-05 11:21:59
1117	1	1275	1	30	22	4	3	56	2025-11-05 11:21:59	2025-11-05 11:21:59
1118	1	1276	1	30	22	4	3	16	2025-11-05 11:21:59	2025-11-05 11:21:59
1119	1	1277	1	30	22	4	3	5	2025-11-05 11:21:59	2025-11-05 11:21:59
1120	1	1278	1	30	16	4	3	6.6	2025-11-05 11:21:59	2025-11-05 11:21:59
1121	1	1279	1	30	23	4	3	44.5	2025-11-05 11:21:59	2025-11-05 11:21:59
1122	1	1280	1	30	24	4	3	21.5	2025-11-05 11:21:59	2025-11-05 11:21:59
1123	1	1281	1	30	25	4	3	45	2025-11-05 11:21:59	2025-11-05 11:21:59
1124	1	1282	1	30	25	4	3	64	2025-11-05 11:21:59	2025-11-05 11:21:59
1125	1	1283	1	30	26	4	3	4.2	2025-11-05 11:21:59	2025-11-05 11:21:59
1126	1	1284	1	30	26	4	3	6.5	2025-11-05 11:21:59	2025-11-05 11:21:59
1127	1	1285	1	30	27	4	3	56.71	2025-11-05 11:21:59	2025-11-05 11:21:59
1128	1	1286	1	30	28	10	3	13.41	2025-11-05 11:21:59	2025-11-05 11:21:59
1129	1	1287	1	30	29	6	3	20	2025-11-05 11:21:59	2025-11-05 11:21:59
1130	1	1288	1	30	30	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
1131	1	1289	1	30	30	4	3	80	2025-11-05 11:21:59	2025-11-05 11:21:59
1132	1	1290	1	30	4	4	3	42.92	2025-11-05 11:21:59	2025-11-05 11:21:59
1133	1	1291	1	30	31	11	3	54	2025-11-05 11:21:59	2025-11-05 11:21:59
1134	1	1292	1	30	32	12	3	240.8	2025-11-05 11:21:59	2025-11-05 11:21:59
1135	1	1293	1	30	33	4	3	52.3	2025-11-05 11:21:59	2025-11-05 11:21:59
1136	1	1294	1	30	33	4	3	17.6	2025-11-05 11:21:59	2025-11-05 11:21:59
1137	1	1295	1	30	33	4	3	11.05	2025-11-05 11:21:59	2025-11-05 11:21:59
1138	1	1296	1	30	33	4	3	18.6	2025-11-05 11:21:59	2025-11-05 11:21:59
1139	1	1297	1	30	34	5	3	3.52	2025-11-05 11:21:59	2025-11-05 11:21:59
1140	1	1298	1	30	35	13	3	55.22	2025-11-05 11:21:59	2025-11-05 11:21:59
1141	1	1299	1	30	36	8	3	1.93	2025-11-05 11:21:59	2025-11-05 11:21:59
1142	1	1300	1	30	25	4	3	10	2025-11-05 11:21:59	2025-11-05 11:21:59
1143	1	1303	1	30	40	4	3	70.2	2025-11-05 11:21:59	2025-11-05 11:21:59
1144	1	1304	1	30	41	4	3	72.83	2025-11-05 11:21:59	2025-11-05 11:21:59
1145	1	1305	1	30	42	4	3	80	2025-11-05 11:21:59	2025-11-05 11:21:59
1146	1	1306	1	30	43	4	3	5.3	2025-11-05 11:21:59	2025-11-05 11:21:59
1147	1	1307	1	30	44	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
1148	1	1308	1	30	4	4	3	100	2025-11-05 11:21:59	2025-11-05 11:21:59
1149	1	1309	1	30	45	4	3	31.3	2025-11-05 11:21:59	2025-11-05 11:21:59
1150	1	1310	1	30	4	4	3	7.9	2025-11-05 11:21:59	2025-11-05 11:21:59
1151	1	1311	1	30	46	4	3	95	2025-11-05 11:21:59	2025-11-05 11:21:59
1152	1	1312	1	30	46	4	3	64.59	2025-11-05 11:21:59	2025-11-05 11:21:59
1153	1	1313	1	30	47	4	3	27	2025-11-05 11:21:59	2025-11-05 11:21:59
1154	1	1314	1	30	48	4	3	40	2025-11-05 11:21:59	2025-11-05 11:21:59
1155	1	1315	1	30	49	4	3	66.92	2025-11-05 11:21:59	2025-11-05 11:21:59
1156	1	1316	1	30	50	4	3	70	2025-11-05 11:21:59	2025-11-05 11:21:59
1157	2	1246	1	25	4	4	3	42.2	2025-11-12 16:30:49	2025-11-12 16:30:49
1158	2	1247	1	25	4	4	3	72.5	2025-11-12 16:30:49	2025-11-12 16:30:49
1159	2	1248	1	25	5	5	3	66.9	2025-11-12 16:30:49	2025-11-12 16:30:49
1160	2	1249	1	25	4	4	3	80.2	2025-11-12 16:30:49	2025-11-12 16:30:49
1161	2	1250	1	25	6	4	3	21.3	2025-11-12 16:30:49	2025-11-12 16:30:49
1162	2	1251	1	25	7	4	3	51.37	2025-11-12 16:30:49	2025-11-12 16:30:49
1163	2	1252	1	25	8	4	3	36.95	2025-11-12 16:30:49	2025-11-12 16:30:49
\.


--
-- TOC entry 5485 (class 0 OID 27166)
-- Dependencies: 270
-- Data for Name: etude_identifications; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.etude_identifications (id, projet_id, etude_id, etude_disponible, document_etude, etude_envisagee, source_financement_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5489 (class 0 OID 27180)
-- Dependencies: 274
-- Data for Name: etudes; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.etudes (id, intitule, created_at, updated_at) FROM stdin;
1	Document d'identification de projet	2025-11-10 00:02:26	2025-11-10 00:02:26
2	Etude pré-faisabilité	2025-11-10 00:02:43	2025-11-10 00:02:43
3	Document d'evaluation de projet	2025-11-10 00:02:58	2025-11-10 00:02:58
4	Etudes de faisabilité technique et financière	2025-11-10 00:03:19	2025-11-10 00:03:19
5	Etudes d’impact environnemental	2025-11-10 00:03:39	2025-11-10 00:03:39
6	Etudes d’analyse socioéconomique	2025-11-10 00:04:00	2025-11-10 00:04:00
7	Etudes géotechniques	2025-11-10 00:04:16	2025-11-10 00:04:16
8	Etudes architecturales et topographiques ;	2025-11-10 00:04:52	2025-11-10 00:04:52
9	Etudes bathymétriques	2025-11-10 00:05:19	2025-11-10 00:05:19
10	Etudes hydrauliques et hydro-morphiques ;	2025-11-10 00:05:36	2025-11-10 00:05:36
11	Etudes routières ;	2025-11-10 00:06:22	2025-11-10 00:06:22
12	Elaboration d’un plan d’affaires dans le cadre des PPP	2025-11-10 09:24:21	2025-11-10 09:24:21
13	Autres Etudes à préciser	2025-11-10 09:24:39	2025-11-10 09:24:39
\.


--
-- TOC entry 5442 (class 0 OID 26869)
-- Dependencies: 227
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- TOC entry 5505 (class 0 OID 27406)
-- Dependencies: 291
-- Data for Name: hypothese_risques; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.hypothese_risques (id, cadre_logique_id, hypothese, risque, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5454 (class 0 OID 26922)
-- Dependencies: 239
-- Data for Name: indicateurs; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.indicateurs (id, code, intitule, definition, donnees_requises, methode_calcul, methode_collecte, source, commentaire_limite, niveau_desagregation, periodicite, unite, echelle, lien_avec_cadre_developpement, created_at, updated_at) FROM stdin;
1246	\N	Proportion de la population vivant en dessous du seuil national de pauvreté	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1247	\N	Incidence de la pauvreté multidimensionnelle	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1248	\N	Espérance de vie à la naissance 	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1249	\N	Taux de satisfaction des populations vis-à-vis des services des forces de défense et de sécurité	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1250	\N	Proportion des communes déclarées en état d’urgence	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1251	\N	Proportion des frontières du territoire délimités et abornées (en distance kilométrique)	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1252	\N	Taux de variation des conflits inter et intra-communautaires	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1253	\N	Proportion de comités de Paix opérationnels pour la prévention et la gestion des conflits communautaires	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1254	\N	Proportion de la population estimant que les informations fournies par les autorités centrales sur le budget et les politiques publiques sont suffisantes	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1255	\N	Proportion de la population ayant contribué à au moins une action de développement bénévolement	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1256	\N	Taux de satisfaction des usagers des services judiciaires	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1257	\N	Délai moyen de traitement des affaires pénales 	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1258	\N	Taux de couverture juridictionnelle	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1259	\N	Proportion de la population estimant que leurs préoccupations/demandes sont prises en compte par les autorités politiques	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1260	\N	Ratio d'encadrement administratif	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1261	\N	Pourcentage des collectivités qui ont déposé leurs comptes de gestion dans les délais	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1262	\N	Proportion des communes ayant élaboré le rapport annuel sur l’état général de la commune	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1263	\N	Proportion des institutions opérationnelles prévues par la charte de la refondation de la République 	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1264	\N	Degré de perception de la population sur le respect des droits humains	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1265	\N	Proportion de compétitions internationales auxquelles le Niger a obtenu de médailles et autres distinctions	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1266	\N	Nombre d’événements sportif régionaux et internationaux auxquels le Niger a participé	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1267	\N	Taux de croissance annuelle du PIB réel	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1268	\N	Indice de répartition des revenus (Indice de Gini)	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1269	\N	Taux d’exécution du budget de l’Etat	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1270	\N	Proportion des cadres stratégiques sectoriels conformes aux priorités nationales	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1271	\N	Taux de pression fiscale	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1272	\N	Part des ressources extérieures dans le budget national	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1273	\N	Part de quantité de céréales importées par rapport aux besoins	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1274	\N	Part de l'agriculture dans le PIB	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1275	\N	Part de la production des cultures irriguées dans la production agricole	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1276	\N	Taux d’accroissement des productions des cultures irriguées	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1277	\N	Taux d’accroissement des productions des cultures pluviales	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1278	\N	Part de l'élevage dans le PIB	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1279	\N	Indice d’accessibilité rurale	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1280	\N	Taux d’écoulement des produits agricoles entre le Niger et le reste du Monde	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1281	\N	Proportion des plateformes de commerces ayant une rubrique agricole	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1282	\N	Proportion d’unités agro-industrielles opérationnelles	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1283	\N	Part des activités minières dans le PIB (Uranate+Or)	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1284	\N	Part des activités extractives pétrolières dans le PIB 	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1285	\N	Taux d’accès national à l’électricité (Toutes les sources)	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1286	\N	Densité routière	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1287	\N	Délai moyen d’acheminement des marchandises à partir des principaux ports de transit 	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1288	\N	Taux de pénétration mobile	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1289	\N	Taux de pénétration internet haut débit	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1290	\N	Taux d'alphabétisation	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1291	\N	Taux de mortalité des enfants de moins de 5 ans	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1292	\N	Taux de mortalité maternelle	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1293	\N	Taux d’achèvement primaire (TAP) 	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1294	\N	Taux d'achèvement Global au cycle de base 2	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1295	\N	Taux d'achèvement Global au cycle moyen	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1296	\N	Proportion (%) d’apprenants inscrits à l’EFTP formel par rapport à ceux de l'enseignement secondaire général	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1297	\N	Durée Moyenne de scolarisation 	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1298	\N	Ratio étudiants/enseignants dans les Universités Publiques du Niger	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1299	\N	Nombre d’étudiants pour une place assise en amphithéâtre	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1300	\N	Taux de variation de brevets délivrés	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1301	\N	Dépense de recherche et développement en pourcentage du budget national	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1302	\N	Proportion de projets de recherche financés	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1303	\N	Taux de couverture sanitaire	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1304	\N	Taux d’accouchements assistés par un personnel qualifié	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1305	\N	Proportion d’établissements de santé utilisant un dispositif adéquat de gestion des déchets d’activités de soins (GDAS)	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1306	\N	Prévalence de la malnutrition aiguë globale chez les enfants de 6 à 59 mois	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1307	\N	Pourcentage de personnes affectées assistées en vivres et biens non alimentaires	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1308	\N	Pourcentage des ménages en insécurité alimentaire bénéficiaires de transferts sociaux prévisibles caractérisés des pauvres 	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1309	\N	Taux de placement des jeunes 	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1310	\N	Taux de chômage des jeunes (15 à 34 ans) 	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1311	\N	Taux de couverture géographique en eau potable en milieu rural	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1312	\N	Taux d’accès théorique à l’eau potable en milieu rural	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1313	\N	Taux des Communes Urbaines/ Villes ayant un plan de gestion des déchets (PGD)	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1314	\N	Taux de valorisation des déchets ménagers	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1315	\N	Proportion des centres urbains disposant d’un outil de planification urbaine (SDAU, PUR, CDU, SDEP)	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
1316	\N	Taux de réalisation de logements sociaux	\N	\N	\N	\N	\N	\N	\N	\N	\N		\N	2025-11-04 17:00:36	2025-11-04 17:00:36
\.


--
-- TOC entry 5479 (class 0 OID 27141)
-- Dependencies: 264
-- Data for Name: institution_tutelles; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.institution_tutelles (id, intitule, created_at, updated_at) FROM stdin;
1	Ministère de l'Economie et des Finances	2025-11-08 10:16:53	2025-11-08 10:16:53
\.


--
-- TOC entry 5440 (class 0 OID 26861)
-- Dependencies: 225
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- TOC entry 5439 (class 0 OID 26852)
-- Dependencies: 224
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- TOC entry 5431 (class 0 OID 26804)
-- Dependencies: 216
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2025_08_28_123720_create_zones_table	1
5	2025_08_28_123721_create_cadre_developpements_table	1
6	2025_08_28_123722_create_piece_jointes_table	1
7	2025_08_28_123723_create_cadre_logiques_table	1
8	2025_08_28_123724_create_orientation_cadre_developpements_table	1
9	2025_08_28_123725_create_indicateurs_table	1
10	2025_08_28_123726_create_donnee_indicateurs_table	1
11	2025_08_28_123727_create_desagregations_table	1
12	2025_08_28_123728_create_type_desagregations_table	1
13	2025_08_28_123729_create_nature_donnees_table	1
14	2025_08_28_123730_create_periodes_table	1
15	2025_08_28_123731_create_source_indicateurs_table	1
16	2025_08_28_123732_create_unite_indicateurs_table	1
17	2025_08_28_123733_create_commentaire_valeur_indicateurs_table	1
18	2025_10_01_185114_create_projets_table	2
19	2025_10_01_185115_create_zone_interventions_table	2
20	2025_10_01_185116_create_priorites_table	2
21	2025_10_01_185117_create_institution_tutelles_table	2
22	2025_10_01_185118_create_population_cibles_table	2
23	2025_10_01_185119_create_population_cible_projets_table	2
24	2025_10_01_185120_create_etude_identifications_table	2
25	2025_10_01_185121_create_recherche_financements_table	2
26	2025_10_01_185122_create_etudes_table	2
27	2025_10_01_185123_create_source_financements_table	2
28	2025_10_01_185124_create_mode_financements_table	2
29	2025_10_01_185125_create_niveau_financements_table	2
30	2025_10_01_185126_create_hypothese_risques_table	2
31	2025_10_01_185127_create_positionnement_strategiques_table	2
32	2025_01_01_000001_create_roles_table	3
33	2025_01_01_000002_create_permissions_table	3
34	2025_01_01_000003_create_role_user_table	3
35	2025_01_01_000004_create_permission_role_table	3
\.


--
-- TOC entry 5462 (class 0 OID 26956)
-- Dependencies: 247
-- Data for Name: nature_donnees; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.nature_donnees (id, intitule, created_at, updated_at) FROM stdin;
1	Prévision	2025-09-28 19:03:23	2025-09-28 19:03:23
2	Réalisation	2025-09-28 19:51:32	2025-09-28 19:53:54
3	Valeur de référence	2025-10-27 08:34:05	2025-10-27 08:34:05
\.


--
-- TOC entry 5493 (class 0 OID 27198)
-- Dependencies: 278
-- Data for Name: nature_financements; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.nature_financements (id, intitule, created_at, updated_at) FROM stdin;
1	ANR	2025-11-12 12:04:34	2025-11-12 12:04:34
2	EMPRUNT	2025-11-12 12:04:46	2025-11-12 12:04:46
3	FONDS PROPRES	2025-11-12 12:04:58	2025-11-12 12:04:58
4	FONDS DE CONTREPARTIE	2025-11-12 12:05:12	2025-11-12 12:05:12
5	BENEFICIAIRES	2025-11-12 12:05:25	2025-11-12 12:05:25
6	PPP	2025-11-12 12:05:37	2025-11-12 12:05:37
7	COLLECTIVITES	2025-11-12 12:05:49	2025-11-12 12:05:49
8	AUTRES A PRECISER	2025-11-12 12:06:02	2025-11-12 12:06:02
\.


--
-- TOC entry 5452 (class 0 OID 26915)
-- Dependencies: 237
-- Data for Name: orientation_cadre_developpements; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.orientation_cadre_developpements (id, intitule, cadre_developpement_id, cadre_logique_id, created_at, updated_at) FROM stdin;
4	CMR	5	60	2025-09-10 15:32:47	2025-09-10 15:32:47
5	CMR PRSP	4	64	2025-09-10 16:00:19	2025-09-10 16:00:19
6	Axe PRSP	4	68	2025-09-10 16:01:31	2025-09-10 16:01:31
7	TEst CMR	5	71	2025-09-19 11:27:58	2025-09-19 11:27:58
8	CMR	8	73	2025-09-24 10:35:31	2025-09-24 10:35:31
9	Axes Stratégiques	8	77	2025-09-24 10:43:47	2025-09-24 10:43:47
10	CMR	9	82	2025-10-14 09:04:11	2025-10-14 09:04:11
11	Cadre logique	9	86	2025-10-14 09:27:22	2025-10-14 09:27:22
12	Cadre logique	9	87	2025-10-14 09:27:33	2025-10-14 09:27:33
13	Axes	9	90	2025-10-14 10:06:16	2025-10-14 10:06:16
14	CMR2	9	96	2025-10-29 10:18:47	2025-10-29 10:18:47
15	CMR du PRR	11	98	2025-11-04 16:39:40	2025-11-04 16:39:40
16	Impact	15	122	2025-11-12 15:42:16	2025-11-12 15:42:16
17	Logique d'intervention PRR	15	123	2025-11-12 15:43:03	2025-11-12 15:43:03
18	CMR du PRR	17	125	2025-11-13 08:48:49	2025-11-13 08:48:49
\.


--
-- TOC entry 5434 (class 0 OID 26821)
-- Dependencies: 219
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- TOC entry 5464 (class 0 OID 26965)
-- Dependencies: 249
-- Data for Name: periodes; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.periodes (id, intitule, created_at, updated_at) FROM stdin;
1	2000	2025-09-28 18:46:38	2025-11-05 09:20:19
2	2001	2025-09-28 18:46:48	2025-11-05 09:20:36
3	2002	\N	\N
4	2003	\N	\N
5	2004	\N	\N
6	2005	\N	\N
7	2006	\N	\N
8	2007	\N	\N
9	2008	\N	\N
10	2009	\N	\N
11	2010	\N	\N
12	2011	\N	\N
13	2012	\N	\N
14	2013	\N	\N
15	2014	\N	\N
16	2015	\N	\N
17	2016	\N	\N
18	2017	\N	\N
19	2018	\N	\N
20	2019	\N	\N
21	2020	\N	\N
22	2021	\N	\N
23	2022	\N	\N
24	2023	\N	\N
25	2024	\N	\N
26	2025	\N	\N
27	2026	\N	\N
28	2027	\N	\N
29	2028	\N	\N
30	2029	\N	\N
31	2030	\N	\N
\.


--
-- TOC entry 5501 (class 0 OID 27268)
-- Dependencies: 286
-- Data for Name: permission_role; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.permission_role (permission_id, role_id) FROM stdin;
1	1
\.


--
-- TOC entry 5499 (class 0 OID 27243)
-- Dependencies: 284
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.permissions (id, name, label, created_at, updated_at) FROM stdin;
1	administration	administration	2025-10-21 11:42:29	2025-10-21 11:42:29
\.


--
-- TOC entry 5521 (class 0 OID 27547)
-- Dependencies: 307
-- Data for Name: piece_jointe_activites; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.piece_jointe_activites (id, intitule, fichier, created_at, updated_at, activite_id) FROM stdin;
\.


--
-- TOC entry 5511 (class 0 OID 27475)
-- Dependencies: 297
-- Data for Name: piece_jointe_produits; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.piece_jointe_produits (id, intitule, fichier, created_at, updated_at, produit_id) FROM stdin;
\.


--
-- TOC entry 5533 (class 0 OID 27762)
-- Dependencies: 322
-- Data for Name: piece_jointe_projets; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.piece_jointe_projets (id, intitule, fichier, created_at, updated_at, projet_id) FROM stdin;
1	PRSP	pieces/Cp6zVp4yIFhpo8yBBPZz3nIDll3yE0GsaV4YoPrI.xlsx	2025-11-08 21:42:34	2025-11-08 21:42:34	2
2	Kandadji	pieces/bFM2pxZX4TM3uKGQcOd8qBlMKBzQJpVZztpMIzk8.xlsx	2025-11-08 21:48:56	2025-11-08 21:48:56	2
3	document du projet	pieces/niYynUCw8NbZMud9gTzHLGAminHpZcrGPcMU9J1t.pdf	2025-11-12 16:48:07	2025-11-12 16:48:07	3
4	test	pieces/CoAU91oTwS37ZCEWm9Z8TKNCQT608suk3XtOJEP0.txt	2025-11-12 23:53:25	2025-11-12 23:53:25	1
\.


--
-- TOC entry 5448 (class 0 OID 26899)
-- Dependencies: 233
-- Data for Name: piece_jointes; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.piece_jointes (id, intitule, fichier, created_at, updated_at, cadre_developpement_id) FROM stdin;
9	test	pieces/HRSI5D9dkro2iJqr5gTlhRH1PcqLEB6kHYHDJhZr.pdf	2025-11-12 23:35:03	2025-11-12 23:35:03	16
10	document de programme	pieces/2gpwvXafIw2eeqAL5YCYsIVACXKYPfscQAtxPWC0.xlsx	2025-11-13 08:46:59	2025-11-13 08:46:59	11
11	autre document	pieces/nems2XusBa0YOKeYmoqtJ0mNFXvHNWt7JJ2w6uXq.pdf	2025-11-13 08:47:24	2025-11-13 08:47:24	11
\.


--
-- TOC entry 5481 (class 0 OID 27150)
-- Dependencies: 266
-- Data for Name: population_cibles; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.population_cibles (id, intitule, created_at, updated_at) FROM stdin;
1	Rurale Sédentaire	2025-11-09 13:46:37	2025-11-09 13:46:37
2	Rurale Nomade	2025-11-09 13:47:05	2025-11-09 13:47:05
3	Urbaine	2025-11-09 13:47:21	2025-11-09 13:47:21
4	Totale	2025-11-09 13:47:53	2025-11-09 13:47:53
\.


--
-- TOC entry 5477 (class 0 OID 27132)
-- Dependencies: 262
-- Data for Name: priorites; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.priorites (id, intitule, created_at, updated_at) FROM stdin;
1	Non précisé	2025-10-11 13:16:06	2025-10-11 13:16:06
2	Haute	2025-10-11 13:16:20	2025-10-11 13:16:20
3	Moyenne	2025-10-11 13:16:33	2025-10-11 13:16:33
4	Basse	2025-10-11 13:16:45	2025-10-11 13:16:45
5	A attribuer	2025-10-11 13:48:04	2025-10-11 13:48:04
\.


--
-- TOC entry 5523 (class 0 OID 27561)
-- Dependencies: 309
-- Data for Name: produit_zone; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.produit_zone (id, produit_id, zone_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5509 (class 0 OID 27445)
-- Dependencies: 295
-- Data for Name: produits; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.produits (id, cadre_logique_id, intitule, annee_debut_prevu, annee_fin_prevu, duree_travaux, cout_prevu, responsable, contact_responsable, statut_produit_id, description, date_debut_realisation, date_fin_realisation, cout_realisation, latitude, longitude, created_at, updated_at, type_produit_id) FROM stdin;
\.


--
-- TOC entry 5531 (class 0 OID 27743)
-- Dependencies: 320
-- Data for Name: projet_cadre_logique; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.projet_cadre_logique (id, projet_id, cadre_logique_id, created_at, updated_at) FROM stdin;
1	1	113	2025-11-08 15:28:35	2025-11-08 15:28:35
2	2	102	2025-11-08 16:10:58	2025-11-08 16:10:58
3	3	103	2025-11-12 16:47:24	2025-11-12 16:47:24
\.


--
-- TOC entry 5535 (class 0 OID 27781)
-- Dependencies: 324
-- Data for Name: projet_etude_disponible; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.projet_etude_disponible (id, projet_id, etude_id, created_at, updated_at, fichier) FROM stdin;
1	2	1	2025-11-10 10:56:11	2025-11-10 10:56:11	pieces/fLjOwiG5QLGqaXmTYG8NAWG5iE0OnpktUtajRGVO.xlsx
3	3	1	2025-11-12 16:49:44	2025-11-12 16:49:44	pieces/0MjiDsjfXzsMyxG8veTcYXdFrKqd0kqSQqEneZlf.docx
\.


--
-- TOC entry 5537 (class 0 OID 27788)
-- Dependencies: 326
-- Data for Name: projet_etude_envisagee; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.projet_etude_envisagee (id, projet_id, etude_id, source_financement_id, created_at, updated_at) FROM stdin;
1	2	1	2	2025-11-10 12:31:17	2025-11-11 17:12:13
3	3	5	1	2025-11-12 16:50:06	2025-11-12 16:50:06
\.


--
-- TOC entry 5541 (class 0 OID 27816)
-- Dependencies: 330
-- Data for Name: projet_financement; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.projet_financement (id, projet_id, source_financement_id, ptf_id, statut_financement_id, nature_financement_id, montant, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5483 (class 0 OID 27159)
-- Dependencies: 268
-- Data for Name: projet_population_cible; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.projet_population_cible (id, projet_id, population_cible_id, created_at, updated_at, effectif) FROM stdin;
5	2	1	2025-11-09 17:53:23	2025-11-09 22:59:18	250
6	2	2	2025-11-09 19:46:53	2025-11-11 11:23:05	500
7	3	1	2025-11-12 16:48:25	2025-11-12 16:48:25	100
8	3	2	2025-11-12 16:48:35	2025-11-12 16:48:35	100
\.


--
-- TOC entry 5529 (class 0 OID 27724)
-- Dependencies: 318
-- Data for Name: projet_zone; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.projet_zone (id, projet_id, zone_id, created_at, updated_at) FROM stdin;
1	1	3	2025-11-08 15:28:35	2025-11-08 15:28:35
2	1	4	2025-11-08 15:28:35	2025-11-08 15:28:35
3	1	5	2025-11-08 15:28:35	2025-11-08 15:28:35
4	2	3	2025-11-08 16:10:58	2025-11-08 16:10:58
5	2	4	2025-11-08 16:10:58	2025-11-08 16:10:58
6	2	5	2025-11-08 16:10:58	2025-11-08 16:10:58
7	3	1	2025-11-12 16:47:24	2025-11-12 16:47:24
\.


--
-- TOC entry 5475 (class 0 OID 27116)
-- Dependencies: 260
-- Data for Name: projets; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.projets (id, sigle, intitule, priorite_id, institution_tutelle_id, direction_agence, contact, cout, annee_demarrage, date_debut_prevue, date_fin_prevue, duree, created_at, updated_at, statut_projet_id, date_debut_effective, date_fin_effective, projet_id, cadre_developpement_id) FROM stdin;
2	Kandadji	Kandadji	2	1	DGPPD	90217087	87897946	\N	2020-11-03	2027-11-08	58	2025-11-08 16:10:58	2025-11-09 01:41:49	2	\N	\N	1	14
3	PHASAOC	PHASAOC	2	1	INS/DCMIS	90217087	7896524	2024	\N	\N	60	2025-11-12 16:47:24	2025-11-12 16:50:43	1	\N	\N	\N	16
1	PCRSS	PCRSS	3	1	DGPPD	90217087	123456	2022	\N	\N	48	2025-11-08 15:28:35	2025-11-12 23:59:32	1	\N	\N	\N	\N
\.


--
-- TOC entry 5539 (class 0 OID 27795)
-- Dependencies: 328
-- Data for Name: ptfs; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.ptfs (id, intitule, created_at, updated_at) FROM stdin;
1	Banque Mondiale	2025-11-12 12:14:53	2025-11-12 12:14:53
2	UNICEF	2025-11-12 12:15:47	2025-11-12 12:15:47
\.


--
-- TOC entry 5487 (class 0 OID 27173)
-- Dependencies: 272
-- Data for Name: recherche_financements; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.recherche_financements (id, projet_id, source_financement_id, niveau_financement_id, mode_financement_id, bailleurs, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5500 (class 0 OID 27253)
-- Dependencies: 285
-- Data for Name: role_user; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.role_user (role_id, user_id) FROM stdin;
1	1
\.


--
-- TOC entry 5497 (class 0 OID 27232)
-- Dependencies: 282
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.roles (id, name, label, created_at, updated_at) FROM stdin;
1	admin	admin	2025-10-21 11:43:07	2025-10-21 11:43:07
\.


--
-- TOC entry 5435 (class 0 OID 26828)
-- Dependencies: 220
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
465is5hsEQbL2VZ8EqVA6nseu9n2QEmOs1AhgZz4	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSHdjZXlBYVp1aHE1RnhYc2xWQnNFNkw0QzV2bWx6a1BXUFRFMmpaQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9jYWRyZV9kZXZlbG9wcGVtZW50cy8xNC9jYWRyZXNfbG9naXF1ZXMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1763031703
\.


--
-- TOC entry 5491 (class 0 OID 27189)
-- Dependencies: 276
-- Data for Name: source_financements; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.source_financements (id, intitule, created_at, updated_at) FROM stdin;
1	Etat	2025-11-10 12:17:33	2025-11-10 12:17:33
2	PTFs	2025-11-11 11:16:08	2025-11-11 11:16:08
\.


--
-- TOC entry 5466 (class 0 OID 26974)
-- Dependencies: 251
-- Data for Name: source_indicateurs; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.source_indicateurs (id, intitule, created_at, updated_at) FROM stdin;
4	INS, 2021, EHCVM	\N	\N
5	INS, 2019, Rapport sur les projections démographiques	\N	\N
6	Rapport Ministère en charge de l'intérieur	\N	\N
7	Rapport Ministère en charge de l'intérieur 2022	\N	\N
8	HACP	\N	\N
9	MJDH, 2022, Rapport d'enquête sur les besoins et la satisfaction en matière de justice	\N	\N
10	MJDH	\N	\N
11	RAP du ministère en charge de la fonction publique	\N	\N
12	Cour des comptes, 2021, Rapport d'activité	\N	\N
13	Ministère de l'intérieur	\N	\N
14	MJCAS	\N	\N
15	Annuaire MJCAS	\N	\N
16	INS, 2024, comptes nationaux annuels (CNA) révisés 2015-2022 et provisoires 2023-2024	\N	\N
17	MEF/DGPPD-DGB	\N	\N
18	MEF/DGPPD	\N	\N
19	MEF	\N	\N
20	DGB	\N	\N
21	Ministère de l'Agriculture et l'Elevage	\N	\N
22	Rapport DS/MAG/EL, RAP et RAC du MAG/EL	\N	\N
23	MEq, 2022, RAP	\N	\N
24	INS, 2023, Bulletin des statistiques du commerce extérieur	\N	\N
25	Ministère du Commerce et de l'Industrie	\N	\N
26	INS, 2022, CEN	\N	\N
27	ME/ER, RAP 2022	\N	\N
28	MEq, 2024, RAP	\N	\N
29	MT, 2022, RAP	\N	\N
30	ARCEP, Rapport d'activités 2022	\N	\N
31	INS, 2021, Enquête ENAFEME	\N	\N
32	INS, 2015, ENISED	\N	\N
33	Annuaire MEN/A/EP/PLN 2023-2024	\N	\N
34	INS-RNDH,2020	\N	\N
35	Annuaire MESR 2023-2024	\N	\N
36	Annuaire MESRIT 2023-2024	\N	\N
37	Ministère du Commerce et d'Industrie	\N	\N
38	Ministère de l'Economie et des Finances	\N	\N
39	MESRIT	\N	\N
40	Annuaire Statistique MSP, 2024	\N	\N
41	Annuaire Santé	\N	\N
42	Rapport d'évaluation, 2024, du PGDISS 2016-2020	\N	\N
43	INS, 2022, Enquête SMART	\N	\N
44	PAP/MAHGC	\N	\N
45	Rapport ANPE	\N	\N
46	Rapport sur les indicateurs MH/A	\N	\N
47	Rapport sur les indicateurs MHA/E	\N	\N
48	Rapport MELCD	\N	\N
49	MU/ L, Rapport Annuel de Performance 2022	\N	\N
50	MU/H RAP	\N	\N
\.


--
-- TOC entry 5517 (class 0 OID 27512)
-- Dependencies: 303
-- Data for Name: statut_activites; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.statut_activites (id, intitule, created_at, updated_at) FROM stdin;
1	En cours	2025-11-02 09:41:33	2025-11-02 09:41:33
2	Non démarré	2025-11-02 09:42:07	2025-11-02 09:42:07
3	Terminé	2025-11-02 09:42:15	2025-11-02 09:42:15
\.


--
-- TOC entry 5495 (class 0 OID 27207)
-- Dependencies: 280
-- Data for Name: statut_financements; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.statut_financements (id, intitule, created_at, updated_at) FROM stdin;
1	A rechercher	2025-11-12 12:02:23	2025-11-12 12:02:23
2	Complément à rechercher	2025-11-12 12:02:35	2025-11-12 12:02:35
3	En négociation	2025-11-12 12:02:48	2025-11-12 12:02:48
4	Accord de principe	2025-11-12 12:03:02	2025-11-12 12:03:02
5	Acquis	2025-11-12 12:03:13	2025-11-12 12:03:13
6	Signé	2025-11-12 12:03:25	2025-11-12 12:03:25
7	Demande transmise	2025-11-12 12:03:58	2025-11-12 12:03:58
\.


--
-- TOC entry 5507 (class 0 OID 27425)
-- Dependencies: 293
-- Data for Name: statut_produits; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.statut_produits (id, intitule, created_at, updated_at) FROM stdin;
1	Programmé	2025-11-01 12:03:37	2025-11-01 12:03:37
2	En cours d'exécution	2025-11-01 12:03:53	2025-11-01 12:03:53
3	Terminé	2025-11-01 12:04:01	2025-11-01 12:04:01
\.


--
-- TOC entry 5527 (class 0 OID 27715)
-- Dependencies: 316
-- Data for Name: statut_projets; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.statut_projets (id, intitule, created_at, updated_at) FROM stdin;
1	Identification	2025-11-08 14:33:54	2025-11-08 14:33:54
2	Formulation	2025-11-08 14:34:09	2025-11-08 14:34:09
3	Exécution	2025-11-08 14:34:32	2025-11-12 23:56:19
4	Cloture	2025-11-12 16:42:15	2025-11-12 23:56:32
\.


--
-- TOC entry 5515 (class 0 OID 27503)
-- Dependencies: 301
-- Data for Name: type_activites; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.type_activites (id, intitule, created_at, updated_at) FROM stdin;
1	Atelier de formation	2025-11-02 09:44:09	2025-11-02 09:44:09
2	Mission de sensibilisation	2025-11-02 09:44:22	2025-11-02 09:44:22
\.


--
-- TOC entry 5460 (class 0 OID 26947)
-- Dependencies: 245
-- Data for Name: type_desagregations; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.type_desagregations (id, intitule, created_at, updated_at) FROM stdin;
2	Milieu de résidence	2025-09-23 13:18:10	2025-09-28 18:35:22
1	Sexe	2025-09-23 13:18:01	2025-09-28 18:35:32
4	NA	2025-10-22 16:01:23	2025-10-22 16:01:23
\.


--
-- TOC entry 5513 (class 0 OID 27489)
-- Dependencies: 299
-- Data for Name: type_produits; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.type_produits (id, intitule, created_at, updated_at) FROM stdin;
1	classe	2025-11-02 01:24:57	2025-11-02 01:24:57
\.


--
-- TOC entry 5468 (class 0 OID 26983)
-- Dependencies: 253
-- Data for Name: unite_indicateurs; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.unite_indicateurs (id, intitule, created_at, updated_at) FROM stdin;
4	%	\N	\N
5	Ans	\N	\N
6	Jour	\N	\N
7	Encadrants pour 1000hbts	\N	\N
8	Nombre	\N	\N
9	Indice	\N	\N
10	Km/1000hbts	\N	\N
11	‰	\N	\N
12	100 000 naissances	\N	\N
13	Ratio	\N	\N
\.


--
-- TOC entry 5433 (class 0 OID 26811)
-- Dependencies: 218
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at) FROM stdin;
1	abass	abass.atacorp@gmail.com	\N	$2y$12$zFB64bIUNXOLyTfE1qlkauOz30d6DnvcoXhBN0b//IqeVD7cb.X7W	\N	\N	2025-10-21 11:41:59
\.


--
-- TOC entry 5444 (class 0 OID 26881)
-- Dependencies: 229
-- Data for Name: zones; Type: TABLE DATA; Schema: public; Owner: sysnise
--

COPY public.zones (id, intitule, code, latitude, longitude, zone_id, niveau, created_at, updated_at) FROM stdin;
1	NIGER	\N	\N	\N	\N	1	\N	\N
2	NIAMEY	\N	\N	\N	1	2	\N	\N
3	DOSSO	\N	\N	\N	1	2	\N	\N
4	AGADEZ	\N	\N	\N	1	2	\N	\N
5	TAHOUA	\N	\N	\N	1	2	\N	\N
6	MARADI	\N	\N	\N	1	2	\N	\N
7	DIFFA	\N	\N	\N	1	2	\N	\N
8	VILLE DE NIAMEY	\N	\N	\N	2	3	\N	\N
9	DOGONDOUTCHI	\N	\N	\N	3	3	\N	\N
10	INGALL	\N	\N	\N	4	3	\N	\N
11	TAHOUA	\N	\N	\N	5	3	\N	\N
13	BAGAROUA	\N	\N	\N	5	3	\N	\N
14	ILLELA	\N	\N	\N	5	3	\N	\N
15	MALBAZA	\N	\N	\N	5	3	\N	\N
16	MADAOUA	\N	\N	\N	5	3	\N	\N
17	KEITA	\N	\N	\N	5	3	\N	\N
18	BOUZA	\N	\N	\N	5	3	\N	\N
19	ABALAK	\N	\N	\N	5	3	\N	\N
20	ARLIT	\N	\N	\N	4	3	\N	\N
21	BOBOYE	\N	\N	\N	3	3	\N	\N
22	FALMEY	\N	\N	\N	3	3	\N	\N
23	DOSSO	\N	\N	\N	3	3	\N	\N
24	GAYA	\N	\N	\N	3	3	\N	\N
25	DIOUNDIOU	\N	\N	\N	3	3	\N	\N
26	TIBIRI (DOUTCHI)	\N	\N	\N	3	3	\N	\N
27	LOGA	\N	\N	\N	3	3	\N	\N
28	GAZAOUA	\N	\N	\N	6	3	\N	\N
29	AGUIE	\N	\N	\N	6	3	\N	\N
30	MADAROUNFA	\N	\N	\N	6	3	\N	\N
31	GUIDAN-ROUMDJI	\N	\N	\N	6	3	\N	\N
32	TESSAOUA	\N	\N	\N	6	3	\N	\N
33	DAKORO	\N	\N	\N	6	3	\N	\N
34	MAYAHI	\N	\N	\N	6	3	\N	\N
35	MAINE-SOROA	\N	\N	\N	7	3	\N	\N
36	DIFFA	\N	\N	\N	7	3	\N	\N
37	GOUDOUMARIA	\N	\N	\N	7	3	\N	\N
38	BOSSO	\N	\N	\N	7	3	\N	\N
41	BERMO	\N	\N	\N	6	3	\N	\N
42	ADERBISSINAT	\N	\N	\N	4	3	\N	\N
43	TCHIROZERINE	\N	\N	\N	4	3	\N	\N
44	IFEROUANE	\N	\N	\N	4	3	\N	\N
45	BILMA	\N	\N	\N	4	3	\N	\N
46	MARADI VILLE	\N	\N	\N	6	3	\N	\N
47	NIAMEY ARRONDISSEMENT 3	\N	\N	\N	8	4	\N	\N
48	NIAMEY ARRONDISSEMENT 2	\N	\N	\N	8	4	\N	\N
49	NIAMEY ARRONDISSEMENT 1	\N	\N	\N	8	4	\N	\N
50	NIAMEY ARRONDISSEMENT 5	\N	\N	\N	8	4	\N	\N
51	NIAMEY ARRONDISSEMENT 4	\N	\N	\N	8	4	\N	\N
52	DOGONKIRIA	\N	\N	\N	9	4	\N	\N
53	MATANKARI	\N	\N	\N	9	4	\N	\N
54	INGALL	\N	\N	\N	10	4	\N	\N
57	BAGAROUA	\N	\N	\N	13	4	\N	\N
58	ILLELA	\N	\N	\N	14	4	\N	\N
59	BAMBEYE	\N	\N	\N	11	4	\N	\N
60	TAJAE	\N	\N	\N	14	4	\N	\N
61	MALBAZA	\N	\N	\N	15	4	\N	\N
64	DOGUERAWA	\N	\N	\N	15	4	\N	\N
65	SABON GUIDA	\N	\N	\N	16	4	\N	\N
66	GALMA KOUDAWATCHE	\N	\N	\N	16	4	\N	\N
67	TAMASKE	\N	\N	\N	17	4	\N	\N
68	BADAGUICHIRI	\N	\N	\N	14	4	\N	\N
69	ALLAKAYE	\N	\N	\N	18	4	\N	\N
70	TABOTAKI	\N	\N	\N	18	4	\N	\N
71	AZARORI	\N	\N	\N	16	4	\N	\N
72	GARHANGA	\N	\N	\N	17	4	\N	\N
73	DEOULE	\N	\N	\N	18	4	\N	\N
74	AFFALA	\N	\N	\N	11	4	\N	\N
75	TABALAK	\N	\N	\N	19	4	\N	\N
76	BARMOU	\N	\N	\N	11	4	\N	\N
77	ABALAK	\N	\N	\N	19	4	\N	\N
78	IBOHAMANE	\N	\N	\N	17	4	\N	\N
79	KEITA	\N	\N	\N	17	4	\N	\N
80	AKOUBOUNOU	\N	\N	\N	19	4	\N	\N
81	BANGUI	\N	\N	\N	16	4	\N	\N
82	OURNO	\N	\N	\N	16	4	\N	\N
83	MADAOUA	\N	\N	\N	16	4	\N	\N
84	KAROFANE	\N	\N	\N	18	4	\N	\N
85	BOUZA	\N	\N	\N	18	4	\N	\N
86	BABANKATAMI	\N	\N	\N	18	4	\N	\N
87	AZEYE	\N	\N	\N	19	4	\N	\N
88	TAMAYA	\N	\N	\N	19	4	\N	\N
89	GOUGARAM	\N	\N	\N	20	4	\N	\N
91	FAKARA	\N	\N	\N	21	4	\N	\N
92	FALMEY	\N	\N	\N	22	4	\N	\N
93	FABIDJI	\N	\N	\N	21	4	\N	\N
95	KANKANDI	\N	\N	\N	21	4	\N	\N
96	TESSA	\N	\N	\N	23	4	\N	\N
97	SAMBERA	\N	\N	\N	23	4	\N	\N
98	TANDA	\N	\N	\N	24	4	\N	\N
99	GAYA	\N	\N	\N	24	4	\N	\N
100	YELOU	\N	\N	\N	24	4	\N	\N
101	GOLLE	\N	\N	\N	23	4	\N	\N
102	GUILLADJE	\N	\N	\N	22	4	\N	\N
103	FAREY	\N	\N	\N	23	4	\N	\N
104	BANA	\N	\N	\N	24	4	\N	\N
105	BENGOU	\N	\N	\N	24	4	\N	\N
106	TOUNOUGA	\N	\N	\N	24	4	\N	\N
107	KARGUIBANGOU	\N	\N	\N	23	4	\N	\N
108	DIOUNDIOU	\N	\N	\N	25	4	\N	\N
109	ZABORI	\N	\N	\N	25	4	\N	\N
110	KARAKARA	\N	\N	\N	25	4	\N	\N
111	GUECHEME	\N	\N	\N	26	4	\N	\N
112	MOKKO	\N	\N	\N	23	4	\N	\N
113	KIOTA	\N	\N	\N	21	4	\N	\N
114	GARANKEDEY	\N	\N	\N	23	4	\N	\N
115	GOROUBANKASSAM	\N	\N	\N	23	4	\N	\N
116	DOSSO	\N	\N	\N	23	4	\N	\N
117	KOYGOLO	\N	\N	\N	21	4	\N	\N
118	HARIKANASSOU	\N	\N	\N	21	4	\N	\N
119	SOKORBE	\N	\N	\N	27	4	\N	\N
120	LOGA	\N	\N	\N	27	4	\N	\N
121	KORE MAIROUA	\N	\N	\N	26	4	\N	\N
122	TOMBOKOIREY II	\N	\N	\N	23	4	\N	\N
123	TOMBOKOIREY I	\N	\N	\N	23	4	\N	\N
124	DOUMEGA	\N	\N	\N	26	4	\N	\N
125	TIBIRI (DOUTCHI)	\N	\N	\N	26	4	\N	\N
126	DOGONDOUTCHI	\N	\N	\N	9	4	\N	\N
127	FALWEL	\N	\N	\N	27	4	\N	\N
128	KIECHE	\N	\N	\N	9	4	\N	\N
129	DAN-KASSARI	\N	\N	\N	9	4	\N	\N
130	SOUCOUCOUTANE	\N	\N	\N	9	4	\N	\N
131	DANNET	\N	\N	\N	20	4	\N	\N
132	GANGARA (AGUIE)	\N	\N	\N	28	4	\N	\N
133	AGUIE	\N	\N	\N	29	4	\N	\N
134	GABI	\N	\N	\N	30	4	\N	\N
135	SAFO	\N	\N	\N	30	4	\N	\N
136	TIBIRI (MARADI)	\N	\N	\N	31	4	\N	\N
137	MADAROUNFA	\N	\N	\N	30	4	\N	\N
138	DAN-ISSA	\N	\N	\N	30	4	\N	\N
139	SARKIN YAMMA	\N	\N	\N	30	4	\N	\N
140	GUIDAN SORI	\N	\N	\N	31	4	\N	\N
141	DJIRATAWA	\N	\N	\N	30	4	\N	\N
142	TCHADOUA	\N	\N	\N	29	4	\N	\N
143	HAWANDAWAKI	\N	\N	\N	32	4	\N	\N
144	KORGOM	\N	\N	\N	32	4	\N	\N
145	GAZAOUA	\N	\N	\N	28	4	\N	\N
146	SAE SABOUA	\N	\N	\N	31	4	\N	\N
147	MAIYARA	\N	\N	\N	33	4	\N	\N
148	GUIDAN ROUMDJI	\N	\N	\N	31	4	\N	\N
149	CHADAKORI	\N	\N	\N	31	4	\N	\N
150	DAN-GOULBI	\N	\N	\N	33	4	\N	\N
151	SABON MACHI	\N	\N	\N	33	4	\N	\N
152	KORNAKA	\N	\N	\N	33	4	\N	\N
153	SARKIN HAOUSSA	\N	\N	\N	34	4	\N	\N
154	BAOUDETTA	\N	\N	\N	32	4	\N	\N
155	MAIJIRGUI	\N	\N	\N	32	4	\N	\N
156	KOONA	\N	\N	\N	32	4	\N	\N
157	TESSAOUA	\N	\N	\N	32	4	\N	\N
158	MAYAHI	\N	\N	\N	34	4	\N	\N
159	ATTANTANE	\N	\N	\N	34	4	\N	\N
160	OURAFANE	\N	\N	\N	32	4	\N	\N
161	KANAN-BAKACHE	\N	\N	\N	34	4	\N	\N
162	ISSAWANE	\N	\N	\N	34	4	\N	\N
163	FOULATARI	\N	\N	\N	35	4	\N	\N
164	MAINE SOROA	\N	\N	\N	35	4	\N	\N
165	CHETIMARI	\N	\N	\N	36	4	\N	\N
166	GOUDOUMARIA	\N	\N	\N	37	4	\N	\N
167	DIFFA	\N	\N	\N	36	4	\N	\N
168	GUESKEROU	\N	\N	\N	36	4	\N	\N
169	TOUMOUR	\N	\N	\N	38	4	\N	\N
170	BOSSO	\N	\N	\N	38	4	\N	\N
175	EL ALLASSANE MAIREYREY	\N	\N	\N	34	4	\N	\N
176	GADABEDJI	\N	\N	\N	41	4	\N	\N
177	BERMO	\N	\N	\N	41	4	\N	\N
178	BIRNI LALLE	\N	\N	\N	33	4	\N	\N
179	ADJEKORIA	\N	\N	\N	33	4	\N	\N
180	KORAHANE	\N	\N	\N	33	4	\N	\N
181	TAGRISS	\N	\N	\N	33	4	\N	\N
182	GUIDAN AMOUMOUNE	\N	\N	\N	34	4	\N	\N
183	TCHAKE	\N	\N	\N	34	4	\N	\N
184	ROUMBOU I	\N	\N	\N	33	4	\N	\N
185	DAKORO	\N	\N	\N	33	4	\N	\N
186	AZAGOR	\N	\N	\N	33	4	\N	\N
187	BADER GOULA	\N	\N	\N	33	4	\N	\N
188	ARLIT	\N	\N	\N	20	4	\N	\N
189	ADERBISSINAT	\N	\N	\N	42	4	\N	\N
190	DABAGA	\N	\N	\N	43	4	\N	\N
191	TCHIROZERINE	\N	\N	\N	43	4	\N	\N
192	TABELOT	\N	\N	\N	43	4	\N	\N
193	TIMIA	\N	\N	\N	44	4	\N	\N
194	AGADEZ	\N	\N	\N	43	4	\N	\N
195	IFEROUANE	\N	\N	\N	44	4	\N	\N
196	DIRKOU	\N	\N	\N	45	4	\N	\N
197	FACHI	\N	\N	\N	45	4	\N	\N
198	BILMA	\N	\N	\N	45	4	\N	\N
199	DJADO	\N	\N	\N	45	4	\N	\N
200	TILLABERI	\N	\N	\N	1	2	\N	\N
201	ZINDER	\N	\N	\N	1	2	\N	\N
202	SAY	\N	\N	\N	200	3	\N	\N
203	KOLLO	\N	\N	\N	200	3	\N	\N
204	GOTHEYE	\N	\N	\N	200	3	\N	\N
205	TERA	\N	\N	\N	200	3	\N	\N
206	BALLEYARA	\N	\N	\N	200	3	\N	\N
207	ABALA	\N	\N	\N	200	3	\N	\N
208	OUALLAM	\N	\N	\N	200	3	\N	\N
209	TILLABERI	\N	\N	\N	200	3	\N	\N
210	FILINGUE	\N	\N	\N	200	3	\N	\N
211	AYEROU	\N	\N	\N	200	3	\N	\N
212	BANIBANGOU	\N	\N	\N	200	3	\N	\N
213	BANKILARE	\N	\N	\N	200	3	\N	\N
214	KANTCHE	\N	\N	\N	201	3	\N	\N
215	MAGARIA	\N	\N	\N	201	3	\N	\N
216	MIRRIAH	\N	\N	\N	201	3	\N	\N
217	TAKEITA	\N	\N	\N	201	3	\N	\N
218	GOURE	\N	\N	\N	201	3	\N	\N
219	DUNGASS	\N	\N	\N	201	3	\N	\N
220	DAMAGARAM TAKAYA	\N	\N	\N	201	3	\N	\N
221	BELBEDJI	\N	\N	\N	201	3	\N	\N
222	TANOUT	\N	\N	\N	201	3	\N	\N
223	TESKER	\N	\N	\N	201	3	\N	\N
224	TILLIA	\N	\N	\N	5	3	\N	\N
225	TCHINTABARADEN	\N	\N	\N	5	3	\N	\N
226	TASSARA	\N	\N	\N	5	3	\N	\N
227	ZINDER VILLE	\N	\N	\N	201	3	\N	\N
228	TAHOUA VILLE	\N	\N	\N	5	3	\N	\N
229	TORODI	\N	\N	\N	200	3	\N	\N
230	SAY	\N	\N	\N	202	4	\N	\N
231	TAMOU	\N	\N	\N	202	4	\N	\N
232	OURO GUELADJO	\N	\N	\N	202	4	\N	\N
233	KIRTACHI	\N	\N	\N	203	4	\N	\N
234	DARGOL	\N	\N	\N	204	4	\N	\N
235	NAMARO	\N	\N	\N	203	4	\N	\N
236	DIAGOUROU	\N	\N	\N	205	4	\N	\N
237	GOTHEYE	\N	\N	\N	204	4	\N	\N
238	KOURE	\N	\N	\N	203	4	\N	\N
239	KOLLO	\N	\N	\N	203	4	\N	\N
240	DIANTCHANDOU	\N	\N	\N	203	4	\N	\N
241	TAGAZAR	\N	\N	\N	206	4	\N	\N
242	ABALA	\N	\N	\N	207	4	\N	\N
243	SIMIRI	\N	\N	\N	208	4	\N	\N
244	KOKOROU	\N	\N	\N	205	4	\N	\N
245	TERA	\N	\N	\N	205	4	\N	\N
246	KOURTEYE	\N	\N	\N	209	4	\N	\N
247	SAKOIRA	\N	\N	\N	209	4	\N	\N
248	OUALLAM	\N	\N	\N	208	4	\N	\N
249	TILLABERI	\N	\N	\N	209	4	\N	\N
250	IMANAN	\N	\N	\N	210	4	\N	\N
251	TONDIKANDIA	\N	\N	\N	210	4	\N	\N
252	KOURFEYE CENTRE	\N	\N	\N	210	4	\N	\N
253	DINGAZI	\N	\N	\N	208	4	\N	\N
254	FILINGUE	\N	\N	\N	210	4	\N	\N
255	DESSA	\N	\N	\N	209	4	\N	\N
256	MEHANA	\N	\N	\N	205	4	\N	\N
257	SINDER	\N	\N	\N	209	4	\N	\N
258	ANZOUROU	\N	\N	\N	209	4	\N	\N
259	AYEROU	\N	\N	\N	211	4	\N	\N
260	INATES	\N	\N	\N	211	4	\N	\N
261	TONDIKIWINDI	\N	\N	\N	208	4	\N	\N
262	BIBIYERGOU	\N	\N	\N	209	4	\N	\N
263	BANIBANGOU	\N	\N	\N	212	4	\N	\N
264	KARMA	\N	\N	\N	203	4	\N	\N
265	HAMDALLAYE	\N	\N	\N	203	4	\N	\N
267	BITINKODJI	\N	\N	\N	203	4	\N	\N
268	YOURI	\N	\N	\N	203	4	\N	\N
269	LIBORE	\N	\N	\N	203	4	\N	\N
270	GOROUOL	\N	\N	\N	205	4	\N	\N
271	BANKILARE	\N	\N	\N	213	4	\N	\N
272	MATAMEY	\N	\N	\N	214	4	\N	\N
273	MAGARIA	\N	\N	\N	215	4	\N	\N
274	DROUM	\N	\N	\N	216	4	\N	\N
275	DAN BARTO	\N	\N	\N	214	4	\N	\N
276	SASSOUMBROUM	\N	\N	\N	215	4	\N	\N
277	YEKOUA	\N	\N	\N	215	4	\N	\N
278	KWAYA	\N	\N	\N	215	4	\N	\N
279	DAOUCHE	\N	\N	\N	214	4	\N	\N
280	TSAOUNI	\N	\N	\N	214	4	\N	\N
281	YAOURI	\N	\N	\N	214	4	\N	\N
282	KOURNI	\N	\N	\N	214	4	\N	\N
283	DOUNGOU	\N	\N	\N	214	4	\N	\N
284	ICHIRNAWA	\N	\N	\N	214	4	\N	\N
285	GARAGOUMSA	\N	\N	\N	217	4	\N	\N
286	TIRMINI	\N	\N	\N	217	4	\N	\N
287	BOUNE	\N	\N	\N	218	4	\N	\N
288	BANDE	\N	\N	\N	215	4	\N	\N
289	DOGO-DOGO	\N	\N	\N	219	4	\N	\N
290	DANTCHIAO	\N	\N	\N	215	4	\N	\N
291	DUNGASS	\N	\N	\N	219	4	\N	\N
292	MALAWA	\N	\N	\N	219	4	\N	\N
293	WACHA	\N	\N	\N	215	4	\N	\N
294	DOGO	\N	\N	\N	216	4	\N	\N
295	GOUNA	\N	\N	\N	216	4	\N	\N
296	GOUCHI	\N	\N	\N	219	4	\N	\N
297	GUIDIGUIR	\N	\N	\N	218	4	\N	\N
298	KELLE	\N	\N	\N	218	4	\N	\N
299	GAFFATI	\N	\N	\N	216	4	\N	\N
300	HAMDARA	\N	\N	\N	216	4	\N	\N
301	KOLLERAM	\N	\N	\N	216	4	\N	\N
302	MIRRIAH	\N	\N	\N	216	4	\N	\N
303	ZERMOU	\N	\N	\N	216	4	\N	\N
304	GOURE	\N	\N	\N	218	4	\N	\N
305	GUIDIMOUNI	\N	\N	\N	220	4	\N	\N
306	ALBARKARAM	\N	\N	\N	220	4	\N	\N
307	DAKOUSSA	\N	\N	\N	217	4	\N	\N
308	WAME	\N	\N	\N	220	4	\N	\N
309	DAMAGARAM TAKAYA	\N	\N	\N	220	4	\N	\N
310	MAZAMNI	\N	\N	\N	220	4	\N	\N
311	MOA	\N	\N	\N	220	4	\N	\N
312	TARKA	\N	\N	\N	221	4	\N	\N
313	TANOUT	\N	\N	\N	222	4	\N	\N
314	FALENKO	\N	\N	\N	222	4	\N	\N
315	OLLELEWA	\N	\N	\N	222	4	\N	\N
316	TENHYA	\N	\N	\N	222	4	\N	\N
317	GANGARA (TANOUT)	\N	\N	\N	222	4	\N	\N
318	GAMOU	\N	\N	\N	218	4	\N	\N
319	TESKER	\N	\N	\N	223	4	\N	\N
320	ALAKOSS	\N	\N	\N	218	4	\N	\N
321	KANTCHE	\N	\N	\N	214	4	\N	\N
322	KALFOU	\N	\N	\N	11	4	\N	\N
323	TILLIA	\N	\N	\N	224	4	\N	\N
324	TEBARAM	\N	\N	\N	11	4	\N	\N
325	TCHINTABARADEN	\N	\N	\N	225	4	\N	\N
326	TASSARA	\N	\N	\N	226	4	\N	\N
327	KAO	\N	\N	\N	225	4	\N	\N
328	TAKANAMAT	\N	\N	\N	11	4	\N	\N
329	PARC W	\N	\N	\N	202	4	\N	\N
330	ZINDER I,II,III,IV,V	\N	\N	\N	227	4	\N	\N
331	TAHOUA I,II	\N	\N	\N	228	4	\N	\N
332	TORODI	\N	\N	\N	229	4	\N	\N
333	MAKALONDI	\N	\N	\N	229	4	\N	\N
\.


--
-- TOC entry 5601 (class 0 OID 0)
-- Dependencies: 310
-- Name: activite_zone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.activite_zone_id_seq', 7, true);


--
-- TOC entry 5602 (class 0 OID 0)
-- Dependencies: 304
-- Name: activites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.activites_id_seq', 2, true);


--
-- TOC entry 5603 (class 0 OID 0)
-- Dependencies: 230
-- Name: cadre_developpements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.cadre_developpements_id_seq', 17, true);


--
-- TOC entry 5604 (class 0 OID 0)
-- Dependencies: 234
-- Name: cadre_logiques_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.cadre_logiques_id_seq', 127, true);


--
-- TOC entry 5605 (class 0 OID 0)
-- Dependencies: 254
-- Name: commentaire_valeur_indicateurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.commentaire_valeur_indicateurs_id_seq', 3, true);


--
-- TOC entry 5606 (class 0 OID 0)
-- Dependencies: 257
-- Name: desagregation_indicateur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.desagregation_indicateur_id_seq', 1, false);


--
-- TOC entry 5607 (class 0 OID 0)
-- Dependencies: 242
-- Name: desagregations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.desagregations_id_seq', 6, true);


--
-- TOC entry 5608 (class 0 OID 0)
-- Dependencies: 287
-- Name: donnee_indicateur_desagregation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.donnee_indicateur_desagregation_id_seq', 1154, true);


--
-- TOC entry 5609 (class 0 OID 0)
-- Dependencies: 240
-- Name: donnee_indicateurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.donnee_indicateurs_id_seq', 1163, true);


--
-- TOC entry 5610 (class 0 OID 0)
-- Dependencies: 269
-- Name: etude_identifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.etude_identifications_id_seq', 1, false);


--
-- TOC entry 5611 (class 0 OID 0)
-- Dependencies: 273
-- Name: etudes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.etudes_id_seq', 13, true);


--
-- TOC entry 5612 (class 0 OID 0)
-- Dependencies: 226
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- TOC entry 5613 (class 0 OID 0)
-- Dependencies: 290
-- Name: hypothese_risques_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.hypothese_risques_id_seq', 2, true);


--
-- TOC entry 5614 (class 0 OID 0)
-- Dependencies: 238
-- Name: indicateurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.indicateurs_id_seq', 1396, true);


--
-- TOC entry 5615 (class 0 OID 0)
-- Dependencies: 263
-- Name: institution_tutelles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.institution_tutelles_id_seq', 1, true);


--
-- TOC entry 5616 (class 0 OID 0)
-- Dependencies: 223
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- TOC entry 5617 (class 0 OID 0)
-- Dependencies: 215
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.migrations_id_seq', 35, true);


--
-- TOC entry 5618 (class 0 OID 0)
-- Dependencies: 277
-- Name: mode_financements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.mode_financements_id_seq', 8, true);


--
-- TOC entry 5619 (class 0 OID 0)
-- Dependencies: 246
-- Name: nature_donnees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.nature_donnees_id_seq', 3, true);


--
-- TOC entry 5620 (class 0 OID 0)
-- Dependencies: 279
-- Name: niveau_financements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.niveau_financements_id_seq', 7, true);


--
-- TOC entry 5621 (class 0 OID 0)
-- Dependencies: 236
-- Name: orientation_cadre_developpements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.orientation_cadre_developpements_id_seq', 18, true);


--
-- TOC entry 5622 (class 0 OID 0)
-- Dependencies: 248
-- Name: periodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.periodes_id_seq', 31, true);


--
-- TOC entry 5623 (class 0 OID 0)
-- Dependencies: 283
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.permissions_id_seq', 1, true);


--
-- TOC entry 5624 (class 0 OID 0)
-- Dependencies: 306
-- Name: piece_jointe_activites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.piece_jointe_activites_id_seq', 1, true);


--
-- TOC entry 5625 (class 0 OID 0)
-- Dependencies: 296
-- Name: piece_jointe_produits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.piece_jointe_produits_id_seq', 4, true);


--
-- TOC entry 5626 (class 0 OID 0)
-- Dependencies: 321
-- Name: piece_jointe_projets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.piece_jointe_projets_id_seq', 4, true);


--
-- TOC entry 5627 (class 0 OID 0)
-- Dependencies: 232
-- Name: piece_jointes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.piece_jointes_id_seq', 11, true);


--
-- TOC entry 5628 (class 0 OID 0)
-- Dependencies: 267
-- Name: population_cible_projets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.population_cible_projets_id_seq', 8, true);


--
-- TOC entry 5629 (class 0 OID 0)
-- Dependencies: 265
-- Name: population_cibles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.population_cibles_id_seq', 4, true);


--
-- TOC entry 5630 (class 0 OID 0)
-- Dependencies: 261
-- Name: priorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.priorites_id_seq', 5, true);


--
-- TOC entry 5631 (class 0 OID 0)
-- Dependencies: 308
-- Name: produit_zone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.produit_zone_id_seq', 5, true);


--
-- TOC entry 5632 (class 0 OID 0)
-- Dependencies: 294
-- Name: produits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.produits_id_seq', 2, true);


--
-- TOC entry 5633 (class 0 OID 0)
-- Dependencies: 319
-- Name: projet_cadre_logique_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.projet_cadre_logique_id_seq', 3, true);


--
-- TOC entry 5634 (class 0 OID 0)
-- Dependencies: 323
-- Name: projet_etude_disponible_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.projet_etude_disponible_id_seq', 3, true);


--
-- TOC entry 5635 (class 0 OID 0)
-- Dependencies: 325
-- Name: projet_etude_envisagee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.projet_etude_envisagee_id_seq', 3, true);


--
-- TOC entry 5636 (class 0 OID 0)
-- Dependencies: 329
-- Name: projet_financement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.projet_financement_id_seq', 1, false);


--
-- TOC entry 5637 (class 0 OID 0)
-- Dependencies: 317
-- Name: projet_zone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.projet_zone_id_seq', 7, true);


--
-- TOC entry 5638 (class 0 OID 0)
-- Dependencies: 259
-- Name: projets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.projets_id_seq', 3, true);


--
-- TOC entry 5639 (class 0 OID 0)
-- Dependencies: 327
-- Name: ptfs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.ptfs_id_seq', 3, true);


--
-- TOC entry 5640 (class 0 OID 0)
-- Dependencies: 271
-- Name: recherche_financements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.recherche_financements_id_seq', 1, false);


--
-- TOC entry 5641 (class 0 OID 0)
-- Dependencies: 281
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, true);


--
-- TOC entry 5642 (class 0 OID 0)
-- Dependencies: 275
-- Name: source_financements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.source_financements_id_seq', 2, true);


--
-- TOC entry 5643 (class 0 OID 0)
-- Dependencies: 250
-- Name: source_indicateurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.source_indicateurs_id_seq', 50, true);


--
-- TOC entry 5644 (class 0 OID 0)
-- Dependencies: 302
-- Name: statut_activites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.statut_activites_id_seq', 3, true);


--
-- TOC entry 5645 (class 0 OID 0)
-- Dependencies: 292
-- Name: statut_produits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.statut_produits_id_seq', 3, true);


--
-- TOC entry 5646 (class 0 OID 0)
-- Dependencies: 315
-- Name: statut_projets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.statut_projets_id_seq', 4, true);


--
-- TOC entry 5647 (class 0 OID 0)
-- Dependencies: 300
-- Name: type_activites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.type_activites_id_seq', 2, true);


--
-- TOC entry 5648 (class 0 OID 0)
-- Dependencies: 244
-- Name: type_desagregations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.type_desagregations_id_seq', 4, true);


--
-- TOC entry 5649 (class 0 OID 0)
-- Dependencies: 298
-- Name: type_produits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.type_produits_id_seq', 1, true);


--
-- TOC entry 5650 (class 0 OID 0)
-- Dependencies: 252
-- Name: unite_indicateurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.unite_indicateurs_id_seq', 13, true);


--
-- TOC entry 5651 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- TOC entry 5652 (class 0 OID 0)
-- Dependencies: 228
-- Name: zones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sysnise
--

SELECT pg_catalog.setval('public.zones_id_seq', 337, true);


--
-- TOC entry 5221 (class 2606 OID 27588)
-- Name: activite_zone activite_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.activite_zone
    ADD CONSTRAINT activite_zone_pkey PRIMARY KEY (activite_id, zone_id);


--
-- TOC entry 5215 (class 2606 OID 27530)
-- Name: activites activites_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.activites
    ADD CONSTRAINT activites_pkey PRIMARY KEY (id);


--
-- TOC entry 5079 (class 2606 OID 26850)
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- TOC entry 5077 (class 2606 OID 26843)
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- TOC entry 5092 (class 2606 OID 26897)
-- Name: cadre_developpements cadre_developpements_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.cadre_developpements
    ADD CONSTRAINT cadre_developpements_pkey PRIMARY KEY (id);


--
-- TOC entry 5096 (class 2606 OID 26913)
-- Name: cadre_logiques cadre_logiques_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.cadre_logiques
    ADD CONSTRAINT cadre_logiques_pkey PRIMARY KEY (id);


--
-- TOC entry 5135 (class 2606 OID 27077)
-- Name: cadre_mesure_resultats cadre_mesure_resultat_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.cadre_mesure_resultats
    ADD CONSTRAINT cadre_mesure_resultat_unique UNIQUE (indicateur_id, cadre_logique_id);


--
-- TOC entry 5137 (class 2606 OID 27075)
-- Name: cadre_mesure_resultats cadre_mesure_resultats_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.cadre_mesure_resultats
    ADD CONSTRAINT cadre_mesure_resultats_pkey PRIMARY KEY (id);


--
-- TOC entry 5131 (class 2606 OID 27001)
-- Name: commentaire_valeur_indicateurs commentaire_valeur_indicateurs_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.commentaire_valeur_indicateurs
    ADD CONSTRAINT commentaire_valeur_indicateurs_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5133 (class 2606 OID 26999)
-- Name: commentaire_valeur_indicateurs commentaire_valeur_indicateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.commentaire_valeur_indicateurs
    ADD CONSTRAINT commentaire_valeur_indicateurs_pkey PRIMARY KEY (id);


--
-- TOC entry 5139 (class 2606 OID 27088)
-- Name: desagregation_indicateur desagregation_indicateur_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.desagregation_indicateur
    ADD CONSTRAINT desagregation_indicateur_pkey PRIMARY KEY (id);


--
-- TOC entry 5107 (class 2606 OID 26945)
-- Name: desagregations desagregations_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.desagregations
    ADD CONSTRAINT desagregations_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5109 (class 2606 OID 26943)
-- Name: desagregations desagregations_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.desagregations
    ADD CONSTRAINT desagregations_pkey PRIMARY KEY (id);


--
-- TOC entry 5102 (class 2606 OID 27340)
-- Name: donnee_indicateurs donnee_indicateur_pk; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateurs
    ADD CONSTRAINT donnee_indicateur_pk PRIMARY KEY (nature_donnee_id, indicateur_id, zone_id, periode_id, source_indicateur_id, unite_indicateur_id, commentaire_valeur_indicateur_id);


--
-- TOC entry 5104 (class 2606 OID 27358)
-- Name: donnee_indicateurs donnee_indicateurs_id_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateurs
    ADD CONSTRAINT donnee_indicateurs_id_unique UNIQUE (id);


--
-- TOC entry 5159 (class 2606 OID 27171)
-- Name: etude_identifications etude_identifications_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.etude_identifications
    ADD CONSTRAINT etude_identifications_pkey PRIMARY KEY (id);


--
-- TOC entry 5163 (class 2606 OID 27187)
-- Name: etudes etudes_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.etudes
    ADD CONSTRAINT etudes_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5165 (class 2606 OID 27185)
-- Name: etudes etudes_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.etudes
    ADD CONSTRAINT etudes_pkey PRIMARY KEY (id);


--
-- TOC entry 5086 (class 2606 OID 26877)
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- TOC entry 5088 (class 2606 OID 26879)
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- TOC entry 5193 (class 2606 OID 27415)
-- Name: hypothese_risques hypothese_risques_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.hypothese_risques
    ADD CONSTRAINT hypothese_risques_pkey PRIMARY KEY (id);


--
-- TOC entry 5100 (class 2606 OID 26929)
-- Name: indicateurs indicateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.indicateurs
    ADD CONSTRAINT indicateurs_pkey PRIMARY KEY (id);


--
-- TOC entry 5149 (class 2606 OID 27148)
-- Name: institution_tutelles institution_tutelles_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.institution_tutelles
    ADD CONSTRAINT institution_tutelles_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5151 (class 2606 OID 27146)
-- Name: institution_tutelles institution_tutelles_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.institution_tutelles
    ADD CONSTRAINT institution_tutelles_pkey PRIMARY KEY (id);


--
-- TOC entry 5084 (class 2606 OID 26867)
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- TOC entry 5081 (class 2606 OID 26859)
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- TOC entry 5065 (class 2606 OID 26809)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 5171 (class 2606 OID 27205)
-- Name: nature_financements mode_financements_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.nature_financements
    ADD CONSTRAINT mode_financements_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5173 (class 2606 OID 27203)
-- Name: nature_financements mode_financements_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.nature_financements
    ADD CONSTRAINT mode_financements_pkey PRIMARY KEY (id);


--
-- TOC entry 5115 (class 2606 OID 26963)
-- Name: nature_donnees nature_donnees_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.nature_donnees
    ADD CONSTRAINT nature_donnees_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5117 (class 2606 OID 26961)
-- Name: nature_donnees nature_donnees_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.nature_donnees
    ADD CONSTRAINT nature_donnees_pkey PRIMARY KEY (id);


--
-- TOC entry 5175 (class 2606 OID 27214)
-- Name: statut_financements niveau_financements_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_financements
    ADD CONSTRAINT niveau_financements_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5177 (class 2606 OID 27212)
-- Name: statut_financements niveau_financements_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_financements
    ADD CONSTRAINT niveau_financements_pkey PRIMARY KEY (id);


--
-- TOC entry 5098 (class 2606 OID 26920)
-- Name: orientation_cadre_developpements orientation_cadre_developpements_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.orientation_cadre_developpements
    ADD CONSTRAINT orientation_cadre_developpements_pkey PRIMARY KEY (id);


--
-- TOC entry 5071 (class 2606 OID 26827)
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- TOC entry 5119 (class 2606 OID 26972)
-- Name: periodes periodes_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.periodes
    ADD CONSTRAINT periodes_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5121 (class 2606 OID 26970)
-- Name: periodes periodes_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.periodes
    ADD CONSTRAINT periodes_pkey PRIMARY KEY (id);


--
-- TOC entry 5189 (class 2606 OID 27282)
-- Name: permission_role permission_role_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_pkey PRIMARY KEY (permission_id, role_id);


--
-- TOC entry 5183 (class 2606 OID 27252)
-- Name: permissions permissions_name_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_unique UNIQUE (name);


--
-- TOC entry 5185 (class 2606 OID 27250)
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 5217 (class 2606 OID 27554)
-- Name: piece_jointe_activites piece_jointe_activites_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointe_activites
    ADD CONSTRAINT piece_jointe_activites_pkey PRIMARY KEY (id);


--
-- TOC entry 5201 (class 2606 OID 27482)
-- Name: piece_jointe_produits piece_jointe_produits_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointe_produits
    ADD CONSTRAINT piece_jointe_produits_pkey PRIMARY KEY (id);


--
-- TOC entry 5231 (class 2606 OID 27769)
-- Name: piece_jointe_projets piece_jointe_projets_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointe_projets
    ADD CONSTRAINT piece_jointe_projets_pkey PRIMARY KEY (id);


--
-- TOC entry 5094 (class 2606 OID 26906)
-- Name: piece_jointes piece_jointes_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointes
    ADD CONSTRAINT piece_jointes_pkey PRIMARY KEY (id);


--
-- TOC entry 5191 (class 2606 OID 27387)
-- Name: donnee_indicateur_desagregation pk_donnee_indicateur_desagregation; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateur_desagregation
    ADD CONSTRAINT pk_donnee_indicateur_desagregation PRIMARY KEY (donnee_indicateur_id, desagregation_id);


--
-- TOC entry 5157 (class 2606 OID 27164)
-- Name: projet_population_cible population_cible_projets_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_population_cible
    ADD CONSTRAINT population_cible_projets_pkey PRIMARY KEY (id);


--
-- TOC entry 5153 (class 2606 OID 27157)
-- Name: population_cibles population_cibles_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.population_cibles
    ADD CONSTRAINT population_cibles_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5155 (class 2606 OID 27155)
-- Name: population_cibles population_cibles_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.population_cibles
    ADD CONSTRAINT population_cibles_pkey PRIMARY KEY (id);


--
-- TOC entry 5145 (class 2606 OID 27139)
-- Name: priorites priorites_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.priorites
    ADD CONSTRAINT priorites_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5147 (class 2606 OID 27137)
-- Name: priorites priorites_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.priorites
    ADD CONSTRAINT priorites_pkey PRIMARY KEY (id);


--
-- TOC entry 5219 (class 2606 OID 27568)
-- Name: produit_zone produit_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.produit_zone
    ADD CONSTRAINT produit_zone_pkey PRIMARY KEY (produit_id, zone_id);


--
-- TOC entry 5199 (class 2606 OID 27454)
-- Name: produits produits_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.produits
    ADD CONSTRAINT produits_pkey PRIMARY KEY (id);


--
-- TOC entry 5229 (class 2606 OID 27750)
-- Name: projet_cadre_logique projet_cadre_logique_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_cadre_logique
    ADD CONSTRAINT projet_cadre_logique_pkey PRIMARY KEY (projet_id, cadre_logique_id);


--
-- TOC entry 5233 (class 2606 OID 27786)
-- Name: projet_etude_disponible projet_etude_disponibles_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_etude_disponible
    ADD CONSTRAINT projet_etude_disponibles_pkey PRIMARY KEY (id);


--
-- TOC entry 5235 (class 2606 OID 27793)
-- Name: projet_etude_envisagee projet_etude_envisagees_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_etude_envisagee
    ADD CONSTRAINT projet_etude_envisagees_pkey PRIMARY KEY (id);


--
-- TOC entry 5241 (class 2606 OID 27821)
-- Name: projet_financement projet_financement_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_financement
    ADD CONSTRAINT projet_financement_pkey PRIMARY KEY (id);


--
-- TOC entry 5227 (class 2606 OID 27731)
-- Name: projet_zone projet_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_zone
    ADD CONSTRAINT projet_zone_pkey PRIMARY KEY (projet_id, zone_id);


--
-- TOC entry 5143 (class 2606 OID 27123)
-- Name: projets projets_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projets
    ADD CONSTRAINT projets_pkey PRIMARY KEY (id);


--
-- TOC entry 5237 (class 2606 OID 27802)
-- Name: ptfs ptfs_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.ptfs
    ADD CONSTRAINT ptfs_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5239 (class 2606 OID 27800)
-- Name: ptfs ptfs_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.ptfs
    ADD CONSTRAINT ptfs_pkey PRIMARY KEY (id);


--
-- TOC entry 5161 (class 2606 OID 27178)
-- Name: recherche_financements recherche_financements_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.recherche_financements
    ADD CONSTRAINT recherche_financements_pkey PRIMARY KEY (id);


--
-- TOC entry 5187 (class 2606 OID 27267)
-- Name: role_user role_user_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.role_user
    ADD CONSTRAINT role_user_pkey PRIMARY KEY (role_id, user_id);


--
-- TOC entry 5179 (class 2606 OID 27241)
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- TOC entry 5181 (class 2606 OID 27239)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 5074 (class 2606 OID 26834)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 5167 (class 2606 OID 27196)
-- Name: source_financements source_financements_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.source_financements
    ADD CONSTRAINT source_financements_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5169 (class 2606 OID 27194)
-- Name: source_financements source_financements_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.source_financements
    ADD CONSTRAINT source_financements_pkey PRIMARY KEY (id);


--
-- TOC entry 5123 (class 2606 OID 26981)
-- Name: source_indicateurs source_indicateurs_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.source_indicateurs
    ADD CONSTRAINT source_indicateurs_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5125 (class 2606 OID 26979)
-- Name: source_indicateurs source_indicateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.source_indicateurs
    ADD CONSTRAINT source_indicateurs_pkey PRIMARY KEY (id);


--
-- TOC entry 5211 (class 2606 OID 27519)
-- Name: statut_activites statut_activites_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_activites
    ADD CONSTRAINT statut_activites_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5213 (class 2606 OID 27517)
-- Name: statut_activites statut_activites_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_activites
    ADD CONSTRAINT statut_activites_pkey PRIMARY KEY (id);


--
-- TOC entry 5195 (class 2606 OID 27432)
-- Name: statut_produits statut_produits_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_produits
    ADD CONSTRAINT statut_produits_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5197 (class 2606 OID 27430)
-- Name: statut_produits statut_produits_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_produits
    ADD CONSTRAINT statut_produits_pkey PRIMARY KEY (id);


--
-- TOC entry 5223 (class 2606 OID 27722)
-- Name: statut_projets statut_projets_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_projets
    ADD CONSTRAINT statut_projets_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5225 (class 2606 OID 27720)
-- Name: statut_projets statut_projets_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.statut_projets
    ADD CONSTRAINT statut_projets_pkey PRIMARY KEY (id);


--
-- TOC entry 5207 (class 2606 OID 27510)
-- Name: type_activites type_activites_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.type_activites
    ADD CONSTRAINT type_activites_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5209 (class 2606 OID 27508)
-- Name: type_activites type_activites_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.type_activites
    ADD CONSTRAINT type_activites_pkey PRIMARY KEY (id);


--
-- TOC entry 5111 (class 2606 OID 26954)
-- Name: type_desagregations type_desagregations_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.type_desagregations
    ADD CONSTRAINT type_desagregations_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5113 (class 2606 OID 26952)
-- Name: type_desagregations type_desagregations_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.type_desagregations
    ADD CONSTRAINT type_desagregations_pkey PRIMARY KEY (id);


--
-- TOC entry 5203 (class 2606 OID 27496)
-- Name: type_produits type_produits_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.type_produits
    ADD CONSTRAINT type_produits_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5205 (class 2606 OID 27494)
-- Name: type_produits type_produits_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.type_produits
    ADD CONSTRAINT type_produits_pkey PRIMARY KEY (id);


--
-- TOC entry 5127 (class 2606 OID 26990)
-- Name: unite_indicateurs unite_indicateurs_intitule_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.unite_indicateurs
    ADD CONSTRAINT unite_indicateurs_intitule_unique UNIQUE (intitule);


--
-- TOC entry 5129 (class 2606 OID 26988)
-- Name: unite_indicateurs unite_indicateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.unite_indicateurs
    ADD CONSTRAINT unite_indicateurs_pkey PRIMARY KEY (id);


--
-- TOC entry 5141 (class 2606 OID 27090)
-- Name: desagregation_indicateur uq_desagregation_indicateur; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.desagregation_indicateur
    ADD CONSTRAINT uq_desagregation_indicateur UNIQUE (desagregation_id, indicateur_id);


--
-- TOC entry 5067 (class 2606 OID 26820)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- TOC entry 5069 (class 2606 OID 26818)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 5090 (class 2606 OID 26888)
-- Name: zones zones_pkey; Type: CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.zones
    ADD CONSTRAINT zones_pkey PRIMARY KEY (id);


--
-- TOC entry 5105 (class 1259 OID 27330)
-- Name: idx_donnee_indicateurs_indicateur_periode; Type: INDEX; Schema: public; Owner: sysnise
--

CREATE INDEX idx_donnee_indicateurs_indicateur_periode ON public.donnee_indicateurs USING btree (indicateur_id, periode_id);


--
-- TOC entry 5082 (class 1259 OID 26860)
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: sysnise
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- TOC entry 5072 (class 1259 OID 26836)
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: sysnise
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- TOC entry 5075 (class 1259 OID 26835)
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: sysnise
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- TOC entry 5271 (class 2606 OID 27589)
-- Name: activite_zone activite_zone_activite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.activite_zone
    ADD CONSTRAINT activite_zone_activite_id_fkey FOREIGN KEY (activite_id) REFERENCES public.activites(id) ON DELETE CASCADE;


--
-- TOC entry 5272 (class 2606 OID 27594)
-- Name: activite_zone activite_zone_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.activite_zone
    ADD CONSTRAINT activite_zone_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES public.zones(id) ON DELETE CASCADE;


--
-- TOC entry 5265 (class 2606 OID 27531)
-- Name: activites fk_activites_cadre_logique; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.activites
    ADD CONSTRAINT fk_activites_cadre_logique FOREIGN KEY (cadre_logique_id) REFERENCES public.cadre_logiques(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 5266 (class 2606 OID 27536)
-- Name: activites fk_activites_statut_activite; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.activites
    ADD CONSTRAINT fk_activites_statut_activite FOREIGN KEY (statut_activite_id) REFERENCES public.statut_activites(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 5267 (class 2606 OID 27541)
-- Name: activites fk_activites_type_activite; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.activites
    ADD CONSTRAINT fk_activites_type_activite FOREIGN KEY (type_activite_id) REFERENCES public.type_activites(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 5250 (class 2606 OID 27063)
-- Name: cadre_mesure_resultats fk_cadre_mesure_resultat_cadre_logique; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.cadre_mesure_resultats
    ADD CONSTRAINT fk_cadre_mesure_resultat_cadre_logique FOREIGN KEY (cadre_logique_id) REFERENCES public.cadre_logiques(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 5251 (class 2606 OID 27058)
-- Name: cadre_mesure_resultats fk_cadre_mesure_resultat_indicateur; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.cadre_mesure_resultats
    ADD CONSTRAINT fk_cadre_mesure_resultat_indicateur FOREIGN KEY (indicateur_id) REFERENCES public.indicateurs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 5252 (class 2606 OID 27091)
-- Name: desagregation_indicateur fk_desagregation; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.desagregation_indicateur
    ADD CONSTRAINT fk_desagregation FOREIGN KEY (desagregation_id) REFERENCES public.desagregations(id) ON DELETE CASCADE;


--
-- TOC entry 5258 (class 2606 OID 27376)
-- Name: donnee_indicateur_desagregation fk_did_desagregation; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateur_desagregation
    ADD CONSTRAINT fk_did_desagregation FOREIGN KEY (desagregation_id) REFERENCES public.desagregations(id) ON DELETE CASCADE;


--
-- TOC entry 5259 (class 2606 OID 27366)
-- Name: donnee_indicateur_desagregation fk_did_donnee_indicateur; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateur_desagregation
    ADD CONSTRAINT fk_did_donnee_indicateur FOREIGN KEY (donnee_indicateur_id) REFERENCES public.donnee_indicateurs(id) ON DELETE CASCADE;


--
-- TOC entry 5243 (class 2606 OID 27325)
-- Name: donnee_indicateurs fk_donnee_indicateurs_commentaire; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateurs
    ADD CONSTRAINT fk_donnee_indicateurs_commentaire FOREIGN KEY (commentaire_valeur_indicateur_id) REFERENCES public.commentaire_valeur_indicateurs(id) ON DELETE SET NULL;


--
-- TOC entry 5244 (class 2606 OID 27295)
-- Name: donnee_indicateurs fk_donnee_indicateurs_indicateur; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateurs
    ADD CONSTRAINT fk_donnee_indicateurs_indicateur FOREIGN KEY (indicateur_id) REFERENCES public.indicateurs(id) ON DELETE CASCADE;


--
-- TOC entry 5245 (class 2606 OID 27290)
-- Name: donnee_indicateurs fk_donnee_indicateurs_nature_donnee; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateurs
    ADD CONSTRAINT fk_donnee_indicateurs_nature_donnee FOREIGN KEY (nature_donnee_id) REFERENCES public.nature_donnees(id) ON DELETE CASCADE;


--
-- TOC entry 5246 (class 2606 OID 27305)
-- Name: donnee_indicateurs fk_donnee_indicateurs_periode; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateurs
    ADD CONSTRAINT fk_donnee_indicateurs_periode FOREIGN KEY (periode_id) REFERENCES public.periodes(id) ON DELETE CASCADE;


--
-- TOC entry 5247 (class 2606 OID 27315)
-- Name: donnee_indicateurs fk_donnee_indicateurs_source; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateurs
    ADD CONSTRAINT fk_donnee_indicateurs_source FOREIGN KEY (source_indicateur_id) REFERENCES public.source_indicateurs(id) ON DELETE CASCADE;


--
-- TOC entry 5248 (class 2606 OID 27320)
-- Name: donnee_indicateurs fk_donnee_indicateurs_unite; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateurs
    ADD CONSTRAINT fk_donnee_indicateurs_unite FOREIGN KEY (unite_indicateur_id) REFERENCES public.unite_indicateurs(id) ON DELETE CASCADE;


--
-- TOC entry 5249 (class 2606 OID 27300)
-- Name: donnee_indicateurs fk_donnee_indicateurs_zone; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.donnee_indicateurs
    ADD CONSTRAINT fk_donnee_indicateurs_zone FOREIGN KEY (zone_id) REFERENCES public.zones(id) ON DELETE CASCADE;


--
-- TOC entry 5260 (class 2606 OID 27416)
-- Name: hypothese_risques fk_hypothese_risque_cadre_logique; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.hypothese_risques
    ADD CONSTRAINT fk_hypothese_risque_cadre_logique FOREIGN KEY (cadre_logique_id) REFERENCES public.cadre_logiques(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 5253 (class 2606 OID 27096)
-- Name: desagregation_indicateur fk_indicateur; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.desagregation_indicateur
    ADD CONSTRAINT fk_indicateur FOREIGN KEY (indicateur_id) REFERENCES public.indicateurs(id) ON DELETE CASCADE;


--
-- TOC entry 5268 (class 2606 OID 27555)
-- Name: piece_jointe_activites fk_piece_jointes_activite; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointe_activites
    ADD CONSTRAINT fk_piece_jointes_activite FOREIGN KEY (activite_id) REFERENCES public.activites(id) ON DELETE CASCADE;


--
-- TOC entry 5242 (class 2606 OID 27003)
-- Name: piece_jointes fk_piece_jointes_cadre; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointes
    ADD CONSTRAINT fk_piece_jointes_cadre FOREIGN KEY (cadre_developpement_id) REFERENCES public.cadre_developpements(id) ON DELETE CASCADE;


--
-- TOC entry 5264 (class 2606 OID 27483)
-- Name: piece_jointe_produits fk_piece_jointes_produit; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointe_produits
    ADD CONSTRAINT fk_piece_jointes_produit FOREIGN KEY (produit_id) REFERENCES public.produits(id) ON DELETE CASCADE;


--
-- TOC entry 5277 (class 2606 OID 27770)
-- Name: piece_jointe_projets fk_piece_jointes_projet; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.piece_jointe_projets
    ADD CONSTRAINT fk_piece_jointes_projet FOREIGN KEY (projet_id) REFERENCES public.projets(id) ON DELETE CASCADE;


--
-- TOC entry 5261 (class 2606 OID 27455)
-- Name: produits fk_produits_cadre_logique; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.produits
    ADD CONSTRAINT fk_produits_cadre_logique FOREIGN KEY (cadre_logique_id) REFERENCES public.cadre_logiques(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 5262 (class 2606 OID 27460)
-- Name: produits fk_produits_statut_produit; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.produits
    ADD CONSTRAINT fk_produits_statut_produit FOREIGN KEY (statut_produit_id) REFERENCES public.statut_produits(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 5263 (class 2606 OID 27497)
-- Name: produits fk_produits_type_produit; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.produits
    ADD CONSTRAINT fk_produits_type_produit FOREIGN KEY (type_produit_id) REFERENCES public.type_produits(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 5256 (class 2606 OID 27271)
-- Name: permission_role permission_role_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- TOC entry 5257 (class 2606 OID 27276)
-- Name: permission_role permission_role_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 5269 (class 2606 OID 27569)
-- Name: produit_zone produit_zone_produit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.produit_zone
    ADD CONSTRAINT produit_zone_produit_id_fkey FOREIGN KEY (produit_id) REFERENCES public.produits(id) ON DELETE CASCADE;


--
-- TOC entry 5270 (class 2606 OID 27574)
-- Name: produit_zone produit_zone_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.produit_zone
    ADD CONSTRAINT produit_zone_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES public.zones(id) ON DELETE CASCADE;


--
-- TOC entry 5275 (class 2606 OID 27756)
-- Name: projet_cadre_logique projet_cadre_logique_cadre_logique_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_cadre_logique
    ADD CONSTRAINT projet_cadre_logique_cadre_logique_id_fkey FOREIGN KEY (cadre_logique_id) REFERENCES public.cadre_logiques(id) ON DELETE CASCADE;


--
-- TOC entry 5276 (class 2606 OID 27751)
-- Name: projet_cadre_logique projet_cadre_logique_projet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_cadre_logique
    ADD CONSTRAINT projet_cadre_logique_projet_id_fkey FOREIGN KEY (projet_id) REFERENCES public.projets(id) ON DELETE CASCADE;


--
-- TOC entry 5278 (class 2606 OID 27842)
-- Name: projet_financement projet_financement_nature_financement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_financement
    ADD CONSTRAINT projet_financement_nature_financement_id_fkey FOREIGN KEY (nature_financement_id) REFERENCES public.nature_financements(id);


--
-- TOC entry 5279 (class 2606 OID 27822)
-- Name: projet_financement projet_financement_projet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_financement
    ADD CONSTRAINT projet_financement_projet_id_fkey FOREIGN KEY (projet_id) REFERENCES public.projets(id);


--
-- TOC entry 5280 (class 2606 OID 27832)
-- Name: projet_financement projet_financement_ptf_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_financement
    ADD CONSTRAINT projet_financement_ptf_id_fkey FOREIGN KEY (ptf_id) REFERENCES public.ptfs(id);


--
-- TOC entry 5281 (class 2606 OID 27827)
-- Name: projet_financement projet_financement_source_financement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_financement
    ADD CONSTRAINT projet_financement_source_financement_id_fkey FOREIGN KEY (source_financement_id) REFERENCES public.source_financements(id);


--
-- TOC entry 5282 (class 2606 OID 27837)
-- Name: projet_financement projet_financement_statut_financement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_financement
    ADD CONSTRAINT projet_financement_statut_financement_id_fkey FOREIGN KEY (statut_financement_id) REFERENCES public.statut_financements(id);


--
-- TOC entry 5273 (class 2606 OID 27732)
-- Name: projet_zone projet_zone_projet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_zone
    ADD CONSTRAINT projet_zone_projet_id_fkey FOREIGN KEY (projet_id) REFERENCES public.projets(id) ON DELETE CASCADE;


--
-- TOC entry 5274 (class 2606 OID 27737)
-- Name: projet_zone projet_zone_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.projet_zone
    ADD CONSTRAINT projet_zone_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES public.zones(id) ON DELETE CASCADE;


--
-- TOC entry 5254 (class 2606 OID 27256)
-- Name: role_user role_user_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.role_user
    ADD CONSTRAINT role_user_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 5255 (class 2606 OID 27261)
-- Name: role_user role_user_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: sysnise
--

ALTER TABLE ONLY public.role_user
    ADD CONSTRAINT role_user_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5548 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: sysnise
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


-- Completed on 2025-11-13 17:42:14

--
-- PostgreSQL database dump complete
--


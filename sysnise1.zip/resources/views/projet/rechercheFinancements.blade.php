@extends('layouts.app')
@section('content')
<div class="container-fluid">
    <div class="row">
	  <!-- Contenu principal -->
      <div class="col-md-12 col-lg-12">
        <div class="card">
		  <div class="card-header">
			<strong>Recherche Financement : </strong>
		  </div>
		  <div class="card-body">
			<form action="{{ route('projets.rechercheFinancements.store',['projet' => $projet->id]) }}" method="POST" enctype="multipart/form-data">
				@csrf
				<div class="row">
					<div class="row mb-3">
						<div class="col-md-6">
						  <label class="form-label">Source de Financement</label>
						   <select name="source_financement_id" class="form-select">
								<option value="">-- Sélectionner une source de financement --</option>
								@foreach($sourceFinancements as $source)
									<option value="{{ $source->id }}">
										{{ $source->intitule }}
									</option>
								@endforeach
							</select>
						</div>
						<div class="col-md-6">
						  <label class="form-label">Bailleurs</label>
						  <input name="bailleurs" type="text" class="form-control">
						</div>
						<div class="col-md-6">
						  <label class="form-label">Niveau de Financement</label>
						   <select name="niveau_financement_id" class="form-select">
								<option value="">-- Sélectionner un niveau de financement --</option>
								@foreach($StatutFinancements as $niveau)
									<option value="{{ $niveau->id }}">
										{{ $niveau->intitule }}
									</option>
								@endforeach
							</select>
						</div>
						<div class="col-md-6">
						  <label class="form-label">Mode de Financement</label>
						   <select name="mode_financement_id" class="form-select">
								<option value="">-- Sélectionner un mode de financement --</option>
								@foreach($natureFinancements as $mode)
									<option value="{{ $mode->id }}">
										{{ $mode->intitule }}
									</option>
								@endforeach
							</select>
						</div>
					</div>
				</div>
				<div class="mt-3 text-end">
					<a href="{{ url()->previous() }}" class="btn btn-secondary"><i class="fa fa-arrow-left"></i> Retour</a>
					<button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Enregistrer</button>
				</div>
			</form>
		  </div>
		</div>
	  </div>
	  
	  <!-- Tableau des pièces jointes -->
        <div class="col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong>Recherches Financements</strong>
                </div>
                <div class="card-body">
                    <table class="dataTable table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th class="text-left">Etude</th>
								<th class="text-left">Source de financement</th>
                                <th class="text-center table-icons">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($projet->etudeEnvisagees as $ED)
                            <tr>
                                <td class="text-left">{{ $ED->intitule }}</td>
								<td class="text-left">{{ $ED }}</td>
                                <td class="text-center table-icons">
                                    <a href="{{ route('projets.etudeEnvisagees.edit', [$projet->id,$ED->id]) }}" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                    <form action="{{ route('projets.etudeEnvisagees.destroy',[$projet->id,$ED->id]) }}" method="POST" style="display:inline-block;">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn btn-sm btn-danger" onclick="return confirm('Confirmer la suppression ?')"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
	  
    </div>
</div>

@endsection
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class RechercheFinancement extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'projet_id',
        'source_financement_id',
        'niveau_financement_id',
        'mode_financement_id',
        'bailleurs',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'id' => 'integer',
            'projet_id' => 'integer',
            'source_financement_id' => 'integer',
            'niveau_financement_id' => 'integer',
            'mode_financement_id' => 'integer',
        ];
    }

    public function projet(): BelongsTo
    {
        return $this->belongsTo(Projet::class);
    }

    public function sourceFinancement(): BelongsTo
    {
        return $this->belongsTo(SourceFinancement::class);
    }

    public function statutFinancement(): BelongsTo
    {
        return $this->belongsTo(StatutFinancement::class);
    }

    public function natureFinancement(): BelongsTo
    {
        return $this->belongsTo(NatureFinancement::class);
    }
}

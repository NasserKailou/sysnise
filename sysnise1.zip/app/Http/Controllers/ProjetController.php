<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Requests\CadreDeveloppementStoreRequest;
use App\Http\Requests\CadreDeveloppementUpdateRequest;
use App\Http\Requests\PopulationCibleProjetStoreRequest;
use App\Http\Requests\PopulationCibleProjetUpdateRequest;
use App\Models\CadreDeveloppement;
use App\Http\Requests\ProjetStoreRequest;
use App\Http\Requests\ProjetUpdateRequest;
use App\Models\CadreLogique;
use App\Models\EtudeDisponible;
use App\Models\EtudeEnvisagee;
use App\Models\ProjetFinancement;
use App\Models\Etude;
use App\Models\PieceJointeProjet;
use App\Models\Projet;
use App\Models\StatutProjet;
use App\Models\Zone;
use App\Models\Priorite;
use App\Models\PopulationCible;
use App\Models\InstitutionTutelle;
use App\Models\StatutFinancement;
use App\Models\Bailleur;
use App\Models\NatureFinancement;
use App\Models\SourceFinancement;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ProjetController extends Controller
{
    public function index(Request $request)
    {
        $projets = Projet::all();

        return view('projet.index', [
            'projets' => $projets,
			'breadcrumb' => 'Projets > Liste projets',
        ]);
    }

    public function create(Request $request)
    {
		$projets = Projet::all();
		$statutProjets = StatutProjet::all();
		$zones = Zone::all();
		$chaineLogiques = DB::table('view_cadre_logique')->get();
		$priorites = Priorite::all();
        $populationCibles = PopulationCible::all();
		$institutionTutelles = InstitutionTutelle::all();
		$statutFinancements = StatutFinancement::all();
		$natureFinancements = NatureFinancement::all();
		$sourceFinancements = SourceFinancement::all();
		

        return view('projet.create', [
            'projets' => $projets,
			'zones' => $zones,
			'populationCibles' => $populationCibles,
			'institutionTutelles' => $institutionTutelles,
			'priorites' => $priorites,
			'statutFinancements' => $statutFinancements,
			'natureFinancements' => $natureFinancements,
			'sourceFinancements' => $sourceFinancements,
			'chaineLogiques' => $chaineLogiques,
			'statutProjets' => $statutProjets,
			'breadcrumb' => 'Projet > Nouveau Projet',
        ]);
    }

    public function store(ProjetStoreRequest $request)
    {
        // Récupère les données validées
        $data = $request->validated();
		$projet = Projet::create($data);
		
		//Récupérer les IDs de zones envoyés depuis la vue
		$zoneIds = array_filter(explode(',', $request->input('zone_ids', '')));
		$projet->zoneInterventions()->attach($zoneIds);

		//Récupérer les IDs de Positionnement stratégique envoyés depuis la vue
		$cadreLogiqueIds = array_filter(explode(',', $request->input('chaine_logique_ids', '')));
		$projet->positionnementStrategiques()->attach($cadreLogiqueIds);

        return redirect()
			->route('projets.index')
			->with('success', 'Projet enregistré avec succès.');
	
    }

    public function show(Request $request, Projet $projet)
    {
		$zoneInterventions = $projet->zoneInterventions->pluck('intitule')->implode(', ');
		$positionnementStrategiques = $projet->positionnementStrategiques->pluck('intitule')->implode(', ');
        
		return view('projet.show', [
            'projet' => $projet,
			'zoneInterventions' => $zoneInterventions,
			'positionnementStrategiques' => $positionnementStrategiques,
			'breadcrumb' => 'Projet > Détail Projet',
        ]);
    }

    public function edit(Request $request, Projet $projet)
    {
        $projets = Projet::all();
		$statutProjets = StatutProjet::all();
		$zones = Zone::all();
		$chaineLogiques = DB::table('view_cadre_logique')->get();
		$priorites = Priorite::all();
        $populationCibles = PopulationCible::all();
		$institutionTutelles = InstitutionTutelle::all();
		$statutFinancements = StatutFinancement::all();
		$natureFinancements = NatureFinancement::all();
		$sourceFinancements = SourceFinancement::all();
		// Récupérer les zones liées au projet
		$zoneNames = $projet->zoneInterventions->pluck('intitule')->implode(', ');
		$zoneIds = $projet->zoneInterventions->pluck('id')->implode(',');
		
		// Récupérer les actions/cadre logique liées au projet
		$chaineLogiqueNames = $projet->positionnementStrategiques->pluck('intitule')->implode(', ');
		$chaineLogiqueIds = $projet->positionnementStrategiques->pluck('id')->implode(',');
		

        return view('projet.edit', [
            'projets' => $projets,
			'projet' => $projet,
			'zones' => $zones,
			'populationCibles' => $populationCibles,
			'institutionTutelles' => $institutionTutelles,
			'priorites' => $priorites,
			'statutFinancements' => $statutFinancements,
			'natureFinancements' => $natureFinancements,
			'sourceFinancements' => $sourceFinancements,
			'chaineLogiques' => $chaineLogiques,
			'statutProjets' => $statutProjets,
			'zoneNames' => $zoneNames,
			'zoneIds' => $zoneIds,
			'chaineLogiqueNames' => $chaineLogiqueNames,
			'chaineLogiqueIds' => $chaineLogiqueIds,
			'breadcrumb' => 'Projet > Mise à jour projet',
        ]);
    }

    public function update(ProjetUpdateRequest $request, Projet $projet)
    {
		$data = $request->validated();
        $projet->update($data);
		//Récupérer les IDs de zones envoyés depuis la vue
		$zoneIds = array_filter(explode(',', $request->input('zone_ids', '')));
		//Synchroniser les zones sans créer de doublons
		$projet->zoneInterventions()->sync($zoneIds);
		//Synchroniser les positionnements stratégiques sans créer de doublons
		$chaineLogiqueIds = array_filter(explode(',', $request->input('chaine_logique_ids', '')));
		$projet->positionnementStrategiques()->sync($chaineLogiqueIds);
		
        return redirect()
            ->route('projets.index')
            ->with('success', 'projet mis à jour avec succès.');

    }

    public function destroy(Request $request, Projet $projet)
    {
        $projet->delete();

        return redirect()->route('projets.index');
    }
	
	public function showActionStrategieNationaleForm()
    {
		$cadre_logiques = CadreLogique::all();
        return view('projet.actionStrategieNationale',compact('cadre_logiques'));
    }
	
	public function cadreProjet(Request $request, Projet $projet)
    {
		return view('projet.cadreProjet', [
            'projet' => $projet,
			'breadcrumb' => 'Projet > cadre stratégique',
        ]);
	}
	
	public function storeCadreProjet(CadreDeveloppementStoreRequest $request, Projet $projet)
    {
		$data = $request->validated();
		$data['type_cadre_developpement_id'] = 2;
		$cadreDeveloppement = CadreDeveloppement::create($data);
		$projet->cadre_developpement_id = $cadreDeveloppement->id;
		$projet->save();
		return redirect()->route('cadre_developpements.cadres_logiques.index',['cadre_developpement' => $cadreDeveloppement->id])->with('success', 'cadre de projet initialisé avec succès');
    }
	
	public function editCadreProjet(Request $request, Projet $projet)
    {
		return view('projet.editCadreProjet', [
            'projet' => $projet,
			'breadcrumb' => 'Projet > Mise à jour projet',
        ]);
	}
	
	public function updateCadreProjet(CadreDeveloppementStoreRequest $request, Projet $projet)
    {
		$data = $request->validated();
		$data['type_cadre_developpement_id'] = 2;
		$projet->cadreDeveloppement->update($data);
		
		return redirect()->route('cadre_developpements.cadres_logiques.index',['cadre_developpement' => $projet->cadreDeveloppement->id])->with('success', 'cadre de projet initialisé avec succès');
    }
	
	public function populationCible(Request $request, Projet $projet)
    {
		$populationCibles = PopulationCible::all();
		return view('projet.populationCible', [
            'projet' => $projet,
			'populationCibles' => $populationCibles,
			'breadcrumb' => 'Projet > Population Cible',
        ]);
	}
	
	public function storePopulationCibles(PopulationCibleProjetStoreRequest $request, Projet $projet)
    {
		$data = $request->validated();
		//updateExistingPivot;
		$projet->populationCibles()->attach($data['population_cible_id'], ['effectif' => $data['effectif'],]);
		
		return redirect()->route('projets.populationCibles',['projet' => $projet->id])->with('success', 'population cible enregistrée avec succès');
    }
	
	public function editPopulationCibles(Request $request, Projet $projet,$populationCibleId)
    {
		$populationCibles = PopulationCible::all();
		$populationCible = $projet->populationCibles->firstwhere('pivot.population_cible_id',$populationCibleId);
		$effectif = $populationCible->pivot->effectif;
		//$populationCibleId = $populationCible->pivot->population_cible_id;
		return view('projet.editPopulationCible', [
            'projet' => $projet,
			'populationCibles' => $populationCibles,
			'effectif' => $effectif,
			'populationCibleId' => $populationCibleId,
			'breadcrumb' => 'Projet > Mise à jour population cible',
        ]);
	}
	
	public function updatePopulationCibles(PopulationCibleProjetUpdateRequest $request, Projet $projet, PopulationCible $populationCible)
    {
		$data = $request->validated();
		$projet->populationCibles()->updateExistingPivot($data['population_cible_id'], ['effectif' => $data['effectif'],]);
		
		return redirect()->route('projets.populationCibles',['projet' => $projet->id])->with('success', 'population cible enregistrée avec succès');
    }
	
	public function etudeDisponibles(Request $request, Projet $projet)
    {
		$etudes = Etude::all();
		return view('projet.etudeDisponibles', [
            'projet' => $projet,
			'etudes' => $etudes,
			'breadcrumb' => 'Projet > Etudes Disponibles',
        ]);
	}
	
	public function storeEtudeDisponibles(Request $request,$projet_id)
    {
        // Validation
        $validated = $request->validate([
            'etude_id' => 'required',
            'fichier' => 'required',
        ]);
		
        // Sauvegarder le fichier
        $path = $request->file('fichier')->store('pieces', 'public');

        EtudeDisponible::create([
            'etude_id' => $validated['etude_id'],
            'fichier' => $path,
			'projet_id' => $projet_id,
        ]);

        return redirect()->back()->with('success', 'étude ajoutée avec succès.');
    }
	
	public function destroyEtudeDisponibles($projetID, $etudeId)
    {
        EtudeDisponible::where('projet_id',$projetID)->where('etude_id', $etudeId)->delete();
		return redirect()->back()->with('success', 'Etude supprimée avec succès.');
		
	}
	
	public function etudeEnvisagees(Request $request, Projet $projet)
    {
		$etudes = Etude::all();
		$sourceFinancements = SourceFinancement::all();
		return view('projet.etudeEnvisagees', [
            'projet' => $projet,
			'etudes' => $etudes,
			'sourceFinancements' => $sourceFinancements,
			'breadcrumb' => 'Projet > Etudes Envisagées',
        ]);
	}
	
	public function storeEtudeEnvisagees(Request $request,Projet $projet)
    {
        // Validation
        $data = $request->validate([
            'etude_id' => 'required',
            'source_financement_id' => 'required',
        ]);
		//updateExistingPivot;
		$projet->etudeEnvisagees()->attach($data['etude_id'], ['source_financement_id' => $data['source_financement_id'],]);
		
        return redirect()->back()->with('success', 'étude ajoutée avec succès.');
    
	}
	
	public function destroyEtudeEnvisagees($projetID, $etudeId, $sourceFinancementID)
    {
        EtudeEnvisagee::where('projet_id',$projetID)->where('etude_id', $etudeId)->where('source_financement_id', $sourceFinancementID)->delete();
		return redirect()->back()->with('success', 'Etude supprimée avec succès.');
		
	}
	public function editEtudeEnvisagees(Request $request, Projet $projet, Etude $etude, SourceFinancement $sourceFinancement)
    {
		$etudes = Etude::all();
		$sourceFinancements = SourceFinancement::all();
		return view('projet.editEtudeEnvisagees', [
            'projet' => $projet,
			'etudeId' => $etude->id,
			'sourceFinancementId' => $sourceFinancement->id,
			'etudes' => $etudes,
			'sourceFinancements' => $sourceFinancements,
			'breadcrumb' => 'Projet > Mise à jour Etude envisagée',
        ]);
	}
	
	public function updateEtudeEnvisagees(Request $request, Projet $projet, Etude $etude, SourceFinancement $sourceFinancement)
    {
		// Validation
        $data = $request->validate([
            'etude_id' => 'required',
            'source_financement_id' => 'required',
        ]);
		// Recherche de l'enregistrement existant
		$etudeEnvisagee = EtudeEnvisagee::where('projet_id', $projet->id)
        ->where('etude_id', $etude->id)
        ->where('source_financement_id', $sourceFinancement->id)
        ->first();
		
		// Si non trouvé → erreur
		if (!$etudeEnvisagee) {
			return redirect()->back()->with('error', 'Étude envisagée introuvable.');
		}
		
		// Mise à jour
		$etudeEnvisagee->update([
			'etude_id' => $data['etude_id'],
			'source_financement_id' => $data['source_financement_id'],
		]);
        return redirect()->route('projets.etudeEnvisagees',['projet' => $projet->id])->with('success', 'Etude envisagée mise à jour avec succès.');
	}
	
	public function financements(Request $request, Projet $projet)
    {
		$sourceFinancements = SourceFinancement::all();
		$bailleurs = Bailleur::all();
		$natureFinancements = NatureFinancement::all();
		$statutFinancements = StatutFinancement::all();
		return view('projet.financements', [
            'projet' => $projet,
			'sourceFinancements' => $sourceFinancements,
			'natureFinancements' => $natureFinancements,
			'statutFinancements' => $statutFinancements,
			'bailleurs' => $bailleurs,
			'breadcrumb' => 'Projet > Financements',
        ]);
	}
	
	public function storeFinancements(Request $request,Projet $projet)
    {
        // Validation
        $data = $request->validate([
            'bailleur_id' => 'required',
            'source_financement_id' => 'required',
			'statut_financement_id' => 'required',
			'nature_financement_id' => 'required',
			'montant' => 'required',
        ]);
		//updateExistingPivot;
		$projet->financements()->attach($data['source_financement_id'], ['bailleur_id' => $data['bailleur_id'], 'statut_financement_id' => $data['statut_financement_id'], 'nature_financement_id' => $data['nature_financement_id'], 'montant' => $data['montant'],]);
		
        return redirect()->back()->with('success', 'étude ajoutée avec succès.');
    
	}
	
	public function destroyFinancements($projetId, $bailleurId, $sourceFinancementId, $statutFinancementId, $natureFinancementId)
    {
        ProjetFinancement::where('projet_id',$projetId)->where('bailleur_id', $bailleurId)->where('source_financement_id', $sourceFinancementId)->where('statut_financement_id', $statutFinancementId)->where('nature_financement_id', $natureFinancementId)->delete();
		return redirect()->back()->with('success', 'Etude supprimée avec succès.');
		
	}
	public function editFinancements(Request $request, Projet $projet, $bailleurId, $sourceFinancementId, $statutFinancementId, $natureFinancementId)
    {
		$sourceFinancements = SourceFinancement::all();
		$bailleurs = Bailleur::all();
		$natureFinancements = NatureFinancement::all();
		$statutFinancements = StatutFinancement::all();
		$PF = ProjetFinancement::where('projet_id',$projet->id)->where('bailleur_id', $bailleurId)->where('source_financement_id', $sourceFinancementId)->where('statut_financement_id', $statutFinancementId)->where('nature_financement_id', $natureFinancementId)->first();
		return view('projet.editFinancements', [
            'projet' => $projet,
			'sourceFinancements' => $sourceFinancements,
			'natureFinancements' => $natureFinancements,
			'statutFinancements' => $statutFinancements,
			'bailleurs' => $bailleurs,
			'bailleurId' => $bailleurId,
			'sourceFinancementId' => $sourceFinancementId,
			'statutFinancementId' => $statutFinancementId,
			'natureFinancementId' => $natureFinancementId,
			'montant' => $PF->montant,
			'breadcrumb' => 'Projet > Mise à jour financement',
        ]);
	}
	
	public function updateFinancements(Request $request, Projet $projet)
    {
		// Validation
        $data = $request->validate([
            'bailleur_id' => 'required',
            'source_financement_id' => 'required',
			'statut_financement_id' => 'required',
			'nature_financement_id' => 'required',
			'montant' => 'required',
        ]);
		// Recherche de l'enregistrement existant
		$PF = ProjetFinancement::where('projet_id', $projet->id)
        ->where('source_financement_id', $data['source_financement_id'])
		->where('statut_financement_id', $data['statut_financement_id'])
		->where('nature_financement_id', $data['nature_financement_id'])
		->where('bailleur_id', $data['bailleur_id'])
        ->first();
		
		// Si non trouvé → erreur
		if (!$PF) {
			return redirect()->back()->with('error', 'Financement introuvable.');
		}
		
		// Mise à jour
		//$projet->financements()->attach($data['source_financement_id'], ['bailleur_id' => $data['bailleur_id'], 'statut_financement_id' => $data['statut_financement_id'], 'nature_financement_id' => $data['nature_financement_id'], 'montant' => $data['montant'],]);
		
		/*$PF->update([
			'source_financement_id' = $data['source_financement_id'],   
			'statut_financement_id' = $data['statut_financement_id'],
			'nature_financement_id' = $data['nature_financement_id'],
			'bailleur_id' = $data['bailleur_id'],
		]);*/
        return redirect()->route('projets.financements',['projet' => $projet->id])->with('success', 'financement mis à jour avec succès.');
	}
}

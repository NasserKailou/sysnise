<?php

namespace App\Http\Controllers;

use App\Http\Requests\OrientationCadreDeveloppementStoreRequest;
use App\Http\Requests\OrientationCadreDeveloppementUpdateRequest;
use App\Models\OrientationCadreDeveloppement;
use App\Models\CadreDeveloppement;
use App\Models\Indicateur;
use App\Models\CadreLogique;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class OrientationCadreDeveloppementController extends Controller
{
    
}
